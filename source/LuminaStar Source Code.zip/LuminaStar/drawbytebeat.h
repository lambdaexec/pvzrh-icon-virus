BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR?RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
int cx(void) {
	return GetSystemMetrics(SM_CXSCREEN);
}
int cy(void) {
	return GetSystemMetrics(SM_CYSCREEN);
}
DWORD WINAPI drawbytebeat1(LPVOID lpParam) {
	for (;;) {
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, cx(), cy(), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((((t >> 6 | t >> 8) * t) & 128));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI drawbytebeat2(LPVOID lpParam) {
	for (;;) {
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, cx(), cy(), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((((t & t % 255) ^ t) - 1));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI drawbytebeat3(LPVOID lpParam) {
	for (;;) {
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, cx(), cy(), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return (t * (t >> 8 | t >> 10));
			});
		ReleaseDC(0, hdc);
	}
}