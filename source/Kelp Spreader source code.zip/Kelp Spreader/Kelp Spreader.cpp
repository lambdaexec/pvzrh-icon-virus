﻿#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <memory>
#include <stdio.h>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
VOID WINAPI RotatePoints(POINT* points, int count, POINT center, float angle)
{
	float cosVal = cos(angle);
	float sinVal = sin(angle);
	for (int i = 0; i < count; i++)
	{
		int translatedX = points[i].x - center.x;
		int translatedY = points[i].y - center.y;
		points[i].x = static_cast<int>(translatedX * cosVal - translatedY * sinVal + center.x);
		points[i].y = static_cast<int>(translatedX * sinVal + translatedY * cosVal + center.y);
	}
}
COLORREF BlendPixel(COLORREF bg, COLORREF fg, BYTE alpha) {
	BYTE r = (GetRValue(fg) * alpha + GetRValue(bg) * (255 - alpha)) / 255;
	BYTE g = (GetGValue(fg) * alpha + GetGValue(bg) * (255 - alpha)) / 255;
	BYTE b = (GetBValue(fg) * alpha + GetBValue(bg) * (255 - alpha)) / 255;
	return RGB(r, g, b);
}
VOID WINAPI trainfunction(HDC hdc, int w, int h, int xPower, int yPower, DWORD dwRop) {
	if (xPower >= w) xPower = w - 1; if (yPower >= h) yPower = h - 1;
	HBITMAP screenshot = CreateCompatibleBitmap(hdc, w, h);
	HDC hdc2 = CreateCompatibleDC(hdc);
	SelectObject(hdc2, screenshot);
	BitBlt(hdc2, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	BitBlt(hdc, xPower > 0 ? xPower : 0, yPower > 0 ? yPower : 0, w - abs(xPower), h - abs(yPower), hdc, xPower < 0 ? -xPower : 0, yPower < 0 ? -yPower : 0, dwRop);
	BitBlt(hdc, xPower < 0 ? w + xPower : 0, 0, abs(xPower), h, hdc2, xPower > 0 ? w - xPower : 0, 0, dwRop);
	BitBlt(hdc, 0, yPower < 0 ? h + yPower : 0, w, abs(yPower), hdc2, 0, yPower > 0 ? h - yPower : 0, dwRop);
	DeleteDC(hdc2);
	DeleteObject(screenshot);
}
DWORD WINAPI screenrandomdrawkelpspreadericon(LPVOID lpParam) 
{
	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetWindowDC(hwnd);
	int sw = GetSystemMetrics(SM_CXSCREEN);
	int sh = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		DrawIcon(hdc, rand() % sw, rand() % sh, LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)));
		DrawIcon(hdc, rand() % sw, rand() % sh, LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(129)));
		Sleep(10);
	}
}
DWORD WINAPI manyrandomicon(LPVOID lpParam) {
	HINSTANCE HSHELL32 = LoadLibrary(_T("Shell32.dll"));
	HINSTANCE HIMAGERES = LoadLibrary(_T("Imageres.dll"));
	HINSTANCE HMORICONS = LoadLibrary(_T("Moricons.dll"));
	HINSTANCE HPIFMGR = LoadLibrary(_T("Pifmgr.dll"));
	for (;;) {
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetWindowDC(NULL);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		HICON load[9] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)) };
		DrawIconEx(hdc, rand() % w, rand() % h, load[rand() % 9], 96 * wdpi / 96, 96 * hdpi / 96, NULL, NULL, DI_NORMAL);
		DrawIconEx(hdc, rand() % w, rand() % h, load[rand() % 9], 96 * wdpi / 96, 96 * hdpi / 96, NULL, NULL, DI_NORMAL);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI hexagon(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	float rotationAngle = 0.0f;
	float rotationSpeed = 0.04f;
	while (true)
	{
		HDC hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;
		int top_x = 0 + x;
		int top_y = 0 + y;
		int bottom_x = 100 + x;
		int bottom_y = 100 + y;
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		POINT hexagonPoints[6];
		for (int i = 0; i < 6; ++i) {
			double angle = 2.0 * PI * i / 6;
			hexagonPoints[i].x = bottom_x + static_cast<int>(50 * cos(angle));
			hexagonPoints[i].y = bottom_y + static_cast<int>(50 * sin(angle));
		}
		POINT center =
		{
			(top_x + bottom_x) / 2, (top_y + bottom_y) / 2
		};
		RotatePoints(hexagonPoints, 6, center, rotationAngle);
		Polygon(hdc, hexagonPoints, 6);
		if (y >= GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}
		if (x >= GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}
		if (y == 0)
		{
			signY = 1;
		}
		if (x == 0)
		{
			signX = 1;
		}
		rotationAngle += rotationSpeed;
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI pieandrectangleandellipse(LPVOID lpParam)
{
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int nindazhidazhidadazhi = rand() % 3;
		switch (nindazhidazhidadazhi) {
		case 0:
			SelectObject(hcdc, CreateSolidBrush(RndRGB));
			Pie(hcdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h);
			break;
		case 1:
			SelectObject(hcdc, CreateSolidBrush(RndRGB));
			Ellipse(hcdc, rand() % w, rand() % h, rand() % w, rand() % h);
			break;
		case 2:
			SelectObject(hcdc, CreateSolidBrush(RndRGB));
			Rectangle(hcdc, rand() % w, rand() % h, rand() % w, rand() % h);
			break;
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(20);
	}
}
DWORD WINAPI circ1e(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		int rand_num_x = rand() % w;
		int rand_num_y = rand() % h;

		int top_x = 0 + rand_num_x;
		int top_y = 0 + rand_num_y;

		int bottom_x = 444 + rand_num_x;
		int bottom_y = 444 + rand_num_y;
		HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y);
		InvertRgn(hdc, circle);
		DeleteObject(circle);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI textout(LPVOID lpParam) {
	LPCSTR text[9] = { "Kelp Spreader.exe", "LambdaTechnology Studio", "LanPiaoPiaoFlyNB", "The reward from Stygian Kelp(SuperKelp) is unrealistic", "I can't find my way out of this predicament", "This place is filled only with hopelessness", "I don't know what should I do, use Threepeater?" , "Why do I have to give up right now?", "I can't breathe, can't move, I can just only helplessly look at the sky" };
	while (true) {
		DWORD bItalic = 1 - rand() % 2;
		DWORD bUnderline = 1 - rand() % 2;
		DWORD bStrikeOut = 1 - rand() % 2;

		int rdx = 1 + rand() % 5; int xxx = (rdx * 10) - 10;
		int cWidth = 70 - xxx;
		int cHeight = 80 - xxx;
		int tmp = rand() % 9;
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(NULL);
		SetBkMode(hdc, 1);
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(cHeight, cWidth, 0, 0, FW_NORMAL, bItalic, bUnderline, bStrikeOut, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Colonna MT");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % w, rand() % h, text[tmp], strlen(text[tmp]));
		ReleaseDC(NULL, hdc);
		DeleteObject(font);
		DeleteDC(hdc);
		Sleep(10);
	}
}
DWORD WINAPI train(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	for (;;) {
		for (int angle = 0; angle < 720; angle++) {
			int x = (-100) * cos(angle * PI / 180.F), y = (-100) * sin(angle * PI / 180.F);
			hdc = GetDC(0);
			trainfunction(hdc, w, h, x, y, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(1);
		}
	}
}
DWORD WINAPI bltblt_melting(LPVOID lpParam)
{
	while (true)
	{
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
		HDC hdcTemp = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(hdcTemp, hbm);
		BitBlt(hdcTemp, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int numShifts = 600;
		for (int i = 0; i < numShifts; i++)
		{
			int x = rand() % w;
			int y = rand() % h;
			int dx = (rand() % 3) - 1;
			int dy = (rand() % 3) - 1;
			BitBlt(hdcTemp, x + dx, y + dy, w - x, h - y, hdcTemp, x, y, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, w, h, hdcTemp, 0, 0, SRCCOPY);
		SelectObject(hdcTemp, hbmOld);
		DeleteDC(hdcTemp);
		DeleteObject(hbm);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI bitblt_screenmove(LPVOID lpParam) {
	//srand(time(NULL));
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int black_dick = rand() % 7891;
		BitBlt(hcdc, 0, 25 - (5 * (rand() % 10)), w - 20, h, hcdc, 20, 0, NOTSRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(20);
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI bitblt_mix(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		BitBlt(hdc, rand() % w, rand() % h, w, h, hdc, rand() % w, rand() % h, DSTINVERT);
		BitBlt(hdc, rand() % w, rand() % h, w, h, hdc, rand() % w, rand() % h, SRCCOPY);
		BitBlt(hdc, rand() % w, rand() % h, w, h, hdc, rand() % w, rand() % h, MERGEPAINT);
		Sleep(1);
	}
	ReleaseDC(NULL, hdc);
}
DWORD WINAPI bitblt_colourfulsquare(LPVOID lpParam) {
	HDC hdc = GetDC(HWND_DESKTOP);
	int X = GetSystemMetrics(SM_CXSCREEN);
	int Y = GetSystemMetrics(SM_CYSCREEN);

	while (TRUE)
	{
		HDC hdc = GetDC(HWND_DESKTOP);
		int X = GetSystemMetrics(SM_CXSCREEN);
		int Y = GetSystemMetrics(SM_CYSCREEN);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		BitBlt(hdc, rand() % (X - 0), rand() % (Y - 0), rand() % (X - 0), rand() % (Y - 0), hdc, rand() % (X - 0), rand() % (Y - 0), PATINVERT);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI stretchblt_Pull_up(LPVOID lpParam) {
	HDC hdc;
	int sw, sh;
	while (1) {
		hdc = GetDC(0);
		sw = GetSystemMetrics(0);
		sh = GetSystemMetrics(1);
		StretchBlt(hdc, 0, -20, sw, sh + 40, hdc, 0, 0, sw, sh, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
}
DWORD WINAPI mixblt_screenpaper(LPVOID lpParam) {
	//srand(time(NULL));
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int _w = rand() % 100 + 400, _h = rand() % 100 + 400;
		int x = rand() % (w - _w), y = rand() % (h - _h);
		StretchBlt(hcdc, x + (5 - rand() % 10), y + (5 - rand() % 10), _w + (5 - rand() % 10), _h + (5 - rand() % 10), hdc, x, y, _w, _h, SRCCOPY);
		StretchBlt(hcdc, x + (5 - rand() % 10), y + (5 - rand() % 10), _w + (5 - rand() % 10), _h + (5 - rand() % 10), hdc, x, y, _w, _h, SRCCOPY);
		StretchBlt(hcdc, x + (5 - rand() % 10), y + (5 - rand() % 10), _w + (5 - rand() % 10), _h + (5 - rand() % 10), hdc, x, y, _w, _h, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI sines1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;

	for (;;) {
		hdc = GetDC(0);
		for (float i = sh; i > 0; i -= 0.99f) {  // Loop from bottom to top
			int a = sin(angle) * 60;  // Calculate the sine offset
			BitBlt(hdc, a, i, sw, 1, hdc, 0, i - 1, SRCCOPY);  // Move pixels upward
			angle += PI / 70;
		}
		ReleaseDC(wnd, hdc);
		InvalidateRect(0, 0, 0);
	}
}
DWORD WINAPI blur1(LPVOID lpParam) {
	double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 64, 0 };
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y += 20) {
			StretchBlt(hcdc, -5 + rand() % 11, y, w, 20, hcdc, 0, y, w, 20, SRCAND);
		}
		for (int x = 0; x < w; x += 20) {
			StretchBlt(hcdc, x, -5 + rand() % 11, 20, h, hcdc, x, 0, 20, h, SRCCOPY);
		}
		for (float i = 0; i < w; i += 0.99f) {
			int a = sin(angle) * 20;
			BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, SRCCOPY);
			angle += PI / 40;
		}
		for (float i = 0; i < h; i += 0.99f) {
			int a = cos(angle) * 24;
			BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, SRCCOPY);
			angle += PI / 80;
		}
		GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
}
DWORD WINAPI rainbowlike(LPVOID lpParam) {
	int i = 0, move = 20;
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		for (int x = 0; x < w; x += move) {
			StretchBlt(hcdc, x, -5 + rand() % 11, move, h, hcdc, x, 0, move, h, SRCCOPY);
		}
		for (int y = 0; y < h; y += move) {
			StretchBlt(hcdc, -5 + rand() % 11, y, w, move, hcdc, 0, y, w, move, SRCCOPY);
		}
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				FLOAT fx = (x + (i + i * 20));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 200, 1.f);
				hslcolor.s += 1.f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1); i++;
	}
}
DWORD WINAPI shader1(LPVOID lpvd) //credits to pankoza, but I modified it
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * sqrt(x ^ i | y));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader2(LPVOID lpvd)//credits to xuge
{
	int qi = 0, j = 0, k = 1;
	bool control_spiral = true;
	while (control_spiral) {
		j += k;
		int width = GetSystemMetrics(0), height = GetSystemMetrics(1);
		LPVOID MyMemoryAddress = VirtualAlloc(0, (width * height + width) * sizeof(ColorTemp), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		ColorTemp* data = (ColorTemp*)MyMemoryAddress;
		HDC hdc = GetWindowDC(0), MemoryDC = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateBitmap(width, height, 1, 32, data);
		SelectObject(MemoryDC, hBitmap);
		BitBlt(MemoryDC, 0, 0, width, height, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hBitmap, width * height * 4, data);
		for (int i = 0; i < width * height; i++) {
			if (!control_spiral) break;
			int x = i % width - width / 2, y = i / width - height / 2;
			float angle = atan2((float)y, x) * 180 / 3.14159f;
			float radius = sqrt((float)x * x + y * y);
			int color_val = (int)(angle * 2 + radius + qi) % 768;
			ColorTemp vortex;
			if (color_val < 256) {
				vortex.r = 255 - color_val;
				vortex.g = 255 - color_val;
				vortex.b = 255 - color_val;
			}
			else if (color_val < 512) {
				vortex.r = 0;
				vortex.g = 0;
				vortex.b = 0;
			}
			else {
				vortex.r = color_val - 512;
				vortex.g = color_val - 512;
				vortex.b = color_val - 512;
			}
			BYTE alpha = (-32) + (int)(31 * sin(radius / 25.0f));
			COLORREF result = BlendPixel(
				RGB(data[i].r, data[i].g, data[i].b),
				RGB(vortex.r, vortex.g, vortex.b),
				alpha
			);
			data[i].r = GetRValue(result);
			data[i].g = GetGValue(result);
			data[i].b = GetBValue(result);
		}
		SetBitmapBits(hBitmap, width * height * 4, data);
		if (control_spiral) {
			BitBlt(hdc, 0, 0, width, height, MemoryDC, 0, 0, SRCCOPY);
		}
		ReleaseDC(0, hdc);
		ReleaseDC(0, MemoryDC);
		DeleteObject(hBitmap);
		DeleteDC(MemoryDC);
		DeleteDC(hdc);
		VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
		Sleep(32);
		qi += 24;
	}
	return 0;
}
DWORD WINAPI shader3(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (true)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * sqrt(RGB(y, x, i)+1));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader4(LPVOID lpParam) {
	int i = 0;
	while (1)
	{
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		BITMAPINFO bmpi = { 0 };

		bmpi.bmiHeader.biSize = sizeof(bmpi);
		bmpi.bmiHeader.biWidth = w;
		bmpi.bmiHeader.biHeight = h;
		bmpi.bmiHeader.biPlanes = 1;
		bmpi.bmiHeader.biBitCount = 32;
		bmpi.bmiHeader.biCompression = BI_RGB;

		RGBQUAD* rgbquad = NULL;
		HSL hslcolor;

		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)((4 ^ i) + ((8 & i) * tan(x * 2)) + (12 * i));

				rgbquad[index].rgbRed += fx;
				rgbquad[index].rgbGreen -= fx;
				rgbquad[index].rgbBlue += fx;
			}
		}

		i++;
		BLENDFUNCTION blur;
		blur.BlendOp = AC_SRC_OVER;
		blur.BlendFlags = 0;
		blur.AlphaFormat = 0;
		blur.SourceConstantAlpha = 70;
		StretchBlt(hcdc, 0, 0, w, h, hcdc, 1, 1, w, h, SRCERASE);
		StretchBlt(hcdc, 1, 1, w, h, hcdc, 0, 0, w, h, SRCCOPY);
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI shader5(LPVOID lpvd) //credits to pankoza
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)(sqrt(x & (i * 4)) * cbrt(y & (i * 4)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
VOID WINAPI sound1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t & (t / 256)) + t * (t | (t >> 5) | (t >> 9)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound2() {//callback from cephacetrile.exe
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((9 * (t >> 1 | t | t >> 9) + 1 * (t & t >> 91 | t >> 9) + 1 * (t ^ 91)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound3() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t ^ 7 >> t % 78 + 8 ^ t * (91 + t & 31) >> t % (13 - (t >> 13) % 7 * 8) - 91);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound4() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(91 * (0xACCEED * t >> (78 + (t >> 91 | t >> 13 | t >> (t >> 13 ^ t >> 91) + 7) & 7)) & 64);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound5() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)float(t * (t * ((int)tan(t >> 7 | t >> 8) & 91) & 31) + (78 * t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound6() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t / ((1 + ((t >> 9) & (t >> 8))) + 1) / (t + 1)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound7() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t - (t & (t >> 12)) / 2 * (t / 1024 % 4 - 3)) & 0x7F) + 8000.0 * (1.0 - (t % 16384) / 10000.0)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound8() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((2 * (t | (t >> 7) | t)) ^ (((4 * t) & (t >> 11)) + (((t >> 3) | ((t >> 4) | (t >> 9))) << 6)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound9() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t * (t >> 4) * (t >> 6)) >> 7) ^ t) - 1);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound10() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t & (91 << 13 + (t >> 78 & 13)) + 13) + 7 >> 8) + (t * 91));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * (t >> (t >> 10 & 7) & t >> 12)) | (~t * (0xCA98 >> (~t >> 9 & 14) & 15)) | ((t >> 10 | t * 5) & (t >> 8 | t * 4) & (t >> 4 | t * 6));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound12() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(2 * (t & (t / 256)) + t * ((t >> 14) & 0xE) - (t >> 5));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Kelp Spreader'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Kelp Spreader.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Kelp Spreader.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			Sleep(5000);
			HANDLE thread0 = CreateThread(0, 0, screenrandomdrawkelpspreadericon, 0, 0, 0);
			Sleep(500);
			HANDLE thread1_num1 = CreateThread(0, 0, bitblt_screenmove, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, mixblt_screenpaper, 0, 0, 0);
			HANDLE thread1_num3 = CreateThread(0, 0, bitblt_mix, 0, 0, 0);
			sound1();
			TerminateThread(thread1_num1, 0);
			TerminateThread(thread1_num2, 0);
			TerminateThread(thread1_num3, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, hexagon, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, shader1, 0, 0, 0);
			sound2();
			TerminateThread(thread2_num2, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, shader2, 0, 0, 0);
			sound3();
			TerminateThread(thread3, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, blur1, 0, 0, 0);
			sound4();
			TerminateThread(thread4, 0);
			refreshscr();
			HANDLE thread5 = CreateThread(0, 0, shader3, 0, 0, 0);
			sound5();
			TerminateThread(thread5, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, bltblt_melting, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, manyrandomicon, 0, 0, 0);
			sound6();
			TerminateThread(thread6_num1, 0);
			TerminateThread(thread6_num2, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, textout, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, shader4, 0, 0, 0);
			HANDLE thread7_num3 = CreateThread(0, 0, circ1e, 0, 0, 0);
			sound7();
			TerminateThread(thread7_num2, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, rainbowlike, 0, 0, 0);
			sound8();
			TerminateThread(thread8, 0);
			TerminateThread(thread7_num3, 0);
			refreshscr();
			HANDLE thread9 = CreateThread(0, 0, shader5, 0, 0, 0);
			sound9();
			TerminateThread(thread9, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, stretchblt_Pull_up, 0, 0, 0);
			sound10();
			TerminateThread(thread10, 0);
			refreshscr();
			HANDLE thread11_num1 = CreateThread(0, 0, train, 0, 0, 0);
			HANDLE thread11_num2 = CreateThread(0, 0, bitblt_colourfulsquare, 0, 0, 0);
			sound11();
			TerminateThread(thread11_num1, 0);
			TerminateThread(thread11_num2, 0);
			refreshscr();
			HANDLE thread12 = CreateThread(0, 0, sines1, 0, 0, 0);
			sound12();
			TerminateThread(thread12, 0);
			refreshscr();
			TerminateThread(thread0, 0);
			TerminateThread(thread2_num1, 0);
			TerminateThread(thread7_num1, 0);
		}
	}
	return 0;
}