﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 Kelp Spreader.rc 使用
//
#define IDC_MYICON                      2
#define IDD_KELPSPREADER_DIALOG         102
#define IDI_KELPSPREADER                107
#define IDI_SMALL                       108
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
